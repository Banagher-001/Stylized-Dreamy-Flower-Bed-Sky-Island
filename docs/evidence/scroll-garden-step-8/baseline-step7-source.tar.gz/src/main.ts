import './styles.css';

// The approved portfolio remains the default. Step 2 is an isolated prototype.
if (new URLSearchParams(window.location.search).get('tour') === 'prototype') {
  await import('./tour/startTourPrototype');
} else {
  await import('./portfolio/startPortfolio');
}
