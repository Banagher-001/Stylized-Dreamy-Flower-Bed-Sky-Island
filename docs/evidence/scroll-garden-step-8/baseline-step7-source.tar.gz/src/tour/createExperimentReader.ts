import { Vector3 } from 'three';
import type { Camera } from 'three';
import { experimentStations, sampleExperimentPresentation } from './experimentReading';
import type { ExperimentReadingFrame } from './experimentReading';
import { courtyardProject as project, experimentContent as content } from './experimentContent';
import type { ProjectTab } from './createProjectViewer';

/** Short pillar inscriptions; extended content lives in the project archive. */
export function createExperimentReader(app: HTMLElement, host: HTMLElement, anchorFor: (id: string) => Vector3 | undefined, open: (tab: ProjectTab, trigger: HTMLElement) => void) {
  const panel = document.createElement('section');panel.className = 'experiment-reading';panel.setAttribute('aria-label', '交互实验，沿第三根石柱浏览');panel.setAttribute('aria-hidden', 'true');
  const bodies = [
    `<p data-experiment-ink>${content.C1.body}</p><ol class="experiment-process" data-experiment-ink aria-label="从想法到交互">${content.C1.steps.map((s) => `<li>${s}</li>`).join('')}</ol>`,
    `<div class="experiment-project-summary"><figure class="experiment-cover"><img width="${project.cover.width}" height="${project.cover.height}" alt="${project.cover.alt}" decoding="async"/><span class="experiment-image-state" role="status">封面载入中</span></figure><div><p class="experiment-kind" data-experiment-ink>${project.kind}</p><p data-experiment-ink>${project.summary}</p></div></div><div class="experiment-entry-actions"><button type="button" data-project-tab="live">现场体验 <span aria-hidden="true">↗</span></button><button type="button" data-project-tab="archive">项目档案 <span aria-hidden="true">＋</span></button></div>`,
    `<p data-experiment-ink>${content.C3.body}</p><p class="experiment-cue" data-experiment-ink><span aria-hidden="true">↓</span> ${content.C3.cue}</p>`,
  ];
  const titles = [content.C1.title, project.title, content.C3.title];
  panel.innerHTML = experimentStations.map((s, i) => `<article data-experiment-station="${s.id}" aria-labelledby="experiment-${s.id}-title" aria-hidden="true" inert hidden><p class="experiment-eyebrow">03 / 交互实验 <span>${s.label}</span></p><h2 id="experiment-${s.id}-title">${titles[i]}</h2><div class="experiment-body">${bodies[i]}</div></article>`).join('');
  const connector = document.createElementNS('http://www.w3.org/2000/svg', 'svg');connector.classList.add('experiment-reading-link');connector.setAttribute('aria-hidden', 'true');
  const line = document.createElementNS('http://www.w3.org/2000/svg', 'path');connector.append(line);app.querySelector('main')!.append(connector, panel);
  const parts = [...panel.querySelectorAll<HTMLElement>('article')].map((article) => ({ article, title: article.querySelector<HTMLElement>('h2')!, eyebrow: article.querySelector<HTMLElement>('.experiment-eyebrow')!, body: article.querySelector<HTMLElement>('.experiment-body')!, buttons: [...article.querySelectorAll<HTMLButtonElement>('button')] }));
  const image = panel.querySelector<HTMLImageElement>('img')!, imageState = panel.querySelector<HTMLElement>('.experiment-image-state')!;
  const controller = new AbortController(), options = { signal: controller.signal };
  let primed = false, fallback = false, disposed = false, dirty = true, selected = '', signature = '';
  let layoutFrame: number | undefined;
  let reading: ExperimentReadingFrame | undefined, camera: Camera | undefined;
  let bounds = host.getBoundingClientRect(), header = app.querySelector<HTMLElement>('.tour-header')!.getBoundingClientRect(), heading = app.querySelector<HTMLElement>('.tour-heading')!.getBoundingClientRect(), nav = app.querySelector<HTMLElement>('.tour-stops')!.getBoundingClientRect();
  let width = 0, height = 0;
  const point = new Vector3();
  function prime() { if (!primed && !disposed) { primed = true;image.src = project.cover.src; } }
  image.addEventListener('load', () => { imageState.hidden = true;panel.dataset.coverState = 'ready'; }, options);
  image.addEventListener('error', () => { imageState.textContent = '封面暂不可用';panel.dataset.coverState = 'error'; }, options);
  panel.addEventListener('click', (event) => {
    const button = event.target instanceof Element ? event.target.closest<HTMLButtonElement>('[data-project-tab]') : null;
    if (button && !button.disabled) open(button.dataset.projectTab as ProjectTab, button);
  }, options);
  function measure() {
    bounds = host.getBoundingClientRect();header = app.querySelector<HTMLElement>('.tour-header')!.getBoundingClientRect();heading = app.querySelector<HTMLElement>('.tour-heading')!.getBoundingClientRect();nav = app.querySelector<HTMLElement>('.tour-stops')!.getBoundingClientRect();
    connector.setAttribute('viewBox', `0 0 ${innerWidth} ${innerHeight}`);dirty = true;signature = '';
  }
  function place() {
    if (!reading || !camera || fallback) return;
    point.copy(anchorFor(reading.station.id) ?? new Vector3(2.96, reading.station.y, 5.09)).project(camera);
    const x = bounds.left + (point.x + 1) * bounds.width / 2, y = bounds.top + (1 - point.y) * bounds.height / 2;
    const stacked = innerWidth <= 1000, right = stacked ? innerWidth - 16 : nav.left - 24;
    const desiredLeft = stacked ? 16 : x + bounds.width * .085;
    if (dirty) { width = stacked ? innerWidth - 32 : Math.min(500, right - desiredLeft);panel.style.width = `${Math.max(1, width)}px`;height = panel.getBoundingClientRect().height;dirty = false; }
    const left = Math.max(16, Math.min(desiredLeft, right - width));
    const minTop = stacked ? Math.max(heading.bottom + 16, y + 40) : Math.max(header.bottom + 16, left < heading.right + 16 ? heading.bottom + 16 : 0);
    const bottom = stacked ? Math.min(bounds.bottom - 16, nav.top - 16) : bounds.bottom - 20;
    const top = Math.max(minTop, Math.min(stacked ? y + 52 : y - height / 2, bottom - height));
    panel.style.left = `${Math.round(left)}px`;panel.style.top = `${Math.round(top)}px`;
    const clear = stacked ? top >= y + 40 : left >= x + 60;
    panel.dataset.anchorX = x.toFixed(4);panel.dataset.anchorY = y.toFixed(4);panel.dataset.anchorClear = String(clear);panel.dataset.layout = stacked ? 'stacked' : 'side';panel.dataset.fits = String(clear && top + height <= bottom + .5 && top >= header.bottom + 16);
    line.setAttribute('d', stacked ? `M ${Math.round(x)} ${Math.round(y + 28)} Q ${Math.round(x)} ${Math.round(top - 14)} ${Math.round(left + width / 2)} ${Math.round(top - 8)}` : `M ${Math.round(x + 38)} ${Math.round(y)} C ${Math.round(left - 30)} ${Math.round(y)}, ${Math.round(left - 30)} ${Math.round(top + 30)}, ${Math.round(left - 8)} ${Math.round(top + 30)}`);
  }
  const observer = new ResizeObserver(() => {
    // Project entry resizes the shared host. Apply layout outside observer
    // delivery so WebKit can finish that delivery before we change panel size.
    if (disposed || layoutFrame !== undefined) return;
    layoutFrame = requestAnimationFrame(() => { layoutFrame = undefined;if (!disposed) { measure();place(); } });
  });
  for (const el of [host, panel, app.querySelector<HTMLElement>('.tour-heading')!, app.querySelector<HTMLElement>('.tour-header')!, app.querySelector<HTMLElement>('.tour-stops')!]) observer.observe(el);
  measure();
  return {
    prime,
    update(next: ExperimentReadingFrame | undefined, nextCamera: Camera, reduced = false) {
      reading = next;camera = nextCamera;
      const state = sampleExperimentPresentation(reading, reduced);
      if (fallback) return state;
      panel.dataset.progress = (reading?.progress ?? 0).toFixed(7);
      const nextSignature = `${reading?.station.id}|${reading?.phase}|${state.frame}|${state.title}|${state.body}|${state.offset}|${camera.position.toArray()}|${camera.projectionMatrix.elements[0]}`;
      if (signature === nextSignature && !dirty) return state;signature = nextSignature;
      if (selected !== (reading?.station.id ?? '')) { selected = reading?.station.id ?? '';dirty = true;for (const part of parts) part.article.hidden = part.article.dataset.experimentStation !== selected; }
      const visible = !!reading && state.frame > .000001;
      panel.dataset.visible = String(visible);panel.dataset.station = selected;panel.dataset.phase = reading?.phase ?? 'off';panel.dataset.titleOpacity = state.title.toFixed(7);panel.dataset.bodyOpacity = state.body.toFixed(7);
      panel.style.visibility = visible ? 'visible' : 'hidden';panel.setAttribute('aria-hidden', String(!visible));panel.style.setProperty('--experiment-frame-opacity', String(state.frame));connector.style.opacity = String(state.title * .6);
      for (const { article, title, eyebrow, body, buttons } of parts) {
        const active = visible && article.dataset.experimentStation === selected;
        article.inert = !active;article.setAttribute('aria-hidden', String(!active));
        for (const element of [title, eyebrow]) { element.style.opacity = String(active ? state.title : 0);element.setAttribute('aria-hidden', String(!active || state.title <= .000001)); }
        body.style.opacity = String(active ? state.body : 0);body.style.visibility = active && state.body > .000001 ? 'inherit' : 'hidden';body.style.transform = `translateY(${state.offset}px)`;body.setAttribute('aria-hidden', String(!active || state.body <= .000001));
        for (const button of buttons) button.disabled = !active || state.body < .999999;
      }
      if (reading) { if (reading.station.id === 'C2') prime();place(); }
      return state;
    },
    showFallback() {
      fallback = true;prime();panel.classList.add('experiment-fallback');panel.style.visibility = 'visible';panel.setAttribute('aria-hidden', 'false');panel.style.setProperty('--experiment-frame-opacity', '1');connector.style.display = 'none';
      for (const part of parts) {
        part.article.hidden = false;part.article.inert = false;part.article.setAttribute('aria-hidden', 'false');
        for (const element of [part.title, part.eyebrow, part.body]) { element.style.opacity = '1';element.style.visibility = 'visible';element.removeAttribute('aria-hidden');element.style.transform = 'none'; }
        for (const button of part.buttons) { button.disabled = button.dataset.projectTab === 'live';if (button.disabled) button.title = '图形场景暂不可用，可查看项目档案。'; }
      }
    },
    get element() { return panel; },
    dispose() { disposed = true;if (layoutFrame !== undefined) cancelAnimationFrame(layoutFrame);controller.abort();observer.disconnect();panel.remove();connector.remove(); },
  };
}
