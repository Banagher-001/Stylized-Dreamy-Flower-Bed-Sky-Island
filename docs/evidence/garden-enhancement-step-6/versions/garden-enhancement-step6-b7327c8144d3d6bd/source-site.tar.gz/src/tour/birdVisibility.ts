import { birdConfig } from '../config/birds';
import type { BirdRect, BirdView } from '../scene/createBirds';

/** Reuse rectangles while the camera/layout is held. Only the three reader
 * shells are considered, never a fresh measurement of ten article trees.
 */
export function createBirdVisibility(app: HTMLElement, host: HTMLElement, wake: () => void) {
  const fixed = [...app.querySelectorAll<HTMLElement>('.tour-header,.tour-footer,.tour-stops')];
  const dynamic = [...app.querySelectorAll<HTMLElement>('.tour-heading,.pillar-reading,.film-reading,.experiment-reading')];
  const live = app.querySelector<HTMLElement>('.tour-project-live-space');
  const copy = (r: DOMRect): BirdRect => ({ left: r.left, top: r.top, right: r.right, bottom: r.bottom });
  let layoutKey = '', poseKey = '', fixedRects: BirdRect[] = [], dynamicRects: BirdRect[] = [];
  let disposed = false;
  const sizes = new WeakMap<Element, string>();
  const resize = new ResizeObserver(entries => {
    if (disposed) return;
    let changed = false;
    for (const e of entries) { const key = `${e.contentRect.width}/${e.contentRect.height}`;if (sizes.get(e.target) !== key) { sizes.set(e.target, key);changed = true; } }
    if (changed) { layoutKey = '';poseKey = '';wake(); }
  });
  for (const e of [host, ...fixed, ...dynamic, ...(live ? [live] : [])]) resize.observe(e);
  const view: BirdView = { bounds: { left: 0, top: 0, right: 1, bottom: 1 }, avoid: [], margin: birdConfig.desktopMargin, key: '' };
  const visible = (e: HTMLElement) => !e.hidden && getComputedStyle(e).visibility === 'visible' && Number(getComputedStyle(e).opacity) > .000001;
  return {
    measure(layout: string, pose: string, projectLive: boolean) {
      if (layoutKey !== layout) { layoutKey = layout;fixedRects = fixed.filter(visible).map(e => copy(e.getBoundingClientRect()));poseKey = ''; }
      if (poseKey !== pose) {
        poseKey = pose;view.bounds = copy(host.getBoundingClientRect());
        dynamicRects = projectLive ? [] : dynamic.filter(visible).map(e => copy(e.getBoundingClientRect()));
        view.avoid = projectLive ? [] : [...fixedRects, ...dynamicRects];
        if (projectLive && live) {
          // Projection uses the complete original canvas. Clip/safe margins use
          // the real live pane separately; never create another scene/camera.
          const r = copy(live.getBoundingClientRect()), b = view.bounds;
          view.avoid = [
            { left: b.left - 1000, right: r.left, top: b.top - 1000, bottom: b.bottom + 1000 },
            { left: r.right, right: b.right + 1000, top: b.top - 1000, bottom: b.bottom + 1000 },
            { left: r.left, right: r.right, top: b.top - 1000, bottom: r.top },
            { left: r.left, right: r.right, top: r.bottom, bottom: b.bottom + 1000 },
          ];
        }
        view.margin = view.bounds.right - view.bounds.left < 600 ? birdConfig.mobileMargin : birdConfig.desktopMargin;
        view.key = `${layout}/${pose}`;
      }
      return view;
    },
    dispose() { if (disposed) return;disposed = true;resize.disconnect(); },
  };
}
