import{E as e,F as t,G as n,K as r,M as i,N as a,P as o,S as s,Sn as c,T as l,V as u,W as d,Y as f,Z as p,at as m,bn as h,c as g,en as _,et as v,fn as y,h as b,in as x,j as S,nn as C,nt as w,o as T,on as E,ot as D,r as O,rn as k,sn as ee,tt as A,u as j,wn as M,xn as N}from"./three-core-DhN96CcZ.js";import{t as P}from"./three-renderer-yvH6S2DZ.js";(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),t.credentials=e.crossOrigin===`use-credentials`?`include`:e.crossOrigin===`anonymous`?`omit`:`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var F={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},I={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`},L=[{name:`草地`,color:F.grassBase},{name:`石面`,color:F.stoneLight},{name:`背光`,color:F.stoneShade},{name:`树影`,color:F.treeShadow},{name:`水色`,color:F.waterBase},{name:`花朵`,color:F.flower}],R={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},z={defaultMode:`pixel`,maxDevicePixelRatio:2},B={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},V={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},column:{layerRatios:[1.07,.96,1.03,.94],layerSeeds:[11,29,47],layerChips:[0,.028,.052],baseBevel:.024,capBevel:.038,profiles:[{layers:[0,1,0,2],offsets:[-.012,.012,-.008,0],capCorner:2,capChip:.12},{layers:[1,2,0,1],offsets:[.008,-.01,.01,0],capCorner:1,capChip:.095},{layers:[2,0,1,0],offsets:[-.008,.012,-.008,0],capCorner:3,capChip:.145}]},fountain:{copingHeight:.14,jointWidth:.032,bevel:.024,chippedSegments:[1,5],chipSize:.1},wall:{bodyBlocks:3,capBlocks:2},path:{bevel:.014,cornerCut:.045,chippedSlabs:[1,4,6],chipSize:.065}},H={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25]},grass:{count:240,gapCount:12,minHeight:.065,maxHeight:.14,clearance:.06,gapMinHeight:.105,gapMaxHeight:.13,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},U={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function te(e){return{enabled:e.get(`env`)!==`off`&&U.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||U.petals.enabled}}var W={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function ne(e={}){let t={...te(new URLSearchParams),...e};return{options:t,time:{value:W.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function re(e,t){let n=Math.sin(e*12.9898+t*78.233+U.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var ie=Math.hypot(...U.wind.direction),ae=[U.wind.direction[0]/ie,U.wind.direction[1]/ie],G=e=>e.toFixed(10),oe=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${ae.map(G).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,se=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function ce(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${oe}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${se}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${G(U.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${G(U.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function le(e,t){let n=new f,r=e===`foliage`||e===`flower`;n.name=`courtyard-${e}`,n.userData.artSurface=e;let i=t?.options.enabled&&(r||e===`ground`);return n.customProgramCacheKey=()=>`courtyard-art-${e}-v3${i?`-environment-v1`:``}`,n.onBeforeCompile=n=>{let a=B.treeShadows,o=H.ground,s=H.treeDetail;Object.assign(n.uniforms,{uArtSunAmount:{value:B.sun.intensity},uArtFillAmount:{value:B.fill.intensity},uArtStoneVariation:{value:V.colorVariation},uArtGrass:{value:new j(F.grassBase)},uArtGrassLight:{value:new j(F.grassLight)},uArtGrassDark:{value:new j(F.grassDark)},uArtGrassShadow:{value:new j(F.treeShadow)},uArtStoneTop:{value:new j(F.stoneLight)},uArtStoneSide:{value:new j(F.stoneSide)},uArtStoneShade:{value:new j(F.stoneShade)},uArtWater:{value:new j(F.waterBase)},uArtWaterShade:{value:new j(F.waterShade)},uArtPlantShade:{value:new j(F.plantShade)},uArtFlowerShade:{value:new j(F.flowerShade)},uArtFlowerCenter:{value:new j(F.flowerCenter)},uArtGroundEnabled:{value:+!!o.enabled},uArtGroundScales:{value:new c(o.macroScale,o.macroStrength,o.detailScale,o.detailStrength)},uArtGroundDensity:{value:o.detailDensity},uArtQuietRegion:{value:new c(o.quietCenter[0],o.quietCenter[1],o.quietRadius[0],o.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!s.enabled},uArtTreeDetail:{value:new c(s.branchScale,s.leafScale,s.edgeBreakup,s.gapStrength)},uArtTreesEnabled:{value:+!!a.enabled},uArtTreeNoiseScale:{value:a.edgeNoiseScale},uArtTreeNoiseAmount:{value:a.edgeNoiseAmount},uArtTreeSoftness:{value:a.edgeSoftness},uArtTreePatches:{value:a.patches.map(e=>new c(e.center[0],e.center[1],e.radius[0],e.radius[1]))},uArtTreeRotations:{value:a.patches.map(e=>e.rotation)}}),n.vertexShader=n.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${e===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${r?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${e===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${r?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let l=`
      varying vec3 vArtWorldPosition;
      ${e===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${r?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${a.patches.length}];
      uniform float uArtTreeRotations[${a.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${a.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;n.fragmentShader=n.fragmentShader.replace(`#include <common>`,`#include <common>\n${l}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[e]}\n#include <opaque_fragment>`),i&&ce(n,r,t)},n}function ue(e){return le(`ground`,e)}var K={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08,baseHeight:.18,shaftWidth:.72,shaftDepth:.78,shaftHeight:3.05,capWidth:1.02,capDepth:1.04,capHeight:.24},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,columns:4,rows:2,stepX:.74,stepZ:.63,slabWidth:.63,slabDepth:.52,slabHeight:.09}},q=1e-7;function de(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<q*q)||t.push(n);return t}function fe(e,t,n){let r=[],i=[];for(let a of e){let e=[];for(let r=0;r<a.length;r++){let o=a[r],s=a[(r+1)%a.length],c=t.dot(o)-n,l=t.dot(s)-n;if(c<=q&&e.push(o),c<-1e-7&&l>q||c>q&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),i.push(t)}else Math.abs(c)<=q&&i.push(o)}let o=de(e);o.length>=3&&r.push(o)}let a=de(i);if(a.length>=3){let e=a.reduce((e,t)=>e.add(t),new N).divideScalar(a.length),n=Math.abs(t.y)<.9?new N(0,1,0):new N(1,0,0),i=t.clone().cross(n).normalize(),o=t.clone().cross(i).normalize();a.sort((t,n)=>{let r=t.clone().sub(e),a=n.clone().sub(e);return Math.atan2(r.dot(o),r.dot(i))-Math.atan2(a.dot(o),a.dot(i))}),r.push(a)}return r}function pe(t,n){let r=t.getAttribute(`position`),i=Math.sin(n*12.9898+.73)*.65,a=new Float32Array(r.count);for(let e=0;e<r.count;e++)a[e]=i+Math.sin(r.getX(e)*1.6+r.getZ(e)*2.3+n)*.25;return t.setAttribute(`stoneTint`,new e(a,1)),t}function me(t,n,r){if(t.length<3||n<=0)throw Error(`Stone prism needs a polygon and positive height.`);let i=t.map(([e,t])=>[e,t]);i.reduce((e,t,n)=>{let r=i[(n+1)%i.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(i=i.reverse());let a=n/2,o=i.map(([e,t])=>new N(e,a,t)),s=i.map(([e,t])=>new N(e,-a,t)),c=[o,[...s].reverse()],l=[];for(let e=0;e<i.length;e++){let t=(e+1)%i.length,n=s[e],r=s[t];c.push([n,r,o[t],o[e]]);let a=r.clone().sub(n).cross(new N(0,1,0)).normalize();l.push({normal:a,distance:a.dot(n)})}let u=Math.min(r.bevel,n*.2);for(let e=0;e<l.length;e++){let t=l[e];for(let e of[-1,1]){let n=t.normal.clone().add(new N(0,e,0)),r=(t.distance+a-u)/n.length();c=fe(c,n.normalize(),r)}let n=l[(e+l.length-1)%l.length],i=n.normal.clone().add(t.normal),o=(n.distance+t.distance-r.cornerCut)/i.length();c=fe(c,i.normalize(),o)}if(r.chipSize&&r.chipSize>0){let e=(r.chipCorner??0)%l.length,t=l[(e+l.length-1)%l.length],n=l[e],i=t.normal.clone().add(n.normal).add(new N(0,1,0)),o=(t.distance+n.distance+a-r.chipSize)/i.length();c=fe(c,i.normalize(),o)}let d=[],f=[];for(let e of c){let t=e.reduce((e,t)=>e.add(t),new N).divideScalar(e.length),n=new N;for(let r=0;r<e.length;r++)n.add(e[r].clone().sub(t).cross(e[(r+1)%e.length].clone().sub(t)));if(!(n.lengthSq()<q*q)){n.normalize();for(let r=0;r<e.length;r++){let i=e[r],a=e[(r+1)%e.length];if(!(i.clone().sub(t).cross(a.clone().sub(t)).lengthSq()<q*q))for(let e of[t,i,a])d.push(e.x,e.y,e.z),f.push(n.x,n.y,n.z)}}}let p=new T;return p.setAttribute(`position`,new e(d,3)),p.setAttribute(`normal`,new e(f,3)),pe(p,r.seed),p.computeBoundingBox(),p.computeBoundingSphere(),p.userData.stoneSolid=!0,p}function he(e,t,n,r){let i=e/2,a=n/2;return me([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}function ge(){return le(`stone`)}function _e(){return{time:{value:W.initialTime},impacts:{value:Array.from({length:W.ripples.capacity},()=>new c(0,0,0,0))}}}function ve(e=_e(),t=`surface`){let n=le(`water`);n.name=`courtyard-water-${t}`,n.flatShading=t===`jet`,n.userData.waterKind=t,n.customProgramCacheKey=()=>`courtyard-water-${t}-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=K.fountain;Object.assign(n.uniforms,{uWaterTime:e.time,uWaterImpacts:e.impacts,uWaterEnabled:{value:+!!W.enabled},uWaterBase:{value:new j(W.colors.base)},uWaterDeep:{value:new j(W.colors.deep)},uWaterShade:{value:new j(W.colors.shade)},uWaterWhite:{value:new j(W.colors.highlight)},uWaterJet:{value:new j(W.colors.jet)},uWaterOrigin:{value:new c(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uWaterSurface:{value:new c(W.surface.flowSpeed,W.surface.reflectionThreshold,W.surface.waveSpeed,W.surface.waveStrength)},uWaterRipple:{value:new c(W.ripples.lifetime,W.ripples.speed,W.ripples.strength,a.innerRadius*Math.cos(Math.PI/8))}});let o=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${W.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,l=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(l))throw Error(`Water shader extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(l,t===`surface`?s:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},n}function ye(e){let t=new S;t.name=`courtyard-blockout`;let r=new Set;function i(e){return r.add(e),e}let a=new Map,o=ge(),s=ve(e);function c(e,t,r,s,c,l,u=0,d=0,f={}){let p={bevel:V.bevel,cornerCut:V.cornerCut,seed:11,...f},m=JSON.stringify([r,s,c,p]),h=a.get(m);h||(h=i(he(r,s,c,p)),a.set(m,h));let g=new n(h,o);return g.name=t,g.position.set(u,l+s/2,d),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let u=K.fountain,d=new S;d.name=`fountain`,d.position.set(...u.position),d.rotation.y=u.rotationY,t.add(d);let f=new n(i(me(Array.from({length:8},(e,t)=>[Math.cos(t*Math.PI/4)*u.baseRadius,-Math.sin(t*Math.PI/4)*u.baseRadius]),u.baseHeight,{bevel:.018,cornerCut:.025,seed:11})),o);f.name=`fountain-base`,f.position.y=u.baseHeight/2,f.castShadow=!0,f.receiveShadow=!0,d.add(f);let p=new x,m=new w;for(let e=0;e<8;e++){let t=e*Math.PI/4,n=-t,r=Math.cos(t)*u.outerRadius,i=Math.sin(t)*u.outerRadius,a=Math.cos(n)*u.innerRadius,o=Math.sin(n)*u.innerRadius;e===0?(p.moveTo(r,i),m.moveTo(a,o)):(p.lineTo(r,i),m.lineTo(a,o))}p.closePath(),m.closePath(),p.holes.push(m);let h=new S;h.name=`fountain-rim`,h.position.y=u.baseHeight,d.add(h);let _=V.fountain,v=u.rimHeight-_.copingHeight,y=new n(i(pe(new l(p,{depth:v,bevelEnabled:!1,steps:1,curveSegments:1}),11)),o);y.name=`fountain-rim-wall`,y.rotation.x=-Math.PI/2,y.castShadow=!0,y.receiveShadow=!0,h.add(y);function b(e){let t=Math.cos(Math.PI/4)*e,n=-Math.sin(Math.PI/4)*e,r=_.jointWidth/(2*Math.hypot(t-e,n));return[[e+(t-e)*r,n*r],[t+(e-t)*r,n*(1-r)]]}let[C,T]=b(u.outerRadius),[E,D]=b(u.innerRadius),O=new Map;for(let e=0;e<8;e++){let t=_.chippedSegments.some(t=>t===e),r=t?`chip-${e%2}`:`plain-${e%2}`,a=O.get(r);a||(a=i(me([C,T,D,E],_.copingHeight,{bevel:_.bevel,cornerCut:.025,seed:29+e%2,chipSize:t?_.chipSize:0,chipCorner:e%2})),O.set(r,a));let s=new n(a,o);s.name=`fountain-coping-${e}`,s.position.y=v+_.copingHeight/2,s.rotation.y=e*Math.PI/4,s.castShadow=!0,s.receiveShadow=!0,h.add(s)}let k=new n(i(new g(u.innerRadius-.008,8)),s);k.name=`fountain-water`,k.rotation.x=-Math.PI/2,k.position.y=u.waterHeight,k.receiveShadow=!0,d.add(k),c(d,`fountain-pedestal-foot`,u.pedestalFootSize,u.pedestalFootHeight,u.pedestalFootSize,u.baseHeight);let ee=u.baseHeight+u.pedestalFootHeight;c(d,`fountain-pedestal`,u.pedestalSize,u.pedestalHeight,u.pedestalSize,ee),c(d,`fountain-pedestal-cap`,u.pedestalCapSize,u.pedestalCapHeight,u.pedestalCapSize,ee+u.pedestalHeight,0,0,{bevel:.016,chipSize:.06,chipCorner:2,seed:29});let A=K.columnShape;for(let[e,n]of K.columns.entries()){let r=new S;r.name=n.name;let[i,a,o]=n.position;r.position.set(i,a,o),r.rotation.y=n.rotationY;let s=V.column,l=s.profiles[e];c(r,`${n.name}-base`,A.baseWidth,A.baseHeight,A.baseDepth,0,0,0,{bevel:s.baseBevel,chipSize:.04,chipCorner:e%2,seed:29});let u=new S;u.name=`${n.name}-shaft`,r.add(u);let d=V.joints.width,f=s.layerRatios,p=A.shaftHeight-d*(f.length-1),m=f.reduce((e,t)=>e+t,0),h=A.baseHeight;for(let e=0;e<f.length;e++){let t=p*f[e]/m,r=l.layers[e];c(u,`${n.name}-block-${e}`,A.shaftWidth,t,A.shaftDepth,h,l.offsets[e],0,{seed:s.layerSeeds[r],chipSize:s.layerChips[r],chipCorner:r}),h+=t,e<f.length-1&&(c(u,`${n.name}-joint-${e}`,A.shaftWidth-V.joints.recess*2,d,A.shaftDepth-V.joints.recess*2,h,0,0,{bevel:0,cornerCut:0,seed:47}),h+=d)}c(r,`${n.name}-cap`,A.capWidth,A.capHeight,A.capDepth,A.baseHeight+A.shaftHeight,0,0,{bevel:s.capBevel,chipSize:l.capChip,chipCorner:l.capCorner,seed:47+e}),t.add(r)}let j=K.wall,M=new S;M.name=`wallLeft`,M.position.set(...j.position),M.rotation.y=j.rotationY,c(M,`wallLeft-base`,j.length+j.endSize,j.baseHeight,j.baseDepth,0);let N=new S;N.name=`wallLeft-body`,M.add(N);let P=V.wall.bodyBlocks,F=V.joints.width,I=(j.length-(P-1)*F)/P;for(let e=0;e<P;e++){let t=-j.length/2+I/2+e*(I+F);c(N,`wallLeft-body-${e}`,I,j.height,j.depth,j.baseHeight,t,0,{seed:11+e*18,chipSize:e===P-1?.075:0,chipCorner:2}),e<P-1&&c(N,`wallLeft-body-joint-${e}`,F,j.height,j.depth-V.joints.recess*2,j.baseHeight,t+I/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}let L=new S;L.name=`wallLeft-cap`,M.add(L);let R=V.wall.capBlocks,z=(j.length-(R-1)*F)/R;for(let e=0;e<R;e++){let t=-j.length/2+z/2+e*(z+F);c(L,`wallLeft-cap-${e}`,z,j.capHeight,j.capDepth,j.baseHeight+j.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===R-1?.065:0,chipCorner:2}),e<R-1&&c(L,`wallLeft-cap-joint-${e}`,F,j.capHeight*.65,j.capDepth-V.joints.recess*2,j.baseHeight+j.height,t+z/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}c(M,`wallLeft-end`,j.endSize,j.endHeight,j.endSize,j.baseHeight,j.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(M);let B=K.path,H=new S;H.name=`pathRight`,H.position.set(...B.position),H.rotation.y=B.rotationY;for(let e=0;e<B.rows;e++)for(let t=0;t<B.columns;t++)c(H,`pathRight-slab-${e}-${t}`,B.slabWidth,B.slabHeight,B.slabDepth,0,(t-(B.columns-1)/2)*B.stepX,(e-(B.rows-1)/2)*B.stepZ,{bevel:V.path.bevel,cornerCut:V.path.cornerCut,seed:11+(e*B.columns+t)%3*18,chipSize:V.path.chippedSlabs.some(n=>n===e*B.columns+t)?V.path.chipSize:0,chipCorner:(e*B.columns+t)%4});t.add(H);let U=!1;return{root:t,dispose(){if(!U){U=!0,t.removeFromParent(),t.clear();for(let e of r)e.dispose();o.dispose(),s.dispose()}}}}function be(t,n,r){let i=new T;return i.setAttribute(`position`,new e(t,3)),i.setAttribute(`plantPart`,new e(n,1)),i.setAttribute(`plantHeight`,new e(r,1)),i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function xe(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>be(e,t,n)}}function Se(){let e=xe();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function Ce(){let e=xe();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function we(e){let t=xe();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function Te(e,t){let n=le(e,t);return n.side=2,n}function Ee(e,t,n,r=.035){let i=K.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=K.columnShape;for(let n of K.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=K.wall;if(f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY))return!1;let h=K.path;for(let n=0;n<h.rows;n++)for(let r=0;r<h.columns;r++){let i=(r-(h.columns-1)/2)*h.stepX,a=(n-(h.rows-1)/2)*h.stepZ;if(f(e,t,h.position[0]+Math.cos(h.rotationY)*i+Math.sin(h.rotationY)*a,h.position[2]-Math.sin(h.rotationY)*i+Math.cos(h.rotationY)*a,h.slabWidth,h.slabDepth,h.rotationY))return!1}return!0}function De(e,n){let r=new S;r.name=`courtyard-vegetation`;let i=H.seed;function a(){i+=1831565813;let e=Math.imul(i^i>>>15,1|i);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let s=(e,t)=>e+(t-e)*a();function c(t,n){let r=new N(t,0,n).project(e);return Math.abs(r.x)<.98&&Math.abs(r.y)<.98}function l(e,t){let n=H.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let u=[],f=[];if(H.enabled){for(let e=0;u.length<H.grass.count&&e<H.grass.count*120;e++){let e,t;if(a()<.48){let n=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],r=a()*Math.PI*2,i=Math.sqrt(a())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=s(-7.5,7.4),t=s(-8.7,8.4);!c(e,t)||!Ee(e,t,H.grass.clearance)||l(e,t)&&a()<.9||u.push({x:e,z:t,height:s(H.grass.minHeight,H.grass.maxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:H.grass.clearance,gap:!1})}for(let e=0;f.length<H.flowers.count&&e<H.flowers.count*120;e++){let e=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],t=a()*Math.PI*2,n=a()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,o=s(H.flowers.minDiameter,H.flowers.maxDiameter),u=o*.55+.01;c(r,i)&&!l(r,i)&&Ee(r,i,u)&&(f.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+u)*.85)||f.push({x:r,z:i,height:s(H.flowers.minHeight,H.flowers.maxHeight),diameter:o,rotation:a()*Math.PI*2,color:a(),radius:u,gap:!1}))}if(u.length!==H.grass.count||f.length!==H.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=K.path,t=[];for(let n=0;n<e.rows;n++)for(let r=0;r<e.columns-1;r++)t.push([(r-(e.columns-2)/2)*e.stepX,(n-(e.rows-1)/2)*e.stepZ]);for(let n=0;n<e.columns;n++)t.push([(n-(e.columns-1)/2)*e.stepX,0]);t.push([-e.stepX,0],[e.stepX,0]);for(let[n,r]of t.slice(0,H.grass.gapCount)){let t=e.position[0]+Math.cos(e.rotationY)*n+Math.sin(e.rotationY)*r+s(-.006,.006),i=e.position[2]-Math.sin(e.rotationY)*n+Math.cos(e.rotationY)*r+s(-.006,.006);if(!Ee(t,i,.023,.008))throw Error(`Paving gap vegetation intersects stone.`);u.push({x:t,z:i,height:s(H.grass.gapMinHeight,H.grass.gapMaxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:.023,gap:!0})}}let p=[],m=[],h=[];if(H.enabled){let e=Te(`foliage`,n),i=Te(`flower`,n);m.push(e,i);let a=Se(),s=Ce(),c=we(4),l=we(5);p.push(a,s,c,l);function g(e,i,a,s,c){let l=new t(i,a,s.length);l.name=e,l.castShadow=!1,l.receiveShadow=!0;let u=new d,f=new D,p=new N(0,1,0),m=new j(c===`flower`?F.flower:c===`stem`?F.plantStem:F.grassBlade),g=new j(c===`flower`?F.flowerLight:F.grassBladeLight);if(s.forEach((e,t)=>{f.setFromAxisAngle(p,e.rotation);let n=c===`flower`?e.diameter:e.height,r=c===`grass`&&e.gap?H.grass.gapWidthScale:1;u.compose(new N(e.x,H.rootHeight+(c===`flower`?e.height:0),e.z),f,new N(n*r,n,n*r)),l.setMatrixAt(t,u),l.setColorAt(t,m.clone().lerp(g,c===`stem`?e.color*.25:c===`flower`?e.color*.6:e.color*.85))}),l.instanceMatrix.needsUpdate=!0,l.instanceColor&&(l.instanceColor.needsUpdate=!0),n?.options.enabled){let e=new Float32Array(s.length*3),t=new Float32Array(s.length*4);s.forEach((n,r)=>{let i=c===`grass`?n.gap?U.wind.gapAngle:U.wind.grassAngle:U.wind.flowerAngle;e.set([n.x,H.rootHeight,n.z],r*3),t.set([n.height,i,re(n.x,n.z),+(c===`flower`)],r*4)}),i.setAttribute(`windRoot`,new o(e,3)),i.setAttribute(`windShape`,new o(t,4))}l.computeBoundingBox(),l.computeBoundingSphere(),n?.options.enabled&&(l.boundingBox.expandByScalar(.02),l.boundingSphere.radius+=.02),l.userData.plants=s,l.userData.plantType=c,h.push(l),r.add(l)}g(`grass-clusters`,a,e,u,`grass`),g(`flower-stems`,s,e,f,`stem`),g(`flowers-four-petal`,c,i,f.filter((e,t)=>t%2==0),`flower`),g(`flowers-five-petal`,l,i,f.filter((e,t)=>t%2==1),`flower`)}r.userData.seed=H.seed,r.userData.counts={grass:u.length,flowers:f.length,batches:h.length};let g=!1;return{root:r,dispose(){if(!g){g=!0;for(let e of h)e.dispose();for(let e of p)e.dispose();for(let e of m)e.dispose();r.removeFromParent(),r.clear()}}}}function Oe(){let e=W.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=W.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=W.jet.emitterHeight-K.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function ke(e,t,n){return n.set(e.vx*t,W.jet.emitterHeight+e.vy*t-.5*W.drops.gravity*t*t,e.vz*t)}function Ae(e){let r=new S;r.name=`fountain-effects`;let i=K.fountain;r.position.set(...i.position),r.rotation.y=i.rotationY;let a=Oe();r.userData.dropParameters=a;let o=ve(e,`jet`),s=i.baseHeight+i.pedestalFootHeight+i.pedestalHeight+i.pedestalCapHeight,c=W.jet.emitterHeight-s,l=new b(W.jet.stemRadius,W.jet.stemRadius,c,8),u=new ee(1,8,5),f=new v(1,0),p=new n(l,o);p.name=`fountain-water-column`,p.position.y=s+c/2,p.receiveShadow=!0;let m=new n(u,o);m.name=`fountain-water-crown`,m.position.y=W.jet.emitterHeight,m.receiveShadow=!0;let h=new t(f,o,a.length);h.name=`fountain-water-drops`,h.receiveShadow=!0,h.boundingBox=new O(new N(-1.4,.3,-1.4),new N(1.4,1.45,1.4)),h.boundingSphere=h.boundingBox.getBoundingSphere(new E),r.add(p,m,h),r.visible=W.enabled;let g=new N,_=new N,y=new d,x=new D,C=new d,w=a.map(e=>({drop:e,age:0})),T=(e,t)=>e.age-t.age,k=(e,t)=>(e%t+t)%t;function A(t){e.time.value=t;let n=0;for(let e of a){let r=k(t-e.phase,W.drops.period);if(r>=e.impactTime)continue;ke(e,r,g);let i=Math.min(1,r/.07),a=Math.min(1,(e.impactTime-r)/.055),o=e.radius*Math.min(i,a);o<5e-4||(_.setScalar(o),y.compose(g,x,_),h.setMatrixAt(n++,y))}h.count=n;for(let e=n;e<a.length;e++)h.setMatrixAt(e,C);h.instanceMatrix.needsUpdate=!0;for(let e of w)e.age=k(t-e.drop.phase-e.drop.impactTime,W.drops.period);w.sort(T);let i=0;for(let t=0;t<e.impacts.value.length;t++){let n=w[t];n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),i++):e.impacts.value[t].set(0,0,0,0)}let o=W.jet.pulse,s=W.jet.radius;m.scale.set(s*(1+o*Math.sin(t*2.1)),s*.9*(1+o*Math.sin(t*2.8)),s*(1+o*Math.cos(t*2.1))),p.scale.set(1+o*Math.sin(t*2.1),1,1+o*Math.sin(t*2.1)),r.userData.time=t,r.userData.activeDrops=n,r.userData.activeRipples=i}A(W.initialTime);let j=!1;return{root:r,update:A,dispose(){j||(j=!0,h.dispose(),l.dispose(),u.dispose(),f.dispose(),o.dispose(),r.removeFromParent(),r.clear())}}}function je(){let n=U.petals,i=U.seed+1;function a(){i+=1831565813;let e=Math.imul(i^i>>>15,1|i);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let o=Array.from({length:n.capacity},(e,t)=>{let r=0,i=0,o=!1;for(let e=0;e<1e3;e++){let e=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],t=a()*Math.PI*2,s=a()*e.radius;if(r=e.center[0]+Math.cos(t)*s,i=e.center[1]+Math.sin(t)*s,Ee(r,i,n.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:r,z:i,phase:t*n.period/n.capacity,rotation:a()*Math.PI*2,size:.055+a()*.02}}),s=new T;s.setAttribute(`position`,new e([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),s.computeVertexNormals();let c=new r({color:F.flowerLight,side:2,toneMapped:!1});c.name=`courtyard-floating-petal`;let l=new t(s,c,n.capacity);l.name=`courtyard-floating-petals`,l.castShadow=!1;let u=new O;for(let e of o)u.expandByPoint(new N(e.x-n.drift,n.minHeight,e.z-n.drift)),u.expandByPoint(new N(e.x+n.drift,n.maxHeight,e.z+n.drift));u.expandByScalar(.05),l.boundingBox=u,l.boundingSphere=u.getBoundingSphere(new E),l.userData.parameters=o;let f=new d,p=new N,m=new N,h=new D,g=new d,_=new N(.25,1,.15).normalize(),v=!1;return{mesh:l,update(e){let t=0;for(let r of o){let i=((e-r.phase)%n.period+n.period)%n.period;if(i>=n.lifetime)continue;let a=i/n.lifetime,o=Math.min(1,i/.6,(n.lifetime-i)/.7);p.set(r.x+Math.sin(i*.6+r.rotation)*n.drift,n.maxHeight+(n.minHeight-n.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*n.drift),h.setFromAxisAngle(_,r.rotation+i*.25),m.setScalar(r.size*o),f.compose(p,h,m),l.setMatrixAt(t++,f)}l.count=t;for(let e=t;e<n.capacity;e++)l.setMatrixAt(e,g);l.instanceMatrix.needsUpdate=!0},dispose(){v||(v=!0,l.dispose(),s.dispose(),c.dispose(),l.removeFromParent())}}}function Me(e={}){let t=ne(e),r=new C;r.background=new j(F.grassBase);let i=new A;i.position.set(...R.camera.position),i.lookAt(...R.camera.target),i.near=R.camera.near,i.far=R.camera.far;let o=new m(R.ground.size,R.ground.size),c=ue(t),l=new n(o,c);l.name=`courtyard-ground`,l.rotation.x=-Math.PI/2,l.receiveShadow=!0,r.add(l);let u=_e(),d=ye(u);r.add(d.root);let f=Ae(u);r.add(f.root);let p=new a(F.highlight,F.stoneShade,B.fill.intensity);p.name=`courtyard-fill`;let h=new s(F.highlight,B.sun.intensity);h.name=`courtyard-sun`,h.position.set(...B.sun.position),h.castShadow=B.shadows.enabled;let g=B.shadows;h.shadow.mapSize.setScalar(g.mapSize),h.shadow.camera.left=-g.extent,h.shadow.camera.right=g.extent,h.shadow.camera.top=g.extent,h.shadow.camera.bottom=-g.extent,h.shadow.camera.near=g.near,h.shadow.camera.far=g.far,h.shadow.bias=g.bias,h.shadow.normalBias=g.normalBias,h.shadow.radius=g.radius,r.add(p,h,h.target);function _(e){let t=R.camera.viewHeight/2;i.left=-t*e,i.right=t*e,i.top=t,i.bottom=-t,i.updateProjectionMatrix()}_(1),i.updateMatrixWorld(!0);let v=De(i,t);r.add(v.root);let y=t.options.enabled&&t.options.petals?je():void 0;y&&(y.update(t.time.value),r.add(y.mesh));let b=!1;return{scene:r,camera:i,setAspect:_,update(e){f.update(e),t.time.value=e,y?.update(e)},waterState:u,environmentState:t,dispose(){b||(b=!0,o.dispose(),c.dispose(),d.dispose(),v.dispose(),f.dispose(),y?.dispose(),h.shadow.dispose(),r.clear())}}}var Ne=[320,384,448],Pe={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function Fe(e){let t=Number(e.get(`pixelSize`));return{resolution:Ne.some(e=>e===t)?t:Pe.resolution,finish:e.get(`finish`)===`soft`?`soft`:Pe.finish,storage:`auto`}}function Ie(t,r){let a=r.storage!==`byte`&&t.extensions.has(`EXT_color_buffer_float`),o=new M(1,1,{type:a?i:y,minFilter:p,magFilter:p,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});o.texture.colorSpace=a?u:_,o.texture.name=`courtyard-pixel-scene`;let s=new T;s.setAttribute(`position`,new e([-1,-1,0,3,-1,0,-1,3,0],3)),s.setAttribute(`uv`,new e([0,0,2,0,0,2],2));let c=Pe.finishes[r.finish],l=new k({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:o.texture},uSampleSize:{value:new h(1,1)},uLevels:{value:c.levels},uDither:{value:c.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),d=new C,f=new A(-1,1,1,-1,0,1),m=new n(s,l);m.frustumCulled=!1,d.add(m);let g=!1,v=0;function b(){o.dispose(),s.dispose(),l.dispose()}return{releaseGpuResources:b,resize(e,t){let n=Math.min(1,r.resolution/Math.max(e,t)),i=Math.max(1,Math.round(e*n)),a=Math.max(1,Math.round(t*n));(i!==o.width||a!==o.height)&&(o.setSize(i,a),l.uniforms.uSampleSize.value.set(i,a),v++)},render(e,n){t.setRenderTarget(o),t.render(e,n),t.setRenderTarget(null),t.render(d,f)},getInfo(){return{sampleWidth:o.width,sampleHeight:o.height,designResolution:r.resolution,finish:r.finish,storage:a?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:c.levels,dither:c.dither,allocations:v}},dispose(){g||(g=!0,b(),d.clear())}}}function Le(e){let r=new Set,i=new Set;e.traverse(e=>{if(e instanceof n){r.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])i.add(t)}e instanceof t&&e.dispose(),e instanceof s&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of r)e.dispose();for(let e of i)e.dispose()}function Re(e,t,n,r=Fe(new URLSearchParams),i){let a=new P({antialias:!1,alpha:!1});a.outputColorSpace=_,a.toneMapping=0,a.shadowMap.enabled=!0,a.shadowMap.type=1,a.shadowMap.autoUpdate=!1,a.shadowMap.needsUpdate=!0,a.info.autoReset=!1;let o=Ie(a,r),s=new h,c=a.domElement;c.setAttribute(`role`,`img`),c.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(c);let l=t,u=!1,d=!1,f=!1,p=!1,m=!0,g,v,y;function b(){y!==void 0&&cancelAnimationFrame(y),y=void 0}function x(){u||d||p||m||!g||y!==void 0||(y=requestAnimationFrame(e=>{y=void 0,u||d||p||m||g?.(e)}))}function S(){let e=!u&&!d&&!p;(!e||m)&&b(),a.setAnimationLoop(e&&m&&g?g:null),e&&!m&&x()}function C(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||u)return;let r=Math.min(window.devicePixelRatio||1,z.maxDevicePixelRatio);a.setPixelRatio(r),a.setSize(Math.max(1,Math.floor(t.width)),Math.max(1,Math.floor(t.height)),!1),a.getDrawingBufferSize(s),o.resize(s.x,s.y),c.dataset.renderMode=l;let i=o.getInfo();c.dataset.sampleWidth=String(l===`pixel`?i.sampleWidth:s.x),c.dataset.sampleHeight=String(l===`pixel`?i.sampleHeight:s.y),c.dataset.pixelProfile=String(i.designResolution),c.dataset.finish=i.finish,n(t.width/t.height),x()}function w(t){t.preventDefault(),d=!0,f=!0,e.dataset.renderState=`context-lost`,S(),o.releaseGpuResources(),v&&Le(v),i?.(`context-lost`)}function T(){d=!1,a.shadowMap.needsUpdate=!0,i?.(`restored`),C(),S()}c.addEventListener(`webglcontextlost`,w),c.addEventListener(`webglcontextrestored`,T);let E=new ResizeObserver(C);E.observe(e),window.addEventListener(`resize`,C);let D;function O(){D?.removeEventListener(`change`,k),D=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),D.addEventListener(`change`,k)}function k(){O(),C()}return O(),C(),{canvas:c,setMode(e){l=e,C()},setAnimating(e){m=e,S()},setSuspended(e){p=e,S()},renderOnce(){g?.(performance.now()),x()},getStats(){return{geometries:a.info.memory.geometries,textures:a.info.memory.textures,programs:a.info.programs?.length??0,calls:a.info.render.calls,triangles:a.info.render.triangles,mode:l,outputWidth:a.domElement.width,outputHeight:a.domElement.height,pixel:l===`pixel`?o.getInfo():null}},start(t,n,r){v=t,g=s=>{u||d||p||(r?.(s),a.info.reset(),l===`pixel`?o.render(t,n):(a.setRenderTarget(null),a.render(t,n)),e.dataset.renderState=`ready`,f&&(f=!1,i?.(`ready`),x()))},S()},dispose(){u||(u=!0,b(),E.disconnect(),window.removeEventListener(`resize`,C),D.removeEventListener(`change`,k),c.removeEventListener(`webglcontextlost`,w),c.removeEventListener(`webglcontextrestored`,T),a.setAnimationLoop(null),g=void 0,v=void 0,o.dispose(),a.dispose(),!a.getContext().isContextLost()&&a.extensions.has(`WEBGL_lose_context`)&&a.forceContextLoss(),c.remove())}}}function ze(e,t=W.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function Be(e,t,n=!1){let r=window.matchMedia(`(prefers-reduced-motion: reduce)`),i=ze(t),a=n?!0:null,o=!1;function s(){return{playing:!document.hidden&&!(a??r.matches),hidden:document.hidden,reducedMotion:r.matches}}function c(){o||(i.resetTimestamp(),e(s()))}function l(){r.matches&&a!==!0&&(a=null),c()}return document.addEventListener(`visibilitychange`,c),r.addEventListener(`change`,l),{get state(){return s()},get time(){return i.time},advance(e){return i.tick(e,s().playing)},resetTimestamp:i.resetTimestamp,toggle(){a=!(a??r.matches),c()},dispose(){o||(o=!0,document.removeEventListener(`visibilitychange`,c),r.removeEventListener(`change`,l))}}}for(let[e,t]of Object.entries(I))document.documentElement.style.setProperty(`--color-${e}`,t);var J=document.querySelector(`#app`);if(!J)throw Error(`Missing application root.`);J.innerHTML=`
  <main class="study">
    <header class="masthead">
      <div class="identity">
        <svg class="mark" viewBox="0 0 32 32" fill="none" aria-hidden="true">
          <path d="m16 3 12 7v13l-12 7-12-7V10Z M4 10l12 7 12-7 M16 17v13" />
        </svg>
        <div>
          <h1>庭院习作</h1>
          <p class="eyebrow">A STUDY OF LIGHT & COLOR</p>
        </div>
      </div>
      <span class="view-label">固定视角<span aria-hidden="true"> ↗</span></span>
    </header>

    <figure class="composition" aria-label="光与颜色的场景习作">
      <div class="scene-host" id="scene-host" data-render-state="loading">
        <p id="scene-notice" class="scene-notice" hidden></p>
      </div>
      <figcaption class="scene-caption">
        <span>一方水池，几段旧时光。</span>
        <span class="caption-note">庭院的轮廓</span>
      </figcaption>
    </figure>

    <section class="tools" aria-label="画面显示设置">
      <p class="tools-label">观看方式</p>
      <div class="tool-actions">
        <div class="mode-controls" role="group" aria-label="渲染模式">
          <button type="button" data-mode="native" aria-pressed="true">正常画面</button>
          <button type="button" data-mode="pixel" aria-pressed="false">像素预览</button>
        </div>
        <button type="button" id="motion-control" class="motion-control">暂停动效</button>
      </div>
    </section>

    <footer class="palette-footer" aria-label="场景基础色板">
      <span class="palette-title">庭院色谱</span>
      <ul class="swatches"></ul>
    </footer>
    <p id="render-status" class="sr-only" role="status" aria-live="polite"></p>
  </main>
`;var Ve=J.querySelector(`.swatches`);for(let e of L){let t=document.createElement(`li`);t.className=`swatch`,t.title=`${e.name} ${e.color}`;let n=document.createElement(`span`);n.className=`swatch-chip`,n.style.backgroundColor=e.color,n.setAttribute(`aria-hidden`,`true`);let r=document.createElement(`span`);r.textContent=e.name,t.append(n,r),Ve.append(t)}var Y=J.querySelector(`#scene-host`),He=J.querySelector(`#scene-notice`),X=J.querySelector(`#render-status`),Ue=[...J.querySelectorAll(`[data-mode]`)],We=J.querySelector(`#motion-control`),Ge=new URLSearchParams(window.location.search),Ke=Ge.get(`render`),Z=Ke===`pixel`||Ke===`native`?Ke:z.defaultMode,qe=Me(te(Ge)),Q,Je=new AbortController,Ye=Ge.get(`waterTime`)?.trim(),Xe=Ye?Number(Ye):NaN,Ze=Number.isFinite(Xe)&&Xe>=0&&Xe<=86400?Xe:void 0;function Qe(e){We.textContent=e.playing?`暂停动效`:`播放动效`,We.title=e.reducedMotion&&!e.playing?`已按减少动态设置暂停，点按可播放`:``,Y.dataset.motionState=e.hidden?`hidden`:e.playing?`running`:`paused`,Q?.setSuspended(e.hidden),Q?.setAnimating(e.playing)}var $=Be(Qe,Ze??W.initialTime,Ze!==void 0),$e;function et(e){if(e===`restored`){$.resetTimestamp();return}window.clearTimeout($e),$e=void 0;let t=e===`context-lost`;He.hidden=!t;for(let e of[...Ue,We])e.disabled=t;t?(He.textContent=`画面正在恢复，请稍候。`,X.textContent=`图形连接中断，正在恢复画面。`,$e=window.setTimeout(()=>{He.textContent=`画面恢复较慢，可刷新页面重试。`,X.textContent=He.textContent},4e3)):X.textContent=`画面已恢复。`}function tt(){for(let e of Ue)e.setAttribute(`aria-pressed`,String(e.dataset.mode===Z));X.textContent=Z===`pixel`?`已切换为像素预览。`:`已切换为正常画面。`}try{Q=Re(Y,Z,qe.setAspect,Fe(Ge),et),Q.start(qe.scene,qe.camera,e=>{let t=$.advance(e);qe.update(t),Y.dataset.waterTime=t.toFixed(6),Y.dataset.sceneTime=t.toFixed(6)}),Qe($.state),tt(),We.addEventListener(`click`,()=>{$.toggle(),X.textContent=$.state.playing?`场景动效已继续。`:`场景动效已暂停。`},{signal:Je.signal});for(let e of Ue)e.addEventListener(`click`,()=>{Z=e.dataset.mode,Q?.setMode(Z);let t=new URL(window.location.href);Z===z.defaultMode?t.searchParams.delete(`render`):t.searchParams.set(`render`,Z),window.history.replaceState(null,``,t),tt()},{signal:Je.signal})}catch(e){Q?.dispose(),qe.dispose(),Y.dataset.renderState=`error`;let t=document.createElement(`p`);t.className=`render-error`,t.setAttribute(`role`,`alert`),t.textContent=`场景暂时无法显示，请开启浏览器图形加速后刷新页面。`,Y.replaceChildren(t);for(let e of Ue)e.disabled=!0;We.disabled=!0,$.dispose(),X.textContent=`场景初始化失败。`,console.error(`Scene initialization failed.`,e)}