# sakan / 张辰翰 庭院网页

当前候选：`garden-enhancement-step7-487410d10d8ad600`。

先阅读[快速上手](QUICKSTART.md)。Windows修改用START-DEV.cmd，已有构建的预览用START-PREVIEW.cmd；Node建议LTS24。

[维护说明](docs/garden-enhancement/maintenance.md) · [交付说明](docs/garden-enhancement/delivery.md)。

源码可独立安装、严格构建和运行；当前报告与基线在单独evidence包，完整历史套件的fixture需求见维护说明。未包含node_modules、Git历史、凭据或浏览器用户目录。本包没有自动提交Git、推送或上线。
