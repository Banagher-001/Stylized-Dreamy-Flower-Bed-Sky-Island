# 张辰翰 · 创作庭院

解压整个压缩包，在安装了 Node.js 的电脑上打开。项目最低支持 Node.js 22.12，可用 Node.js 24 LTS。

Windows 双击 `START-PREVIEW.cmd`。也可以在解压目录的终端里运行以下命令，从终端显示的地址进入网页。

```sh
node scripts/preview-site.mjs --open
```

预览使用本机 HTTP 地址，保留终端窗口即可继续浏览。进入「交互实验」后，使用窗口顶部的两个标签切换罗森便利店和瓶中海洋。鼠标或触屏在场景里操作原画布，移到窗外继续浏览庭院。
