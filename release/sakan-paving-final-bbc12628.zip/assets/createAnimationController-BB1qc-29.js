import{A as e,An as t,E as n,F as r,G as i,I as a,J as o,L as s,Nn as c,Qt as l,R as u,T as d,X as f,Y as p,Z as m,_ as h,_n as g,a as _,at as v,cn as y,dn as b,dt as x,et as S,f as C,fn as w,ft as T,gn as E,hn as D,jn as O,k,kn as A,mn as j,nt as M,o as N,ot as P,q as F,r as I,st as ee,u as te,un as ne,ut as re,w as ie,xn as ae,z as L}from"./three-core-DPe5a74I.js";import{t as oe}from"./three-renderer-DlsPB-zU.js";var R={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},se={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`};R.grassBase,R.stoneLight,R.stoneShade,R.treeShadow,R.waterBase,R.flower;var ce=new URL(`courtyard-motion-7fR7fsF8.mp4`,import.meta.url).href,le=new URL(`courtyard-keyframe-00-Dnvt_afN.png`,import.meta.url).href,ue=new URL(`courtyard-keyframe-03-BpIvPl5V.png`,import.meta.url).href,de=new URL(`signal-garden-CbiDrnMk.webp`,import.meta.url).href,fe=new URL(`liquid-form-Yl5oqdSL.webp`,import.meta.url).href,z={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},pe={defaultMode:`pixel`,maxDevicePixelRatio:2},B={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},V={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},column:{layerRatios:[1.07,.96,1.03,.94],layerSeeds:[11,29,47],layerChips:[0,.028,.052],baseBevel:.024,capBevel:.038,profiles:[{layers:[0,1,0,2],offsets:[-.012,.012,-.008,0],capCorner:2,capChip:.12},{layers:[1,2,0,1],offsets:[.008,-.01,.01,0],capCorner:1,capChip:.095},{layers:[2,0,1,0],offsets:[-.008,.012,-.008,0],capCorner:3,capChip:.145}]},fountain:{copingHeight:.14,jointWidth:.032,bevel:.024,chippedSegments:[1,5],chipSize:.1},wall:{bodyBlocks:3,capBlocks:2}},H={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25],pavingReserve:{x:[3.905,6.755],z:[.805,1.955]}},grass:{count:240,pavingTufts:[{center:[-.773,-.078],height:.076},{center:[-.745075,.004656],height:.064},{center:[-.375382,.001139],height:.07},{center:[-.002447,-.311354],height:.061},{center:[.734412,-.003957],height:.068}],minHeight:.065,maxHeight:.14,clearance:.06,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},U={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function me(e){return{enabled:e.get(`env`)!==`off`&&U.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||U.petals.enabled}}var W={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function he(e={}){let t={...me(new URLSearchParams),...e};return{options:t,time:{value:W.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function ge(e,t){let n=Math.sin(e*12.9898+t*78.233+U.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var _e=Math.hypot(...U.wind.direction),ve=[U.wind.direction[0]/_e,U.wind.direction[1]/_e],G=e=>e.toFixed(10),ye=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${ve.map(G).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,be=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function xe(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${ye}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${be}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${G(U.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${G(U.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function Se(e,t,n={}){let r=new S,i=e===`foliage`||e===`flower`;r.name=`courtyard-${e}`,r.userData.artSurface=e;let a=t?.options.enabled&&(i||e===`ground`);return r.customProgramCacheKey=()=>`courtyard-art-${e}-v3${a?`-environment-v1`:``}`,r.onBeforeCompile=r=>{let o=B.treeShadows,s=H.ground,c=H.treeDetail;Object.assign(r.uniforms,{uArtSunAmount:{value:B.sun.intensity},uArtFillAmount:{value:B.fill.intensity},uArtStoneVariation:{value:V.colorVariation},uArtGrass:{value:new C(R.grassBase)},uArtGrassLight:{value:new C(R.grassLight)},uArtGrassDark:{value:new C(R.grassDark)},uArtGrassShadow:{value:new C(R.treeShadow)},uArtStoneTop:{value:new C(n.top??R.stoneLight)},uArtStoneSide:{value:new C(n.side??R.stoneSide)},uArtStoneShade:{value:new C(n.shade??R.stoneShade)},uArtWater:{value:new C(R.waterBase)},uArtWaterShade:{value:new C(R.waterShade)},uArtPlantShade:{value:new C(R.plantShade)},uArtFlowerShade:{value:new C(R.flowerShade)},uArtFlowerCenter:{value:new C(R.flowerCenter)},uArtGroundEnabled:{value:+!!s.enabled},uArtGroundScales:{value:new O(s.macroScale,s.macroStrength,s.detailScale,s.detailStrength)},uArtGroundDensity:{value:s.detailDensity},uArtQuietRegion:{value:new O(s.quietCenter[0],s.quietCenter[1],s.quietRadius[0],s.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!c.enabled},uArtTreeDetail:{value:new O(c.branchScale,c.leafScale,c.edgeBreakup,c.gapStrength)},uArtTreesEnabled:{value:+!!o.enabled},uArtTreeNoiseScale:{value:o.edgeNoiseScale},uArtTreeNoiseAmount:{value:o.edgeNoiseAmount},uArtTreeSoftness:{value:o.edgeSoftness},uArtTreePatches:{value:o.patches.map(e=>new O(e.center[0],e.center[1],e.radius[0],e.radius[1]))},uArtTreeRotations:{value:o.patches.map(e=>e.rotation)}}),r.vertexShader=r.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${e===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${i?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${e===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${i?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let l=`
      varying vec3 vArtWorldPosition;
      ${e===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${i?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${o.patches.length}];
      uniform float uArtTreeRotations[${o.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${o.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;r.fragmentShader=r.fragmentShader.replace(`#include <common>`,`#include <common>\n${l}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
        #ifdef USE_COLOR
          outgoingLight *= diffuseColor.rgb;
        #endif
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[e]}\n#include <opaque_fragment>`),a&&xe(r,i,t)},r}function Ce(e){return Se(`ground`,e)}var K={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08,baseHeight:.18,shaftWidth:.72,shaftDepth:.78,shaftHeight:3.05,capWidth:1.02,capDepth:1.04,capHeight:.24},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,stones:[{id:`A`,center:[-1.055,-.355],width:.34,depth:.33,rotationDegrees:12,cuts:[.073,.019,.053,.025],profile:{exposedHeight:.085,embeddedDepth:.014,bevel:.011,chipVertex:7,chipSize:.062}},{id:`B`,center:[-1.111,.205],width:.66,depth:.44,rotationDegrees:-7,cuts:[.025,.064,.036,.049],profile:{exposedHeight:.093,embeddedDepth:.016,bevel:.014,chipVertex:5,chipSize:.079}},{id:`C`,center:[-.465,-.275],width:.45,depth:.33,rotationDegrees:-9,cuts:[.058,.021,.047,.032],profile:{exposedHeight:.078,embeddedDepth:.017,bevel:.009,chipVertex:0,chipSize:.035}},{id:`D`,center:[-.381,.305],width:.59,depth:.43,rotationDegrees:6,cuts:[.033,.055,.023,.071],profile:{exposedHeight:.096,embeddedDepth:.015,bevel:.013,chipVertex:5,chipSize:.044}},{id:`E`,center:[.207,-.014],width:.31,depth:.69,rotationDegrees:-16,cuts:[.028,.068,.015,.053],profile:{exposedHeight:.088,embeddedDepth:.014,bevel:.01,chipVertex:1,chipSize:.061}},{id:`F`,center:[.765,-.259],width:.51,depth:.32,rotationDegrees:10,cuts:[.066,.022,.055,.031],profile:{exposedHeight:.076,embeddedDepth:.018,bevel:.008,chipVertex:2,chipSize:.027}},{id:`G`,center:[.659,.279],width:.53,depth:.4,rotationDegrees:-9,cuts:[.019,.059,.041,.072],profile:{exposedHeight:.09,embeddedDepth:.015,bevel:.012,chipVertex:4,chipSize:.049}},{id:`H`,center:[1.237,.17],width:.43,depth:.41,rotationDegrees:8,cuts:[.053,.028,.073,.021],profile:{exposedHeight:.084,embeddedDepth:.015,bevel:.011,chipVertex:3,chipSize:.075}}]}},we={base:`#7C9955`,light:`#9AAE65`,edge:`#5C7746`},Te={A:{anchor:[-.09,-.09],lobes:[{outline:[[-.041,.015],[-.035,-.009],[-.026,-.024],[-.012,-.021],[-.004,-.034],[.03,-.038],[.052,-.029],[.048,-.014],[.064,-.002],[.056,.015],[.032,.021],[.022,.036],[.002,.032],[-.008,.043],[-.031,.034]],peak:[.012,.005],rise:.016,rim:.0045},{outline:[[.049,.021],[.061,.005],[.076,.008],[.088,.014],[.084,.03],[.069,.033],[.053,.03]],peak:[.068,.019],rise:.011,rim:.004},{outline:[[.028,.04],[.038,.032],[.051,.033],[.054,.042],[.045,.046],[.032,.045]],peak:[.041,.039],rise:.009,rim:.003}]},C:{anchor:[-.09,-.095],lobes:[{outline:[[-.05,-.009],[-.039,-.024],[-.018,-.028],[-.004,-.018],[.015,-.032],[.035,-.025],[.044,-.009],[.039,.002],[.05,.012],[.035,.032],[.012,.027],[-.003,.017],[-.024,.031],[-.041,.023]],peak:[-.006,-.003],rise:.011,rim:.004},{outline:[[.027,-.023],[.039,-.03],[.05,-.024],[.059,-.013],[.057,-.002],[.044,.003],[.031,-.005]],peak:[.043,-.014],rise:.008,rim:.003}]},E:{anchor:[.054,-.26],lobes:[{outline:[[-.04,-.042],[-.022,-.049],[-.012,-.038],[.017,-.045],[.027,-.032],[.021,-.006],[.038,.009],[.029,.032],[.015,.043],[.017,.062],[0,.077],[-.018,.079],[-.03,.06],[-.026,.048],[-.031,.029],[-.049,.008],[-.048,-.013]],peak:[-.006,.014],rise:.015,rim:.0045},{outline:[[-.02,.084],[-.015,.066],[.008,.074],[.026,.089],[.031,.109],[.023,.122],[.004,.126],[-.014,.111],[-.016,.102]],peak:[.006,.101],rise:.01,rim:.0035},{outline:[[-.044,.022],[-.039,.012],[-.029,.011],[-.021,.021],[-.031,.038],[-.042,.035]],peak:[-.033,.024],rise:.009,rim:.003}]},F:{anchor:[.135,-.096],lobes:[{outline:[[-.045,-.013],[-.037,-.024],[-.014,-.027],[.004,-.017],[.022,-.028],[.039,-.016],[.048,-.004],[.039,.006],[.044,.019],[.026,.028],[.007,.021],[-.016,.025],[-.03,.014],[-.043,.008]],peak:[.001,-.001],rise:.0095,rim:.0035}]}},q=1e-7;function Ee(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<q*q)||t.push(n);return t}function De(e,n,r){let i=[],a=[];for(let t of e){let e=[];for(let i=0;i<t.length;i++){let o=t[i],s=t[(i+1)%t.length],c=n.dot(o)-r,l=n.dot(s)-r;if(c<=q&&e.push(o),c<-1e-7&&l>q||c>q&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),a.push(t)}else Math.abs(c)<=q&&a.push(o)}let o=Ee(e);o.length>=3&&i.push(o)}let o=Ee(a);if(o.length>=3){let e=o.reduce((e,t)=>e.add(t),new t).divideScalar(o.length),r=Math.abs(n.y)<.9?new t(0,1,0):new t(1,0,0),a=n.clone().cross(r).normalize(),s=n.clone().cross(a).normalize();o.sort((t,n)=>{let r=t.clone().sub(e),i=n.clone().sub(e);return Math.atan2(r.dot(s),r.dot(a))-Math.atan2(i.dot(s),i.dot(a))}),i.push(o)}return i}function Oe(t,n){let r=t.getAttribute(`position`),i=Math.sin(n*12.9898+.73)*.65,a=new Float32Array(r.count);for(let e=0;e<r.count;e++)a[e]=i+Math.sin(r.getX(e)*1.6+r.getZ(e)*2.3+n)*.25;return t.setAttribute(`stoneTint`,new e(a,1)),t}function ke(n,r,i){if(n.length<3||r<=0)throw Error(`Stone prism needs a polygon and positive height.`);let a=n.map(([e,t])=>[e,t]);a.reduce((e,t,n)=>{let r=a[(n+1)%a.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(a=a.reverse());let o=r/2,s=a.map(([e,n])=>new t(e,o,n)),c=a.map(([e,n])=>new t(e,-o,n)),l=[s,[...c].reverse()],u=[];for(let e=0;e<a.length;e++){let n=(e+1)%a.length,r=c[e],i=c[n];l.push([r,i,s[n],s[e]]);let o=i.clone().sub(r).cross(new t(0,1,0)).normalize();u.push({normal:o,distance:o.dot(r)})}let d=Math.min(i.bevel,r*.2);for(let e=0;e<u.length;e++){let n=u[e];for(let e of[-1,1]){let r=n.normal.clone().add(new t(0,e,0)),i=(n.distance+o-d)/r.length();l=De(l,r.normalize(),i)}let r=u[(e+u.length-1)%u.length],a=r.normal.clone().add(n.normal),s=(r.distance+n.distance-i.cornerCut)/a.length();l=De(l,a.normalize(),s)}if(i.chipSize&&i.chipSize>0){let e=(i.chipCorner??0)%u.length,n=u[(e+u.length-1)%u.length],r=u[e],a=n.normal.clone().add(r.normal).add(new t(0,1,0)),s=(n.distance+r.distance+o-i.chipSize)/a.length();l=De(l,a.normalize(),s)}let f=[],p=[];for(let e of l){let n=e.reduce((e,t)=>e.add(t),new t).divideScalar(e.length),r=new t;for(let t=0;t<e.length;t++)r.add(e[t].clone().sub(n).cross(e[(t+1)%e.length].clone().sub(n)));if(!(r.lengthSq()<q*q)){r.normalize();for(let t=0;t<e.length;t++){let i=e[t],a=e[(t+1)%e.length];if(!(i.clone().sub(n).cross(a.clone().sub(n)).lengthSq()<q*q))for(let e of[n,i,a])f.push(e.x,e.y,e.z),p.push(r.x,r.y,r.z)}}}let m=new N;return m.setAttribute(`position`,new e(f,3)),m.setAttribute(`normal`,new e(p,3)),Oe(m,i.seed),m.computeBoundingBox(),m.computeBoundingSphere(),m.userData.stoneSolid=!0,m}function Ae(e,t,n,r){let i=e/2,a=n/2;return ke([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}var je=new C(we.base),Me=new C(we.light),Ne=new C(we.edge);function Pe(n,r){let i=n.getAttribute(`position`),a=n.getAttribute(`normal`),[o,s]=r.anchor,c=new l(new t,new t(0,-1,0)),u=new t,d=new t,f=new t,p=new t;function m([e,r]){c.origin.set(o+e,(n.boundingBox?.max.y??0)+1,s+r);let l,m=0;for(let e=0;e<i.count;e+=3)u.fromBufferAttribute(i,e),d.fromBufferAttribute(i,e+1),f.fromBufferAttribute(i,e+2),c.intersectTriangle(u,d,f,!0,p)&&(!l||p.y>l.y)&&((l??=new t).copy(p),m=e);return l?{point:l,normal:new t().fromBufferAttribute(a,m)}:void 0}let h=[],g=[];function _(e,t,n,r,i,a){h.push(e.x,e.y,e.z,t.x,t.y,t.z,n.x,n.y,n.z),g.push(r.r,r.g,r.b,i.r,i.g,i.b,a.r,a.g,a.b)}for(let e of r.lobes){let t=m(e.peak),n=[...e.outline].reverse().map(m);if(!t||n.some(e=>!e))continue;let r=n.map(e=>e.point),{normal:i}=t,a=i.dot(t.point);if(r.some(e=>Math.abs(i.dot(e)-a)>1e-5))continue;let o=t.point.clone().addScaledVector(i,-.002),s=t.point.clone().addScaledVector(i,e.rise),c=r.map(e=>e.clone().addScaledVector(i,-.002)),l=r.map((t,n)=>t.clone().addScaledVector(i,e.rim+n%3*.001)),u=r.map((e,t)=>je.clone().lerp(Me,t%4*.1));for(let e=0;e<r.length;e++){let t=(e+1)%r.length;_(s,l[e],l[t],Me,u[e],u[t]),_(o,c[t],c[e],Ne,Ne,Ne),_(c[e],c[t],l[t],Ne,Ne,u[t]),_(c[e],l[t],l[e],Ne,u[t],u[e])}}if(!h.length)return;let v=new N;return v.setAttribute(`position`,new e(h,3)),v.setAttribute(`color`,new e(g,3)),v.computeVertexNormals(),v.computeBoundingSphere(),Oe(v,19)}function Fe(e){return Se(`stone`,void 0,e)}function Ie(){return{time:{value:W.initialTime},impacts:{value:Array.from({length:W.ripples.capacity},()=>new O(0,0,0,0))}}}function Le(e=Ie(),t=`surface`){let n=Se(`water`);n.name=`courtyard-water-${t}`,n.flatShading=t===`jet`,n.userData.waterKind=t,n.customProgramCacheKey=()=>`courtyard-water-${t}-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=K.fountain;Object.assign(n.uniforms,{uWaterTime:e.time,uWaterImpacts:e.impacts,uWaterEnabled:{value:+!!W.enabled},uWaterBase:{value:new C(W.colors.base)},uWaterDeep:{value:new C(W.colors.deep)},uWaterShade:{value:new C(W.colors.shade)},uWaterWhite:{value:new C(W.colors.highlight)},uWaterJet:{value:new C(W.colors.jet)},uWaterOrigin:{value:new O(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uWaterSurface:{value:new O(W.surface.flowSpeed,W.surface.reflectionThreshold,W.surface.waveSpeed,W.surface.waveStrength)},uWaterRipple:{value:new O(W.ripples.lifetime,W.ripples.speed,W.ripples.strength,a.innerRadius*Math.cos(Math.PI/8))}});let o=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${W.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,c=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(c))throw Error(`Water shader extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(c,t===`surface`?s:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},n}var Re=K.path,ze=Math.cos(Re.rotationY),Be=Math.sin(Re.rotationY);function Ve(e,t){return[Re.position[0]+ze*e+Be*t,Re.position[2]-Be*e+ze*t]}var He=Re.stones.map(e=>{let t=e.width/2,n=e.depth/2,[r,i,a,o]=e.cuts,s=[[-t+r,-n],[t-i,-n],[t,-n+i],[t,n-a],[t-a,n],[-t+o,n],[-t,n-o],[-t,-n+r]],c=e.rotationDegrees*Math.PI/180,l=Math.cos(c),u=Math.sin(c),[d,f]=e.center,p=s.map(([e,t])=>Ve(d+l*e+u*t,f-u*e+l*t)),m=p.map(([e])=>e),h=p.map(([,e])=>e),g={minX:Math.min(...m),maxX:Math.max(...m),minZ:Math.min(...h),maxZ:Math.max(...h)};return{id:e.id,center:e.center,profile:e.profile,rotationY:c,outline:s,worldOutline:p,bounds:g}});function Ue(e,t,n){let r=n**2;for(let{worldOutline:i,bounds:a}of He){if(e<a.minX-n||e>a.maxX+n||t<a.minZ-n||t>a.maxZ+n)continue;let o=!0;for(let n=0;n<i.length;n++){let[a,s]=i[n],[c,l]=i[(n+1)%i.length],u=c-a,d=l-s,f=e-a,p=t-s;u*p-d*f<0&&(o=!1);let m=(f*u+p*d)/(u*u+d*d),h=Math.max(0,Math.min(1,m));if((f-u*h)**2+(p-d*h)**2<=r)return!1}if(o)return!1}return!0}function We(e){let t=new r;t.name=`courtyard-blockout`;let n=new Set;function i(e){return n.add(e),e}let a=new Map,o=Fe(),s=Fe({top:`#FFFFFF`,side:`#E5EBDC`,shade:`#88A29A`});s.name=`courtyard-paving-moss`,s.vertexColors=!0;let c=Le(e);function l(e,t,n,r,s,c,l=0,u=0,d={}){let p={bevel:V.bevel,cornerCut:V.cornerCut,seed:11,...d},m=JSON.stringify([n,r,s,p]),h=a.get(m);h||(h=i(Ae(n,r,s,p)),a.set(m,h));let g=new f(h,o);return g.name=t,g.position.set(l,c+r/2,u),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let u=K.fountain,d=new r;d.name=`fountain`,d.position.set(...u.position),d.rotation.y=u.rotationY,t.add(d);let p=new f(i(ke(Array.from({length:8},(e,t)=>[Math.cos(t*Math.PI/4)*u.baseRadius,-Math.sin(t*Math.PI/4)*u.baseRadius]),u.baseHeight,{bevel:.018,cornerCut:.025,seed:11})),o);p.name=`fountain-base`,p.position.y=u.baseHeight/2,p.castShadow=!0,p.receiveShadow=!0,d.add(p);let m=new w,h=new ee;for(let e=0;e<8;e++){let t=e*Math.PI/4,n=-t,r=Math.cos(t)*u.outerRadius,i=Math.sin(t)*u.outerRadius,a=Math.cos(n)*u.innerRadius,o=Math.sin(n)*u.innerRadius;e===0?(m.moveTo(r,i),h.moveTo(a,o)):(m.lineTo(r,i),h.lineTo(a,o))}m.closePath(),h.closePath(),m.holes.push(h);let g=new r;g.name=`fountain-rim`,g.position.y=u.baseHeight,d.add(g);let _=V.fountain,v=u.rimHeight-_.copingHeight,y=new f(i(Oe(new k(m,{depth:v,bevelEnabled:!1,steps:1,curveSegments:1}),11)),o);y.name=`fountain-rim-wall`,y.rotation.x=-Math.PI/2,y.castShadow=!0,y.receiveShadow=!0,g.add(y);function b(e){let t=Math.cos(Math.PI/4)*e,n=-Math.sin(Math.PI/4)*e,r=_.jointWidth/(2*Math.hypot(t-e,n));return[[e+(t-e)*r,n*r],[t+(e-t)*r,n*(1-r)]]}let[x,S]=b(u.outerRadius),[C,T]=b(u.innerRadius),E=new Map;for(let e=0;e<8;e++){let t=_.chippedSegments.some(t=>t===e),n=t?`chip-${e%2}`:`plain-${e%2}`,r=E.get(n);r||(r=i(ke([x,S,T,C],_.copingHeight,{bevel:_.bevel,cornerCut:.025,seed:29+e%2,chipSize:t?_.chipSize:0,chipCorner:e%2})),E.set(n,r));let a=new f(r,o);a.name=`fountain-coping-${e}`,a.position.y=v+_.copingHeight/2,a.rotation.y=e*Math.PI/4,a.castShadow=!0,a.receiveShadow=!0,g.add(a)}let D=new f(i(new te(u.innerRadius-.008,8)),c);D.name=`fountain-water`,D.rotation.x=-Math.PI/2,D.position.y=u.waterHeight,D.receiveShadow=!0,d.add(D),l(d,`fountain-pedestal-foot`,u.pedestalFootSize,u.pedestalFootHeight,u.pedestalFootSize,u.baseHeight);let O=u.baseHeight+u.pedestalFootHeight;l(d,`fountain-pedestal`,u.pedestalSize,u.pedestalHeight,u.pedestalSize,O),l(d,`fountain-pedestal-cap`,u.pedestalCapSize,u.pedestalCapHeight,u.pedestalCapSize,O+u.pedestalHeight,0,0,{bevel:.016,chipSize:.06,chipCorner:2,seed:29});let A=K.columnShape;for(let[e,n]of K.columns.entries()){let i=new r;i.name=n.name;let[a,o,s]=n.position;i.position.set(a,o,s),i.rotation.y=n.rotationY;let c=V.column,u=c.profiles[e];l(i,`${n.name}-base`,A.baseWidth,A.baseHeight,A.baseDepth,0,0,0,{bevel:c.baseBevel,chipSize:.04,chipCorner:e%2,seed:29});let d=new r;d.name=`${n.name}-shaft`,i.add(d);let f=V.joints.width,p=c.layerRatios,m=A.shaftHeight-f*(p.length-1),h=p.reduce((e,t)=>e+t,0),g=A.baseHeight;for(let e=0;e<p.length;e++){let t=m*p[e]/h,r=u.layers[e];l(d,`${n.name}-block-${e}`,A.shaftWidth,t,A.shaftDepth,g,u.offsets[e],0,{seed:c.layerSeeds[r],chipSize:c.layerChips[r],chipCorner:r}),g+=t,e<p.length-1&&(l(d,`${n.name}-joint-${e}`,A.shaftWidth-V.joints.recess*2,f,A.shaftDepth-V.joints.recess*2,g,0,0,{bevel:0,cornerCut:0,seed:47}),g+=f)}l(i,`${n.name}-cap`,A.capWidth,A.capHeight,A.capDepth,A.baseHeight+A.shaftHeight,0,0,{bevel:c.capBevel,chipSize:u.capChip,chipCorner:u.capCorner,seed:47+e}),t.add(i)}let j=K.wall,M=new r;M.name=`wallLeft`,M.position.set(...j.position),M.rotation.y=j.rotationY,l(M,`wallLeft-base`,j.length+j.endSize,j.baseHeight,j.baseDepth,0);let N=new r;N.name=`wallLeft-body`,M.add(N);let P=V.wall.bodyBlocks,F=V.joints.width,I=(j.length-(P-1)*F)/P;for(let e=0;e<P;e++){let t=-j.length/2+I/2+e*(I+F);l(N,`wallLeft-body-${e}`,I,j.height,j.depth,j.baseHeight,t,0,{seed:11+e*18,chipSize:e===P-1?.075:0,chipCorner:2}),e<P-1&&l(N,`wallLeft-body-joint-${e}`,F,j.height,j.depth-V.joints.recess*2,j.baseHeight,t+I/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}let ne=new r;ne.name=`wallLeft-cap`,M.add(ne);let re=V.wall.capBlocks,ie=(j.length-(re-1)*F)/re;for(let e=0;e<re;e++){let t=-j.length/2+ie/2+e*(ie+F);l(ne,`wallLeft-cap-${e}`,ie,j.capHeight,j.capDepth,j.baseHeight+j.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===re-1?.065:0,chipCorner:2}),e<re-1&&l(ne,`wallLeft-cap-joint-${e}`,F,j.capHeight*.65,j.capDepth-V.joints.recess*2,j.baseHeight+j.height,t+ie/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}l(M,`wallLeft-end`,j.endSize,j.endHeight,j.endSize,j.baseHeight,j.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(M);let ae=K.path,L=new r;L.name=`pathRight`,L.position.set(...ae.position),L.rotation.y=ae.rotationY,He.forEach((e,t)=>{let{outline:n,profile:r}=e,{exposedHeight:a,embeddedDepth:c,bevel:l,chipVertex:u,chipSize:d}=r,p=-c,m=i(ke(n,a-p,{bevel:l,cornerCut:0,seed:11+9*t,chipCorner:n.length-1-u,chipSize:d})),h=new f(m,o);h.name=`pathRight-slab-${e.id}`,h.position.set(e.center[0],(a+p)/2,e.center[1]),h.rotation.y=e.rotationY,h.castShadow=!0,h.receiveShadow=!0,L.add(h);let g=Te[e.id],_=g&&Pe(m,g);if(_){let t=new f(i(_),s);t.name=`pathRight-moss-${e.id}`,t.castShadow=!0,t.receiveShadow=!0,h.add(t)}}),t.add(L);let oe=!1;return{root:t,dispose(){if(!oe){oe=!0,t.removeFromParent(),t.clear();for(let e of n)e.dispose();o.dispose(),s.dispose(),c.dispose()}}}}function Ge(t,n,r){let i=new N;return i.setAttribute(`position`,new e(t,3)),i.setAttribute(`plantPart`,new e(n,1)),i.setAttribute(`plantHeight`,new e(r,1)),i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function Ke(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>Ge(e,t,n)}}function qe(){let e=Ke();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function Je(){let e=Ke();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function Ye(e){let t=Ke();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function Xe(e,t){let n=Se(e,t);return n.side=2,n}var Ze=.035;function Qe(e,t,n,r){let i=K.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=K.columnShape;for(let n of K.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=K.wall;return!f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY)}function $e(e,t,n,r=Ze){return Qe(e,t,n,r)&&Ue(e,t,n+r)}function et(e,t,n){let r=H.ground.pavingReserve,i=n+Ze;return!(e>r.x[0]-i&&e<r.x[1]+i&&t>r.z[0]-i&&t<r.z[1]+i)&&Qe(e,t,n,Ze)}function tt(e,n){let i=new r;i.name=`courtyard-vegetation`;let a=H.seed;function o(){a+=1831565813;let e=Math.imul(a^a>>>15,1|a);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let s=(e,t)=>e+(t-e)*o();function c(n,r){let i=new t(n,0,r).project(e);return Math.abs(i.x)<.98&&Math.abs(i.y)<.98}function l(e,t){let n=H.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let d=[],f=[];if(H.enabled){for(let e=0;d.length<H.grass.count&&e<H.grass.count*120;e++){let e,t;if(o()<.48){let n=H.flowers.clusters[Math.floor(o()*H.flowers.clusters.length)],r=o()*Math.PI*2,i=Math.sqrt(o())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=s(-7.5,7.4),t=s(-8.7,8.4);!c(e,t)||!et(e,t,H.grass.clearance)||l(e,t)&&o()<.9||d.push({x:e,z:t,height:s(H.grass.minHeight,H.grass.maxHeight),diameter:0,rotation:o()*Math.PI*2,color:o(),radius:H.grass.clearance,gap:!1})}for(let e=0;f.length<H.flowers.count&&e<H.flowers.count*120;e++){let e=H.flowers.clusters[Math.floor(o()*H.flowers.clusters.length)],t=o()*Math.PI*2,n=o()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,a=s(H.flowers.minDiameter,H.flowers.maxDiameter),u=a*.55+.01;c(r,i)&&!l(r,i)&&et(r,i,u)&&(f.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+u)*.85)||f.push({x:r,z:i,height:s(H.flowers.minHeight,H.flowers.maxHeight),diameter:a,rotation:o()*Math.PI*2,color:o(),radius:u,gap:!1}))}if(d.length!==H.grass.count||f.length!==H.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=.023;for(let{center:t,height:n}of H.grass.pavingTufts){let[r,i]=Ve(t[0],t[1]);$e(r,i,e,.037)&&d.push({x:r,z:i,height:n,diameter:0,rotation:o()*Math.PI*2,color:o(),radius:e,gap:!0})}}let m=e=>Ue(e.x,e.z,e.radius+Ze),h=d.filter(e=>e.gap||m(e)),g=f.filter(m),_=[],v=[],y=[];if(H.enabled){let e=Xe(`foliage`,n),r=Xe(`flower`,n);v.push(e,r);let a=qe(),o=Je(),s=Ye(4),c=Ye(5);_.push(a,o,s,c);function l(e,r,a,o,s){let c=new L(r,a,o.length);c.name=e,c.castShadow=!1,c.receiveShadow=!0;let l=new p,d=new T,f=new t(0,1,0),m=new C(s===`flower`?R.flower:s===`stem`?R.plantStem:R.grassBlade),h=new C(s===`flower`?R.flowerLight:R.grassBladeLight);if(o.forEach((e,n)=>{d.setFromAxisAngle(f,e.rotation);let r=s===`flower`?e.diameter:e.height,i=s===`grass`&&e.gap?H.grass.gapWidthScale:1;l.compose(new t(e.x,H.rootHeight+(s===`flower`?e.height:0),e.z),d,new t(r*i,r,r*i)),c.setMatrixAt(n,l),c.setColorAt(n,m.clone().lerp(h,s===`stem`?e.color*.25:s===`flower`?e.color*.6:e.color*.85))}),c.instanceMatrix.needsUpdate=!0,c.instanceColor&&(c.instanceColor.needsUpdate=!0),n?.options.enabled){let e=new Float32Array(o.length*3),t=new Float32Array(o.length*4);o.forEach((n,r)=>{let i=s===`grass`?n.gap?U.wind.gapAngle:U.wind.grassAngle:U.wind.flowerAngle;e.set([n.x,H.rootHeight,n.z],r*3),t.set([n.height,i,ge(n.x,n.z),+(s===`flower`)],r*4)}),r.setAttribute(`windRoot`,new u(e,3)),r.setAttribute(`windShape`,new u(t,4))}c.computeBoundingBox(),c.computeBoundingSphere(),n?.options.enabled&&(c.boundingBox.expandByScalar(.02),c.boundingSphere.radius+=.02),c.userData.plants=o,c.userData.plantType=s,y.push(c),i.add(c)}l(`grass-clusters`,a,e,h,`grass`),l(`flower-stems`,o,e,g,`stem`),l(`flowers-four-petal`,s,r,f.filter((e,t)=>t%2==0&&m(e)),`flower`),l(`flowers-five-petal`,c,r,f.filter((e,t)=>t%2==1&&m(e)),`flower`)}i.userData.seed=H.seed,i.userData.counts={grass:h.length,flowers:g.length,batches:y.length};let b=!1;return{root:i,dispose(){if(!b){b=!0;for(let e of y)e.dispose();for(let e of _)e.dispose();for(let e of v)e.dispose();i.removeFromParent(),i.clear()}}}}var nt={primary:{amplitude:.032,period:4,direction:[2.5,2,-1.55]},secondary:{amplitude:.008,period:2.6,direction:[-3.1,1.2,4.4]},stemFade:[-.84,-.48],interiorFollow:.25},J={axis:[.766434,-.575767,.28473],front:[.330778,.733779,.593426],offset:-.306825,frontTime:3.5,crestWidth:[.056,.167],backWeight:.3,colors:{crest:`#E2F5FB`,shade:`#4C8BAE`}},rt={clearance:.02,beads:[{direction:[-.82,-.26,.51],phase:.36,formationTime:.16,radius:.024,speed:.84,vy:-.06,strength:1.6},{direction:[-.74,-.25,.62],phase:.88,formationTime:.14,radius:.019,speed:.81,vy:-.06,strength:1.12}]},Y={radius:.26,centerY:1.37,floatAmplitude:.03,floatPeriod:6,sphereSegments:[12,8],shape:{first:.025,second:.009,x:.012,y:.015,z:.012,yRatio:.96,envelope:(1.025+.009)*1.012},flow:{mainPeriod:7.2,detailPeriod:4.1,turnPeriod:23,main:[2.2,7.4,.8],bend:[3.2,0,2],bendStrength:.8,detail:[2.1,-3,7]},stemRadius:.04,stemOverlap:.025,releaseLatitude:-.16,releaseMargin:.004,colors:{base:`#80B9D5`,light:`#ADDCE8`,side:`#4D89B2`,shade:`#427192`,white:`#F3FBFF`}},it=Math.PI*2,X=Y.flow,at=(e,t)=>(e%t+t)%t/t*it;function ot(e,t=new O){let n=at(e,X.turnPeriod);return t.set(Math.cos(n),Math.sin(n),at(e,X.mainPeriod),at(e,X.detailPeriod))}function st(e,t,n,r){let i=r.x*e-r.y*n,a=r.y*e+r.x*n,o=i*X.bend[0]+t*X.bend[1]+a*X.bend[2]+r.w,s=i*X.main[0]+t*X.main[1]+a*X.main[2]+X.bendStrength*Math.sin(o)+r.z,c=i*X.detail[0]+t*X.detail[1]+a*X.detail[2]-r.w;return 1+Y.shape.first*Math.cos(s)+Y.shape.second*Math.sin(c)}function ct(e,n,r,i,a=new t){let o=i.x*e-i.y*r,s=i.y*e+i.x*r,c=o*X.bend[0]+n*X.bend[1]+s*X.bend[2]+i.w,l=o*X.main[0]+n*X.main[1]+s*X.main[2]+X.bendStrength*Math.sin(c)+i.z,u=o*X.detail[0]+n*X.detail[1]+s*X.detail[2]-i.w,d=-Y.shape.first*Math.sin(l),f=Y.shape.second*Math.cos(u),p=X.bendStrength*Math.cos(c),m=d*(X.main[0]+p*X.bend[0])+f*X.detail[0],h=d*(X.main[1]+p*X.bend[1])+f*X.detail[1],g=d*(X.main[2]+p*X.bend[2])+f*X.detail[2],_=i.x*m+i.y*g,v=-i.y*m+i.x*g,y=1+Y.shape.first*Math.cos(l)+Y.shape.second*Math.sin(u),b=e*_+n*h+r*v;return a.set(e-(_-e*b)/y,n-(h-n*b)/y,r-(v-r*b)/y).normalize()}var lt=Math.PI*2/Y.floatPeriod,ut=()=>({y:0,sx:1,sy:1,sz:1});function dt(e,t=ut()){let n=e*lt;return t.y=Y.centerY+Y.floatAmplitude*Math.sin(n),t.sx=1+Y.shape.x*Math.sin(n*.73),t.sy=Y.shape.yRatio*(1+Y.shape.y*Math.sin(n+.8)),t.sz=1+Y.shape.z*Math.cos(n*.81),t}var ft=()=>({birthTime:NaN,x:0,y:0,z:0,vx:0,vy:0,vz:0,duration:0,impactX:0,impactZ:0});function pt(e,t){let n=W.drops.gravity;return(t+Math.sqrt(t*t+2*n*e))/n}function mt(e,t){return e.duration=pt(e.y-K.fountain.waterHeight-t,e.vy),e.impactX=e.x+e.vx*e.duration,e.impactZ=e.z+e.vz*e.duration,e}var ht=ut(),gt=new O,_t=new t;function vt(e,t,n=ft()){let r=dt(t,ht),i=Math.hypot(e.vx,e.vz),a=Y.releaseLatitude,o=Math.sqrt(1-a*a),s=e.vx/i*o,c=a,l=e.vz/i*o;ot(t,gt);let u=Y.radius*st(s,c,l,gt);ct(s,c,l,gt,_t),_t.set(_t.x/r.sx,_t.y/r.sy,_t.z/r.sz).normalize();let d=e.radius+Y.releaseMargin;return n.birthTime=t,n.x=s*u*r.sx+_t.x*d,n.y=r.y+c*u*r.sy+_t.y*d,n.z=l*u*r.sz+_t.z*d,n.vx=e.vx,n.vz=e.vz,n.vy=e.vy+Y.floatAmplitude*lt*Math.cos(t*lt),mt(n,e.radius)}function yt(e,t,n){return n.set(e.x+e.vx*t,e.y+e.vy*t-.5*W.drops.gravity*t*t,e.z+e.vz*t)}function bt(e){let n=e.geometry.getAttribute(`position`),r=e.geometry.getAttribute(`orbDirection`),i=e.geometry.getAttribute(`orbLayer`),a=K.fountain,o=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,{primary:s,secondary:c,stemFade:l}=nt,{yRatio:u}=Y.shape,d=new t(...s.direction),f=new t(...c.direction);return rt.beads.map(p=>{let m=new t(...p.direction),h=new t,g=0,_=-1/0;for(let e=0;e<n.count;e++){if(i.getX(e)!==0)continue;let t=h.fromBufferAttribute(r,e).dot(m);t>_&&(_=t,g=e)}h.fromBufferAttribute(r,g);let v=new t().fromBufferAttribute(n,g),y=new t(h.x,h.y*u,h.z),b=new t(h.x,h.y/u,h.z).normalize(),x=new t(b.x,0,b.z).normalize(),S=h.dot(d),C=h.dot(f),w=F.smoothstep(h.y,...l),T=new t;function E(t,n,r){let i=s.amplitude*Math.cos(S+at(t,s.period))+c.amplitude*Math.sin(C+at(t,c.period));return r.copy(v).addScaledVector(y,i*w).add(e.position).addScaledVector(b,p.radius*n)}function D(e,t){E(e,1,T);let n=pt(T.y-o-p.radius,p.vy),r=a.pedestalCapSize/2+p.radius+rt.clearance,i=Math.min((r-Math.sign(x.x)*T.x)/Math.abs(x.x),(r-Math.sign(x.z)*T.z)/Math.abs(x.z)),s=Math.max(p.speed,i/n);return t.birthTime=e,t.x=T.x,t.y=T.y,t.z=T.z,t.vx=x.x*s,t.vy=p.vy,t.vz=x.z*s,mt(t,p.radius)}return{...p,anchorIndex:g,sampleAttached:E,sampleFlight:D}})}function xt(e){let t=Se(`water`);t.name=`courtyard-living-orb`,t.flatShading=!0,t.customProgramCacheKey=()=>`courtyard-living-orb-flow-v2`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r),Object.assign(t.uniforms,{uOrbPhases:{value:e},uOrbBase:{value:new C(Y.colors.base)},uOrbLight:{value:new C(Y.colors.light)},uOrbSide:{value:new C(Y.colors.side)},uOrbShade:{value:new C(Y.colors.shade)},uOrbWhite:{value:new C(Y.colors.white)}});let i=e=>`vec3(${e.map(e=>e.toFixed(6)).join(`, `)})`,a=Y.flow,o=`
      // Rest coordinates interpolate across faces; normalize only per fragment.
      // No atan/UV wrapping, screen coordinates or independently running clock.
      vec3 rest = normalize(vOrbRest);
      vec3 q = vec3(uOrbPhases.x * rest.x - uOrbPhases.y * rest.z, rest.y,
                    uOrbPhases.y * rest.x + uOrbPhases.x * rest.z);
      float bend = dot(q, ${i(a.bend)}) + uOrbPhases.w;
      float mainPhase = dot(q, ${i(a.main)}) + ${a.bendStrength.toFixed(6)} * sin(bend) + uOrbPhases.z;
      float detailPhase = dot(q, ${i(a.detail)}) - uOrbPhases.w;
      float wave = cos(mainPhase);
      // Derivative filtering broadens the crest at the original 384px sampling.
      // Unresolvable secondary ripples fade out instead of flashing single pixels.
      float aa = clamp(fwidth(wave) * .65, .035, .38);
      float flowBand = smoothstep(-.45 - aa, .45 + aa, wave);
      float crest = smoothstep(.76 - aa, .96 + aa, wave);
      float detailVisibility = 1.0 - smoothstep(.55, 1.6, fwidth(detailPhase));
      float detailWave = sin(detailPhase);
      float shortCrest = smoothstep(.72 - aa, .98 + aa, detailWave) * detailVisibility;
      vec3 orbNormal = inverseTransformDirection(normal, viewMatrix);
      float sunFace = .5;
      #if NUM_DIR_LIGHTS > 0
        sunFace = max(dot(normal, directionalLights[0].direction), 0.0);
      #endif
      float volume = smoothstep(-.6, .7, orbNormal.y) * .6 + sunFace * .4;
      vec3 orbColor = mix(uOrbSide, uOrbBase, smoothstep(.08, .92, volume));
      orbColor = mix(orbColor, uOrbLight, flowBand * .46);
      orbColor = mix(orbColor, uOrbSide, (1.0 - flowBand) * .20);
      float edge = pow(1.0 - clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0), 2.6);
      float litCrest = mix(.52, 1.0, sunFace) * mix(.65, 1.0, smoothstep(-.7, .55, orbNormal.y));
      float rim = smoothstep(.35, .85, edge) * smoothstep(-.15, .6, orbNormal.y);
      float movingHighlight = crest * litCrest * .85 + shortCrest * flowBand * .12;
      orbColor = mix(orbColor, uOrbWhite, clamp(movingHighlight + rim * .13, 0.0, .86));
      outgoingLight = mix(uOrbShade, orbColor, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Orb shader extension anchor changed.`);if(!t.vertexShader.includes(`#include <begin_vertex>`))throw Error(`Orb rest-position anchor changed.`);t.vertexShader=t.vertexShader.replace(`#include <common>`,`#include <common>
attribute vec3 orbRest; varying vec3 vOrbRest;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vOrbRest = orbRest;`),t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      varying vec3 vOrbRest;
      uniform vec4 uOrbPhases;
      uniform vec3 uOrbBase; uniform vec3 uOrbLight; uniform vec3 uOrbSide; uniform vec3 uOrbShade; uniform vec3 uOrbWhite;
    
void main() {`).replace(s,o)},t}var St=600,Ct=Math.round(St*.18),wt=2.6001,Tt=Math.PI*(3-Math.sqrt(5)),Et=Y.radius-.013,Dt=1.3,Ot=[.034,.049],kt={body:`#7DB2CD`,shade:`#659CBE`,light:`#CEE4EE`};function At(n){let r=n!==`particles`,i=n===`particle-flow`||n===`particle-drops`,a=new Float32Array(2124),s=new Float32Array(2124),c=new Float32Array(708),l=new Float32Array(708);function u(e,t,n){for(let r=0;r<t;r++){let i=e+r,o=i*3,u=2*(r+.5)/t-1,d=r*Tt+(n?.7:0),f=Math.sqrt(1-u*u),p=f*Math.cos(d),m=f*Math.sin(d),h=n?.202*Math.cbrt((.27+r*.754877666)%1):Et+.0028*Math.sin(r*2.17);a[o]=p*h,a[o+1]=u*h*Y.shape.yRatio,a[o+2]=m*h,s[o]=p,s[o+1]=u,s[o+2]=m,c[i]=Number(n),l[i]=(Ot[0]+(Ot[1]-Ot[0])*((.31+r*.618033989)%1))*(n?.86:1)}}u(0,St,!1),u(St,Ct,!0);let d=new N;d.setAttribute(`position`,new e(a,3)),d.setAttribute(`orbDirection`,new e(s,3)),d.setAttribute(`orbLayer`,new e(c,1)),d.setAttribute(`orbDiameter`,new e(l,1)),d.computeBoundingBox(),d.computeBoundingSphere();let{primary:f,secondary:p,stemFade:m,interiorFollow:h}=nt,g=dt(wt).y,_=g+d.boundingBox.min.y,v=r?f.amplitude+p.amplitude:0;d.boundingSphere.radius+=Ot[1]/2+v,d.boundingBox.expandByScalar(v);let y=r?new A:void 0,S;if(i){let e=new t(...J.axis).normalize(),n=new t(...J.front).projectOnPlane(e).normalize(),r=new t().crossVectors(e,n);S=new o().set(n.x,n.y,n.z,r.x,r.y,r.z,e.x,e.y,e.z)}let w=new b({name:`courtyard-particle-orb`,transparent:!0,depthTest:!0,depthWrite:!1,toneMapped:!1,defines:{...r&&{ORB_WAVE:1},...i&&{ORB_FLOW:1}},uniforms:{uSampleHeight:{value:1},uMinimumPointSize:{value:Dt},uSunDirection:{value:new t(...B.sun.position).normalize()},uBody:{value:new C(kt.body)},uShade:{value:new C(kt.shade)},uLight:{value:new C(kt.light)},...y&&{uWavePhase:{value:y},uPrimaryWave:{value:new O(...f.direction,f.amplitude)},uSecondaryWave:{value:new O(...p.direction,p.amplitude)},uStemFade:{value:new A(...m)},uInteriorFollow:{value:h},uOrbYRatio:{value:Y.shape.yRatio}},...S&&{uFlowBasis:{value:S},uFlowOffset:{value:J.offset},uFlowFrontPhase:{value:at(J.frontTime,f.period)},uFlowCrestWidth:{value:new A(...J.crestWidth)},uFlowBackWeight:{value:J.backWeight},uFlowLight:{value:new C(J.colors.crest)},uFlowShade:{value:new C(J.colors.shade)}}},vertexShader:`
      attribute vec3 orbDirection;
      attribute float orbLayer;
      attribute float orbDiameter;
      uniform float uSampleHeight;
      uniform float uMinimumPointSize;
      uniform vec3 uSunDirection;
      uniform vec3 uBody;
      uniform vec3 uShade;
      uniform vec3 uLight;
      varying vec3 vColor;
      varying float vOpacity;

      #ifdef ORB_WAVE
        uniform vec2 uWavePhase;
        uniform vec4 uPrimaryWave;
        uniform vec4 uSecondaryWave;
        uniform vec2 uStemFade;
        uniform float uInteriorFollow;
        uniform float uOrbYRatio;

        vec3 displaceOrbPoint(vec3 rest, vec3 direction, float layer) {
          float primary = uPrimaryWave.w * cos(dot(direction, uPrimaryWave.xyz) + uWavePhase.x);
          float secondary = uSecondaryWave.w * sin(dot(direction, uSecondaryWave.xyz) + uWavePhase.y);
          // Keep the lower cap attached to the pedestal's water column.
          float weight = smoothstep(uStemFade.x, uStemFade.y, direction.y) * mix(1.0, uInteriorFollow, layer);
          vec3 ellipticalDirection = direction * vec3(1.0, uOrbYRatio, 1.0);
          return rest + ellipticalDirection * ((primary + secondary) * weight);
        }
      #endif

      #ifdef ORB_FLOW
        uniform mat3 uFlowBasis;
        uniform float uFlowOffset;
        uniform float uFlowFrontPhase;
        uniform vec2 uFlowCrestWidth;
        uniform float uFlowBackWeight;
        uniform vec3 uFlowLight;
        uniform vec3 uFlowShade;

        vec3 colorOrbFlow(vec3 water, vec3 direction, float facing, float lift, float layer) {
          vec3 orbit = uFlowBasis * direction;
          vec2 around = orbit.xy * inversesqrt(max(dot(orbit.xy, orbit.xy), 0.000001));
          float across = orbit.z - uFlowOffset;
          // The highlight slows through the front arc, then continues around the back.
          float phase = uWavePhase.x - uFlowFrontPhase;
          float travel = phase - .26 * sin(phase) + .24 * (1.0 - cos(phase));
          vec2 heading = vec2(cos(travel - .04), sin(travel - .04));
          float lengthMask = smoothstep(.63, .928, dot(around, heading));
          float taper = mix(.64, 1.0, lengthMask);
          float crest = 1.0 - smoothstep(uFlowCrestWidth.x * taper, uFlowCrestWidth.y * taper, abs(across));
          float trough = 1.0 - smoothstep(.024, .104, abs(across - .172));
          float visibility = mix(uFlowBackWeight, 1.0, smoothstep(-.29, .66, facing));
          float surface = mix(1.0, .14, layer);
          float strength = lengthMask * visibility * surface;
          float liftLight = mix(.58, 1.0, smoothstep(-.028, .030, lift));
          return mix(mix(water, uFlowShade, .36 * strength * trough),
                     uFlowLight, .97 * strength * crest * liftLight);
        }
      #endif

      void main() {
        vec3 direction = normalize(mat3(modelMatrix) * orbDirection);
        vec3 viewDirection = normalize(normalMatrix * orbDirection);
        float facing = viewDirection.z;
        float front = smoothstep(-.52, .76, facing);
        float sun = max(dot(direction, uSunDirection), 0.0);
        float rim = pow(1.0 - abs(facing), 2.0);
        vec3 blue = mix(uShade, uBody, .18 + .64 * front + .16 * sun);
        vec3 viewLight = mat3(viewMatrix) * uSunDirection;
        vec3 halfDirection = normalize(viewLight + vec3(0.0, 0.0, 1.0));
        float directGleam = smoothstep(.86, .992, dot(viewDirection, halfDirection));
        float rimGleam = rim * pow(sun, 3.0);
        float gleam = min(.94 * directGleam + .28 * rimGleam, 1.0);
        #ifdef ORB_FLOW
          gleam *= .62;
        #endif
        vColor = mix(blue, uLight, gleam * mix(1.0, .35, orbLayer));
        vOpacity = (.33 + .49 * front + .09 * rim) * mix(1.0, .42, orbLayer);
        vec3 localPosition = position;
        #ifdef ORB_WAVE
          localPosition = displaceOrbPoint(position, orbDirection, orbLayer);
        #endif
        #ifdef ORB_FLOW
          float lift = dot(localPosition - position, orbDirection);
          vColor = colorOrbFlow(vColor, orbDirection, facing, lift, orbLayer);
        #endif
        gl_Position = projectionMatrix * modelViewMatrix * vec4(localPosition, 1.0);
        gl_PointSize = max(uMinimumPointSize, .5 * abs(projectionMatrix[1][1]) * uSampleHeight * orbDiameter);
      }
    `,fragmentShader:`
      varying vec3 vColor;
      varying float vOpacity;
      void main() {
        float distanceToCenter = length(2.0 * gl_PointCoord - 1.0);
        float coverage = 1.0 - smoothstep(.60, 1.0, distanceToCenter);
        if (coverage < .015) discard;
        gl_FragColor = vec4(vColor, vOpacity * coverage);
        #include <colorspace_fragment>
      }
    `}),T=new x(d,w);return T.name=`fountain-water-crown`,T.position.y=g,T.onBeforeRender=e=>{w.uniforms.uSampleHeight.value=e.getRenderTarget()?.height??e.domElement.height},{object:T,metadata:{radius:Y.radius,centerY:g,amplitude:0,period:0,referenceTime:wt,shellCount:St,interiorCount:Ct,vertices:708,triangles:0,shellRadius:Et,minimumPointSize:Dt,diameter:Ot,colors:kt,addedTextures:0,addedPasses:0,...r&&{wave:nt,maximumDisplacement:v},...i&&{surfaceFlow:J}},update(e){return y?.set(at(e,f.period),at(e,p.period)),_},dispose(){d.dispose(),w.dispose()}}}function jt(){let e=new O,n=ut(),r=xt(e),i=new D(1,...Y.sphereSegments),a=i.getAttribute(`position`);a.setUsage(d);let o=new Float32Array(a.array);i.setAttribute(`orbRest`,new _(o,3)),i.boundingSphere=new j(new t,Y.shape.envelope),i.boundingBox=new I(new t().setScalar(-Y.shape.envelope),new t().setScalar(Y.shape.envelope));let s=new f(i,r);return s.name=`fountain-water-crown`,s.receiveShadow=!0,s.scale.setScalar(Y.radius),{object:s,phases:e,pose:n,metadata:{radius:Y.radius,centerY:Y.centerY,amplitude:Y.floatAmplitude,period:Y.floatPeriod,envelope:Y.shape.envelope,replacedGeometries:2,addedGeometries:0,addedTextures:0,addedPasses:0,flow:`curved-rest-sphere-v2`,vertices:a.count,triangles:i.index.count/3,restAttributeBytes:o.byteLength},update(t){dt(t,n),ot(t,e);let r=1/0;for(let t=0;t<a.count;t++){let i=t*3,s=o[i],c=o[i+1],l=o[i+2],u=st(s,c,l,e),d=c*u*n.sy;a.setXYZ(t,s*u*n.sx,d,l*u*n.sz),r=Math.min(r,d)}return a.needsUpdate=!0,s.position.y=n.y,n.y+r*Y.radius},dispose(){i.dispose(),r.dispose()}}}function Mt(e,n,i=`lively`){let a=new r;a.name=`fountain-effects`,a.userData.orbStyle=i;let o=K.fountain;a.position.set(...o.position),a.rotation.y=o.rotationY;let s=i===`lively`?void 0:At(i),c=s??jt(),l=i===`particle-drops`&&s?bt(s.object):void 0,u=l?nt.primary.period:W.drops.period,m=Le(e,`jet`),g=o.baseHeight+o.pedestalFootHeight+o.pedestalHeight+o.pedestalCapHeight,_=new h(Y.stemRadius,Y.stemRadius,1,8),y=new v(1,+!!l),b=new f(_,m);b.name=`fountain-water-column`,b.receiveShadow=!0;let x=new L(y,m,n.length);x.name=`fountain-water-drops`,x.receiveShadow=!0,x.instanceMatrix.setUsage(d),x.boundingBox=new I(new t(-1.75,.3,-1.75),new t(1.75,1.9,1.75)),x.boundingSphere=x.boundingBox.getBoundingSphere(new j),a.add(b,c.object,x),a.visible=W.enabled;let S=new t,C=new t,w=new T,E=new p,D=new p,O=(l??n).map((e,t)=>({drop:e,index:t,current:ft(),previous:ft()})),k=O.map(e=>({record:e,age:0,flight:e.current}));a.userData.flights=O,a.userData.impactEvents=k,`pose`in c&&(a.userData.orbPose=c.pose,a.userData.orbPhases=c.phases),a.userData.orbMetadata={...c.metadata,dropCapacity:n.length,rippleCapacity:e.impacts.value.length,...l&&{releasePeriod:u,beads:l.map(({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i})=>({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i}))}};let A,M=!1;function N(t){if(M||t===A)return;A=t,e.time.value=t;let r=c.update(t),i=r+Y.stemOverlap;b.position.y=(g+i)/2,b.scale.y=i-g;let s=0;for(let e of O){let{drop:n,current:r,previous:i}=e,a=`sampleAttached`in n?n:void 0,c=a?.formationTime??0,l=n.phase+Math.floor((t-n.phase+c)/u)*u;l!==r.birthTime&&(`sampleFlight`in n?(n.sampleFlight(l,r),n.sampleFlight(l-u,i)):(vt(n,l,r),vt(n,l-u,i)));let d=t-l,f=n.radius;if(a&&d<0){let e=F.smoothstep(d,-c,0);a.sampleAttached(t,e,S),f*=e}else{if(!a&&d>=r.duration)continue;if(yt(r,d,S),a){if(S.y+f<=o.waterHeight)continue}else f*=Math.min(1,d/.07,(r.duration-d)/.055)}f<5e-4||(C.setScalar(f),E.compose(S,w,C),x.setMatrixAt(s++,E))}x.count=s;for(let e=s;e<n.length;e++)x.setMatrixAt(e,D);x.instanceMatrix.needsUpdate=!0;for(let e of k){let n=e.record;e.flight=t>=n.current.birthTime+n.current.duration?n.current:n.previous,e.age=t-(e.flight.birthTime+e.flight.duration)}k.sort((e,t)=>e.age-t.age||e.record.index-t.record.index);let l=0;for(let t=0;t<e.impacts.value.length;t++){let n=k[t];n&&n.age>=0&&n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.flight.impactX,n.flight.impactZ,n.age,n.record.drop.strength),l++):e.impacts.value[t].set(0,0,0,0)}a.userData.time=t,a.userData.activeDrops=s,a.userData.activeRipples=l,a.userData.orbBottom=r,a.userData.stemTop=i}return N(W.initialTime),{root:a,update:N,dispose(){M||(M=!0,x.dispose(),_.dispose(),c.dispose(),y.dispose(),m.dispose(),a.removeFromParent(),a.clear())}}}function Nt(){let e=W.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=W.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=W.jet.emitterHeight-K.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function Pt(e,t,n){return n.set(e.vx*t,W.jet.emitterHeight+e.vy*t-.5*W.drops.gravity*t*t,e.vz*t)}function Ft(e,n=`legacy`){if(n!==`legacy`)try{return Mt(e,Nt(),n)}catch(e){console.warn(`Orb detail unavailable; original water effects retained.`,e)}let i=new r;i.name=`fountain-effects`;let a=K.fountain;i.position.set(...a.position),i.rotation.y=a.rotationY;let o=Nt();i.userData.dropParameters=o;let s=Le(e,`jet`),c=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,l=W.jet.emitterHeight-c,u=new h(W.jet.stemRadius,W.jet.stemRadius,l,8),d=new D(1,8,5),m=new v(1,0),g=new f(u,s);g.name=`fountain-water-column`,g.position.y=c+l/2,g.receiveShadow=!0;let _=new f(d,s);_.name=`fountain-water-crown`,_.position.y=W.jet.emitterHeight,_.receiveShadow=!0;let y=new L(m,s,o.length);y.name=`fountain-water-drops`,y.receiveShadow=!0,y.boundingBox=new I(new t(-1.4,.3,-1.4),new t(1.4,1.45,1.4)),y.boundingSphere=y.boundingBox.getBoundingSphere(new j),i.add(g,_,y),i.visible=W.enabled;let b=new t,x=new t,S=new p,C=new T,w=new p,E=o.map(e=>({drop:e,age:0})),O=(e,t)=>e.age-t.age,k=(e,t)=>(e%t+t)%t;function A(t){e.time.value=t;let n=0;for(let e of o){let r=k(t-e.phase,W.drops.period);if(r>=e.impactTime)continue;Pt(e,r,b);let i=Math.min(1,r/.07),a=Math.min(1,(e.impactTime-r)/.055),o=e.radius*Math.min(i,a);o<5e-4||(x.setScalar(o),S.compose(b,C,x),y.setMatrixAt(n++,S))}y.count=n;for(let e=n;e<o.length;e++)y.setMatrixAt(e,w);y.instanceMatrix.needsUpdate=!0;for(let e of E)e.age=k(t-e.drop.phase-e.drop.impactTime,W.drops.period);E.sort(O);let r=0;for(let t=0;t<e.impacts.value.length;t++){let n=E[t];n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),r++):e.impacts.value[t].set(0,0,0,0)}let a=W.jet.pulse,s=W.jet.radius;_.scale.set(s*(1+a*Math.sin(t*2.1)),s*.9*(1+a*Math.sin(t*2.8)),s*(1+a*Math.cos(t*2.1))),g.scale.set(1+a*Math.sin(t*2.1),1,1+a*Math.sin(t*2.1)),i.userData.time=t,i.userData.activeDrops=n,i.userData.activeRipples=r}A(W.initialTime);let M=!1;return{root:i,update:A,dispose(){M||(M=!0,y.dispose(),u.dispose(),d.dispose(),m.dispose(),s.dispose(),i.removeFromParent(),i.clear())}}}function It(){let n=U.petals,r=U.seed+1;function i(){r+=1831565813;let e=Math.imul(r^r>>>15,1|r);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let a=Array.from({length:n.capacity},(e,t)=>{let r=0,a=0,o=!1;for(let e=0;e<1e3;e++){let e=H.flowers.clusters[Math.floor(i()*H.flowers.clusters.length)],t=i()*Math.PI*2,s=i()*e.radius;if(r=e.center[0]+Math.cos(t)*s,a=e.center[1]+Math.sin(t)*s,$e(r,a,n.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:r,z:a,phase:t*n.period/n.capacity,rotation:i()*Math.PI*2,size:.055+i()*.02}}),o=new N;o.setAttribute(`position`,new e([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),o.computeVertexNormals();let s=new m({color:R.flowerLight,side:2,toneMapped:!1});s.name=`courtyard-floating-petal`;let c=new L(o,s,n.capacity);c.name=`courtyard-floating-petals`,c.castShadow=!1;let l=new I;for(let e of a)l.expandByPoint(new t(e.x-n.drift,n.minHeight,e.z-n.drift)),l.expandByPoint(new t(e.x+n.drift,n.maxHeight,e.z+n.drift));l.expandByScalar(.05),c.boundingBox=l,c.boundingSphere=l.getBoundingSphere(new j),c.userData.parameters=a;let u=new p,d=new t,f=new t,h=new T,g=new p,_=new t(.25,1,.15).normalize(),v=!1;return{mesh:c,update(e){let t=0;for(let r of a){let i=((e-r.phase)%n.period+n.period)%n.period;if(i>=n.lifetime)continue;let a=i/n.lifetime,o=Math.min(1,i/.6,(n.lifetime-i)/.7);d.set(r.x+Math.sin(i*.6+r.rotation)*n.drift,n.maxHeight+(n.minHeight-n.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*n.drift),h.setFromAxisAngle(_,r.rotation+i*.25),f.setScalar(r.size*o),u.compose(d,h,f),c.setMatrixAt(t++,u)}c.count=t;for(let e=t;e<n.capacity;e++)c.setMatrixAt(e,g);c.instanceMatrix.needsUpdate=!0},dispose(){v||(v=!0,c.dispose(),o.dispose(),s.dispose(),c.removeFromParent())}}}var Z={flowSpeed:.035,waveSpeed:.36,waveStrength:.15,rippleStrength:.42,foamWidth:[.015,.04],colors:{shallow:`#B4DAD9`,base:`#BED4DF`,middle:`#95BECF`,deep:`#245B80`,shade:`#7FA3BF`,white:`#F2FAFC`,stoneTop:`#F0E5C1`,stoneSide:`#C7CCB6`,stoneShade:`#7095A1`,wetStone:`#557D81`,weathering:`#A3B592`}};function Lt(){let e=Fe({top:Z.colors.stoneTop,side:Z.colors.stoneSide,shade:Z.colors.stoneShade});e.name=`courtyard-pool-stone`,e.customProgramCacheKey=()=>`courtyard-pool-stone-v1`;let t=e.onBeforeCompile.bind(e);return e.onBeforeCompile=(e,n)=>{t(e,n);let r=K.fountain;Object.assign(e.uniforms,{uPoolStoneOrigin:{value:new O(r.position[0],r.position[2],Math.cos(r.rotationY),Math.sin(r.rotationY))},uPoolStoneLevels:{value:new O(r.position[1],r.waterHeight,r.baseHeight,r.innerRadius)},uPoolStoneWet:{value:new C(Z.colors.wetStone)},uPoolStoneOld:{value:new C(Z.colors.weathering)}});let i=`outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;`;if(!e.fragmentShader.includes(i))throw Error(`Pool stone extension anchor changed.`);e.fragmentShader=e.fragmentShader.replace(`void main() {`,`
      uniform vec4 uPoolStoneOrigin; uniform vec4 uPoolStoneLevels;
      uniform vec3 uPoolStoneWet; uniform vec3 uPoolStoneOld;
    
void main() {`).replace(i,`${i}\n
      vec2 poolDelta = vArtWorldPosition.xz - uPoolStoneOrigin.xy;
      vec2 poolP = vec2(uPoolStoneOrigin.z * poolDelta.x - uPoolStoneOrigin.w * poolDelta.y,
                       uPoolStoneOrigin.w * poolDelta.x + uPoolStoneOrigin.z * poolDelta.y);
      vec2 poolN = vec2(uPoolStoneOrigin.z * worldNormal.x - uPoolStoneOrigin.w * worldNormal.z,
                       uPoolStoneOrigin.w * worldNormal.x + uPoolStoneOrigin.z * worldNormal.z);
      float poolY = vArtWorldPosition.y - uPoolStoneLevels.x;
      float side = 1.0 - smoothstep(.35, .85, worldNormal.y);
      float innerFace = 1.0 - smoothstep(-.08, .05, dot(poolN, poolP));
      float pedestal = 1.0 - smoothstep(.44, .58, max(abs(poolP.x), abs(poolP.y)));
      float wetNoise = artNoise(poolP * 13.0 + vec2(5.4, 8.1));
      float wetLine = 1.0 - smoothstep(uPoolStoneLevels.y + .018, uPoolStoneLevels.y + .065 + wetNoise * .025, poolY);
      float wet = wetLine * side * max(innerFace, pedestal);
      outgoingLight = mix(outgoingLight, mix(outgoingLight * .73, uPoolStoneWet, .22), wet * .72);
      float contact = (1.0 - smoothstep(.02, .075, poolY)) * side;
      outgoingLight = mix(outgoingLight, uPoolStoneWet * .78, contact * .30);
      float capStep = (1.0 - smoothstep(.004, .018, abs(poolY - .44))) * side;
      outgoingLight *= 1.0 - capStep * .10;
      float chips = max(1.0 - smoothstep(.08, .28, length(poolP - vec2(.935, -2.259))),
                        1.0 - smoothstep(.08, .28, length(poolP + vec2(.935, -2.259))));
      float weather = chips * smoothstep(.48, .72, wetNoise) * smoothstep(.48, .56, poolY);
      outgoingLight = mix(outgoingLight, uPoolStoneOld, weather * .35);
    `)},e}function Rt(e){let t=Se(`water`);t.name=`courtyard-water-refined-surface`,t.userData.waterKind=`refined-surface`,t.customProgramCacheKey=()=>`courtyard-water-refined-surface-v1`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r);let i=K.fountain;Object.assign(t.uniforms,{uPoolTime:e.time,uPoolImpacts:e.impacts,uPoolOrigin:{value:new O(i.position[0],i.position[2],Math.cos(i.rotationY),Math.sin(i.rotationY))},uPoolMotion:{value:new O(Z.flowSpeed,Z.waveSpeed,Z.waveStrength,Z.rippleStrength)},uPoolBoundary:{value:new O(i.innerRadius*Math.cos(Math.PI/8),...Z.foamWidth,W.ripples.lifetime)},uPoolShallow:{value:new C(Z.colors.shallow)},uPoolBase:{value:new C(Z.colors.base)},uPoolMiddle:{value:new C(Z.colors.middle)},uPoolDeep:{value:new C(Z.colors.deep)},uPoolShade:{value:new C(Z.colors.shade)},uPoolWhite:{value:new C(Z.colors.white)}});let a=`
      uniform float uPoolTime;
      uniform vec4 uPoolImpacts[${W.ripples.capacity}];
      uniform vec4 uPoolOrigin; uniform vec4 uPoolMotion; uniform vec4 uPoolBoundary;
      uniform vec3 uPoolShallow; uniform vec3 uPoolBase; uniform vec3 uPoolMiddle;
      uniform vec3 uPoolDeep; uniform vec3 uPoolShade; uniform vec3 uPoolWhite;
    `,o=`
      vec2 delta = vArtWorldPosition.xz - uPoolOrigin.xy;
      vec2 p = vec2(uPoolOrigin.z * delta.x - uPoolOrigin.w * delta.y,
                    uPoolOrigin.w * delta.x + uPoolOrigin.z * delta.y);
      float t = uPoolTime;
      vec2 drift = vec2(t, -t * .25) * uPoolMotion.x;
      float broad = artNoise(p * vec2(2.2, 1.6) + drift * .5 + vec2(3.7, 6.1));
      float grain = artNoise(p * 18.0 + drift);
      vec2 q = p + vec2((broad - .5) * .20, (artNoise(p * 2.8 + vec2(8.4, 1.7) - drift) - .5) * .18) + drift * .65;
      vec2 leftShape = mat2(.96, -.28, .28, .96) * (q - vec2(-1.3, -.25));
      float leftReflection = length(leftShape / vec2(.36, 1.62));
      vec2 farShape = q - vec2(.30, -1.68);
      farShape.y += sin(farShape.x * 2.0) * .10;
      float farReflection = length(farShape / vec2(1.42, .31));
      vec2 nearShape = mat2(.91, .41, -.41, .91) * (q - vec2(1.12, .95));
      float nearReflection = length(nearShape / vec2(.24, .64));
      float silhouette = min(min(leftReflection, farReflection), nearReflection);
      silhouette += (broad - .5) * .70 + (grain - .5) * .12;
      float aa = clamp(max(fwidth(p.x), fwidth(p.y)), .003, .12);
      float detail = 1.0 - smoothstep(.035, .095, aa);
      float reflection = 1.0 - smoothstep(.93 - aa, 1.04 + aa, silhouette);
      float centerDistance = length(p);
      reflection *= smoothstep(.55, .85, centerDistance);

      float shoreDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + .5) * PI / 4.0;
        shoreDistance = min(shoreDistance, uPoolBoundary.x - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float shelf = smoothstep(.025, .18, shoreDistance);
      float depth = smoothstep(.28, 1.25, shoreDistance) * .26;
      vec3 clearWater = mix(uPoolShallow, uPoolBase, shelf);
      clearWater = mix(clearWater, uPoolMiddle, depth);
      vec3 litWater = mix(clearWater, uPoolDeep, reflection * .96);

      float wave = smoothstep(.955, .995, sin(centerDistance * 12.0 - t * uPoolMotion.y * 12.0 + broad));
      wave *= smoothstep(.65, .9, centerDistance) * (1.0 - smoothstep(1.5, 1.95, centerDistance));
      wave *= smoothstep(.52, .76, artNoise(p * 7.5 + drift)) * uPoolMotion.z;
      float glint = smoothstep(.78, .94, artNoise(p * 7.0 - drift))
        * smoothstep(.90, .99, sin(p.x * 11.0 + p.y * 6.0 - t * .72 + broad * 3.0)) * .64;
      float foam = (1.0 - smoothstep(uPoolBoundary.y, uPoolBoundary.z + aa * .35, shoreDistance))
        * smoothstep(.71, .88, artNoise(p * 12.0 + drift)) * .48;
      float impacts = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 event = uPoolImpacts[i];
        float radius = .025 + event.z * ${W.ripples.speed.toFixed(2)};
        float distanceToRing = abs(length(p - event.xy) - radius);
        float ring = 1.0 - smoothstep(.008, .018 + aa * .3, distanceToRing);
        float ageFade = pow(clamp(1.0 - event.z / uPoolBoundary.w, 0.0, 1.0), 2.0);
        float broken = smoothstep(.22, .47, artNoise(p * 9.0 + vec2(float(i) * 3.1, 5.0)));
        impacts = max(impacts, ring * ageFade * event.w * broken * uPoolMotion.w);
      }
      float white = max(max(wave, glint) * mix(.25, 1.0, detail), max(foam, impacts));
      litWater = mix(litWater, uPoolWhite, white);
      vec3 shadedWater = mix(uPoolShade, uPoolDeep * .84, reflection * .78);
      shadedWater = mix(shadedWater, uPoolWhite, white * .13);
      outgoingLight = mix(shadedWater, litWater, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Pool surface extension anchor changed.`);t.fragmentShader=t.fragmentShader.replace(`void main() {`,`${a}\nvoid main() {`).replace(s,o)},t}function zt(e,t){let n=e.getObjectByName(`fountain`),r=n?.getObjectByName(`fountain-water`),i=[];if(n?.traverse(e=>{e instanceof f&&/^fountain-(base|rim-wall|coping-\d|pedestal(-foot|-cap)?)$/.test(e.name)&&i.push(e)}),!(r instanceof f)||i.length!==13)throw Error(`Pool finish requires the complete original fountain.`);let a=Rt(t),o=Lt(),s=new Map;for(let e of[...i,r])s.set(e,e.material),e.material=e===r?a:o;let c=!1;return{metadata:{bindings:[...s.keys()].map(e=>({object:e.name,material:e.material.name})),newGeometries:0,newTextures:0,extraPasses:0},dispose(){if(!c){c=!0;for(let[e,t]of s)e.material=t;s.clear(),a.dispose(),o.dispose()}}}}var Q={period:32,speed:.22,softness:[.46,1.3],unionSoftness:.24,patches:[{along:-3,across:-1.4,radius:[4.6,3.3],density:1},{along:12,across:4.6,radius:[5.6,3.7],density:.88}],response:{ground:.18,stone:.14,foliage:.13,flower:.1,water:.075,orb:.05,jet:.045}},Bt=B.sun.position,Vt=[Bt[0]/Bt[1],Bt[2]/Bt[1]],Ht=ve,Ut=Q.period/Q.speed;function Wt(e){return(e*Q.speed%Q.period+Q.period)%Q.period}function Gt(e,t){let n=t,r={enabled:e,active:{value:+!!e},drift:{value:Wt(t)},failures:[],update(t){e&&t!==n&&(n=t,r.drift.value=Wt(t))},snapshot(){return{enabled:e,active:r.active.value,time:n,drift:r.drift.value,repeatSeconds:Ut,failures:[...r.failures]}}};return r}var $=e=>e.toFixed(10),Kt=e=>`vec2(${e.map($).join(`,`)})`,qt=`
  uniform float uCloudDrift;
  uniform float uCloudActive;
  float cloudSoftMin(float a, float b) {
    float h = max(${$(Q.unionSoftness)} - abs(a - b), 0.0) / ${$(Q.unionSoftness)};
    return min(a, b) - h * h * ${$(Q.unionSoftness*.25)};
  }
  float cloudPatch(vec2 point, vec2 center, vec2 radius) {
    vec2 q = point - center;
    q.x -= ${$(Q.period)} * floor(q.x / ${$(Q.period)} + .5);
    q /= radius;
    // Evaluate derivatives before the coherent empty-space branch. The cloud
    // is already fully clear outside these bounds, including the wrap seam.
    float aa = min(max(fwidth(q.x), fwidth(q.y)) * .75, .10);
    if (abs(q.x) > 1.8 || abs(q.y) > 1.6) return 0.0;
    vec2 b = (q - vec2(.48, -.16)) * vec2(1.3, 1.18);
    vec2 c = (q + vec2(.44, -.22)) * vec2(1.15, 1.38);
    float d = cloudSoftMin(cloudSoftMin(dot(q, q), dot(b, b)), dot(c, c));
    return 1.0 - smoothstep(${$(Q.softness[0])} - aa, ${$(Q.softness[1])} + aa, d);
  }
  float cloudCoverage(vec3 world) {
    vec2 projected = world.xz - world.y * ${Kt(Vt)};
    const vec2 direction = ${Kt(Ht)};
    vec2 point = vec2(dot(projected, direction) - uCloudDrift,
                      dot(projected, vec2(-direction.y, direction.x)));
    ${Q.patches.map((e,t)=>`float c${t} = cloudPatch(point, ${Kt([e.along,e.across])}, ${Kt(e.radius)}) * ${$(e.density)};`).join(`
`)}
    return 1.0 - (1.0 - c0) * (1.0 - c1);
  }
`;function Jt(e,t,n,r){let i=`#include <opaque_fragment>`;if(!e.fragmentShader.includes(i)||!e.fragmentShader.includes(`void main() {`)||!e.vertexShader.includes(`vArtWorldPosition`))throw Error(`Cloud receiver shader anchor unavailable`);let a=t===`ground`?`mix(.08, 1.0, 1.0 - occlusion)`:t===`foliage`?`mix(.10, 1.0, 1.0 - plantOcclusion)`:t===`flower`?`mix(.10, 1.0, 1.0 - flowerOcclusion)`:`mix(.12, 1.0, cloudSceneShadow) * mix(.10, 1.0, smoothstep(.015, .32, cloudLuminance))`,o=t===`water`?` * mix(1.0, .30, smoothstep(.50, .90, cloudLuminance))`:``,s=`
    // CLOUD_SHADOW_FINISH: shared world field after the original material finish.
    float cloudLuminance = dot(outgoingLight, vec3(.2126, .7152, .0722));
    float cloudMask = cloudCoverage(vArtWorldPosition);
    float cloudAmount = cloudMask * ${$(n)} * (${a})${o} * uCloudActive;
    outgoingLight *= vec3(1.0) - cloudAmount * vec3(1.0, .96, .85);
    ${i}
  `,c=e.fragmentShader.replaceAll(`getShadowMask()`,`cloudSceneShadow`).replace(`void main() {`,`void main() {
float cloudSceneShadow = getShadowMask();`).replace(`#include <common>`,`#include <common>\n${qt}`).replace(i,s);e.uniforms.uCloudDrift=r.drift,e.uniforms.uCloudActive=r.active,e.fragmentShader=c}function Yt(e){let t=new Map,n=!1;return{bind(r){!n&&e.enabled&&r.traverse(n=>{if(n instanceof f)for(let r of Array.isArray(n.material)?n.material:[n.material]){let n=r.userData.artSurface;if(!n||!(n in Q.response)||t.has(r))continue;let i=r.name===`courtyard-living-orb`?Q.response.orb:r.userData.waterKind===`jet`?Q.response.jet:Q.response[n],a=r.onBeforeCompile,o=r.customProgramCacheKey;t.set(r,{compile:a,key:o,data:r.userData.cloudShadow}),r.customProgramCacheKey=()=>`${o.call(r)}-cloud-shadow-v2-${i}`,r.onBeforeCompile=(t,o)=>{if(a.call(r,t,o),e.active.value)try{Jt(t,n,i,e)}catch(t){e.active.value=0,e.failures.push(`${r.name}: ${String(t)}`),console.warn(`Cloud shade unavailable; original surface lighting retained.`,t)}},r.userData.cloudShadow={surface:n,strength:i}}})},get metadata(){return{...e.snapshot(),materials:[...t.keys()].map(e=>({name:e.name,...e.userData.cloudShadow})),newGeometries:0,newTextures:0,extraPasses:0,extraDrawCalls:0}},dispose(){if(!n){n=!0;for(let[e,n]of t)e.onBeforeCompile=n.compile,e.customProgramCacheKey=n.key,n.data===void 0?delete e.userData.cloudShadow:e.userData.cloudShadow=n.data;t.clear()}}}}var Xt={routes:[{center:[-.6,1.3],radii:[7.2,5.5],height:4.45,rotation:.05,period:48,phase:.14,direction:1,span:.34,flapCycle:5.2,flapDuration:1.4,flapRate:1.7},{center:[.4,.7],radii:[6.1,6.4],height:5.1,rotation:-.65,period:54,phase:.55,direction:-1,span:.32,flapCycle:5.4,flapDuration:1.6,flapRate:1.9},{center:[-.4,1.1],radii:[7.8,4.9],height:5.75,rotation:.35,period:61,phase:.81,direction:1,span:.33,flapCycle:4.9,flapDuration:1.3,flapRate:1.6}],colors:{warm:`#F3EAC4`,light:`#F8FCED`,cool:`#7095A1`,tip:`#405B55`,beak:`#DCCB9D`},bodyRadius:.69,clearance:.25,desktopMargin:20,mobileMargin:14,fadePixels:26,minimumAlpha:.015},Zt=Math.PI*2,Qt=(e,t)=>(e%t+t)%t,$t=e=>{let t=Math.min(1,Math.max(0,e));return t*t*t*(t*(t*6-15)+10)};function en(){return{position:new t,tangent:new t,rotation:new T,euler:new n(0,0,0,`YXZ`),leftWing:0,rightWing:0,flap:0,bank:0,speed:0,scale:1,phase:0}}function tn(e,t,n){let r=Xt.routes[t],i=Qt(e/r.period*r.direction+r.phase,1),a=Zt*i,o=Zt/r.period*r.direction,s=Math.cos(r.rotation),c=Math.sin(r.rotation),l=r.radii[0]*Math.cos(a)+.35*Math.sin(2*a),u=r.radii[1]*Math.sin(a),d=(-r.radii[0]*Math.sin(a)+.7*Math.cos(2*a))*o,f=r.radii[1]*Math.cos(a)*o,p=Qt(e+t*1.37,r.flapCycle),m=$t(p/.22)*(1-$t((p-r.flapDuration+.28)/.28)),h=Zt*r.flapRate*e+t*1.9,g=.08+m*(.54*Math.sin(h)-.04);n.position.set(r.center[0]+s*l-c*u,r.height+.055*Math.sin(2*a)+.016*m*Math.sin(h*2),r.center[1]+c*l+s*u),n.tangent.set(s*d-c*f,.11*o*Math.cos(2*a),c*d+s*f),n.speed=n.tangent.length(),n.tangent.normalize();let _=Math.atan2(n.tangent.x,n.tangent.z),v=-Math.atan2(n.tangent.y,Math.hypot(n.tangent.x,n.tangent.z)),y=-.18*r.direction*(.75+.25*Math.cos(2*a));return n.euler.set(v,_,y,`YXZ`),n.rotation.setFromEuler(n.euler),n.leftWing=g,n.rightWing=-g,n.flap=m,n.bank=y,n.scale=r.span,n.phase=i,n}function nn(n){let r=[],i=[],a=[],o=0,s=Object.fromEntries(Object.entries(Xt.colors).map(([e,t])=>[e,new C(t)])),c=new t,l=new t,u=new t;function d(e,t,n,d){c.set(t[0]-e[0],t[1]-e[1],t[2]-e[2]),l.set(n[0]-e[0],n[1]-e[1],n[2]-e[2]),u.crossVectors(c,l).normalize();let f=s[d??(u.y>.3?`light`:u.y<-.3?`cool`:`warm`)];for(let s of[e,t,n])r.push(...s),i.push(f.r,f.g,f.b),a.push(o)}function f(e,n,r){let i=e.reduce((e,n)=>e.add(new t(...n)),new t).divideScalar(e.length);for(let[a,o,s]of n){let n=e[a],f=e[o],p=e[s];c.set(f[0]-n[0],f[1]-n[1],f[2]-n[2]),l.set(p[0]-n[0],p[1]-n[1],p[2]-n[2]),u.crossVectors(c,l),u.dot(new t(...n).sub(i))<0?d(n,p,f,r):d(n,f,p,r)}}function p(e,t,n,r=!1){let i=0;for(let t=0;t<e.length;t++){let n=e[t],r=e[(t+1)%e.length];i+=n[0]*r[1]-r[0]*n[1]}i>0&&e.reverse();let a=e.map(([e,r])=>[e,t+n/2,r]),o=e.map(([e,r])=>[e,t-n/2,r]);for(let t=1;t<e.length-1;t++)d(a[0],a[t],a[t+1],r&&t===2?`tip`:`warm`),d(o[0],o[t+1],o[t],`cool`);for(let t=0;t<e.length;t++){let n=(t+1)%e.length;d(a[t],o[t],o[n],`cool`),d(a[t],o[n],a[n],`cool`)}}if((n===`body`||n===`all`)&&(f([[0,.02,.245],[0,.02,-.225],[.085,.02,0],[-.085,.02,0],[0,.105,.005],[0,-.065,-.005]],[[4,0,2],[4,2,1],[4,1,3],[4,3,0],[5,2,0],[5,1,2],[5,3,1],[5,0,3]]),f([[0,.115,.28],[-.055,.025,.2],[.055,.025,.2],[0,.035,.37]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`warm`),f([[0,.04,.345],[-.025,.025,.32],[.025,.025,.32],[0,.025,.415]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`beak`),p([[0,-.17],[.075,-.34],[0,-.305],[-.075,-.34]],.015,.014)),n!==`body`)for(let e of n===`all`?[-1,1]:[n===`left`?-1:1])o=e,p([[0,.1],[e*.22,.035],[e*.425,-.095],[e*.3,-.19],[e*.05,-.08]],.025,.018,!0);let m=new N;return m.name=`courtyard-bird-${n}`,m.setAttribute(`position`,new e(r,3)),m.setAttribute(`color`,new e(i,3)),n===`all`&&m.setAttribute(`birdPart`,new e(a,1)),m.computeVertexNormals(),m.computeBoundingBox(),m.computeBoundingSphere(),m}function rn(){let e=new S({color:16777215,vertexColors:!0,flatShading:!0,transparent:!0,depthTest:!0,depthWrite:!1,alphaTest:.012,toneMapped:!1});return e.name=`courtyard-birds`,e.customProgramCacheKey=()=>`courtyard-birds-hinge-v2`,e.color.multiplyScalar(1.5),e.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
attribute float birdAlpha; attribute float birdWing; attribute float birdPart; varying float vBirdAlpha;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vBirdAlpha = birdAlpha;
if (abs(birdPart) > 0.5) {
  float angle = -birdPart * birdWing;
  float c = cos(angle), s = sin(angle);
  transformed.xy = mat2(c, s, -s, c) * transformed.xy;
  transformed += vec3(birdPart * 0.075, 0.0, 0.015);
}`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
varying float vBirdAlpha;`).replace(`#include <alphatest_fragment>`,`diffuseColor.a *= vBirdAlpha;
#include <alphatest_fragment>`)},e}var an=e=>{let t=Math.min(1,Math.max(0,e));return t*t*(3-2*t)};function on(e,t,n,r){let i=an((Math.min(e-r.bounds.left,r.bounds.right-e,t-r.bounds.top,r.bounds.bottom-t)+n)/Math.max(1,n*2));for(let a of r.avoid){let o=Math.max(a.left-e,e-a.right,a.top-t,t-a.bottom)-n-r.margin;i*=an(o/Xt.fadePixels)}return i}function sn(){let e=new r;e.name=`courtyard-birds`;let n=nn(`all`),i=rn(),a=new u(new Float32Array(3),1).setUsage(E),o=new u(new Float32Array(3),1).setUsage(E);n.setAttribute(`birdAlpha`,a),n.setAttribute(`birdWing`,o);let s=new L(n,i,3);s.name=`courtyard-birds-complete`,s.castShadow=!1,s.receiveShadow=!1,s.instanceMatrix.setUsage(E),s.boundingBox=new I(new t(-11,3.8,-10),new t(11,6.2,11)),s.boundingSphere=s.boundingBox.getBoundingSphere(new j),e.add(s);let c=Xt.routes.map(()=>en()),l=c.map(()=>({x:0,y:0,radius:0,alpha:0})),d=new t,f=new t,m=new p,h=NaN,g=NaN,_=``,v=!1;return{root:e,metadata:{birds:3,newGeometries:1,newTextures:0,maximumColorDrawCalls:1,extraPasses:0,castsShadows:!1,trianglesPerBird:n.getAttribute(`position`).count/3},update(e){if(!(v||e===h)){h=e;for(let t=0;t<c.length;t++)tn(e,t,c[t])}},present(t,n){if(v||g===h&&_===n.key)return;g=h,_=n.key;let r=n.bounds.right-n.bounds.left,i=n.bounds.bottom-n.bounds.top,u=0;for(let e=0;e<c.length;e++){let p=c[e],h=l[e];d.copy(p.position).project(t),h.x=n.bounds.left+(d.x*.5+.5)*r,h.y=n.bounds.top+(.5-d.y*.5)*i,h.radius=p.scale*Xt.bodyRadius*Math.abs(t.projectionMatrix.elements[5])*i*.5,h.alpha=d.z<-1||d.z>1?0:on(h.x,h.y,h.radius,n),h.alpha<Xt.minimumAlpha||(m.compose(p.position,p.rotation,f.setScalar(p.scale)),s.setMatrixAt(u,m),a.setX(u,h.alpha),o.setX(u,p.leftWing),u++)}s.count=u,e.visible=u>0,u&&(s.instanceMatrix.needsUpdate=!0,a.needsUpdate=!0,o.needsUpdate=!0)},snapshot(){return{time:h,visible:s.count,poses:c.map((e,t)=>({id:t,position:e.position.toArray(),rotation:e.rotation.toArray(),leftWing:e.leftWing,rightWing:e.rightWing,flap:e.flap,bank:e.bank,scale:e.scale,speed:e.speed,phase:e.phase,screen:{...l[t]}}))}},dispose(){v||(v=!0,s.dispose(),n.dispose(),i.dispose(),e.removeFromParent(),e.clear())}}}function cn(e={},t=`legacy`,n=`legacy`,r=!1,i=!1){let a=he(e),o=Gt(r&&a.options.enabled,a.time.value),c=Yt(o),l=new ne;l.background=new C(R.grassBase);let u=new P;u.position.set(...z.camera.position),u.lookAt(...z.camera.target),u.near=z.camera.near,u.far=z.camera.far;let d=new re(z.ground.size,z.ground.size),p=Ce(a),m=new f(d,p);m.name=`courtyard-ground`,m.rotation.x=-Math.PI/2,m.receiveShadow=!0,l.add(m);let h=Ie(),g=We(h);l.add(g.root);let _;if(t===`refined`)try{_=zt(l,h)}catch(e){console.warn(`Pool finish unavailable; original fountain retained.`,e)}let v=Ft(h,n);l.add(v.root);let y=new s(R.highlight,R.stoneShade,B.fill.intensity);y.name=`courtyard-fill`;let b=new ie(R.highlight,B.sun.intensity);b.name=`courtyard-sun`,b.position.set(...B.sun.position),b.castShadow=B.shadows.enabled;let x=B.shadows;b.shadow.mapSize.setScalar(x.mapSize),b.shadow.camera.left=-x.extent,b.shadow.camera.right=x.extent,b.shadow.camera.top=x.extent,b.shadow.camera.bottom=-x.extent,b.shadow.camera.near=x.near,b.shadow.camera.far=x.far,b.shadow.bias=x.bias,b.shadow.normalBias=x.normalBias,b.shadow.radius=x.radius,l.add(y,b,b.target);let S=z.camera.viewHeight,w=1;function T(e){w=e;let t=S/2;u.left=-t*e,u.right=t*e,u.top=t,u.bottom=-t,u.updateProjectionMatrix()}T(1),u.updateMatrixWorld(!0);let E=tt(u,a);l.add(E.root);let D=a.options.enabled&&a.options.petals?It():void 0;D&&(D.update(a.time.value),l.add(D.mesh)),c.bind(l);let O;if(i&&a.options.enabled)try{O=sn(),O.update(a.time.value),l.add(O.root)}catch(e){console.warn(`Birds unavailable; original courtyard retained.`,e)}let k=!1;return{scene:l,camera:u,setAspect:T,setViewHeight(e){if(!Number.isFinite(e)||e<=0)throw RangeError(`Camera view height must be positive.`);e!==S&&(S=e,T(w))},update(e){v.update(e),a.time.value=e,o.update(e),O?.update(e),D?.update(e)},waterState:h,fountainStyle:_?`refined`:t===`refined`?`fallback`:`legacy`,fountainMetadata:_?.metadata,orbStyle:v.root.userData.orbStyle??(n===`legacy`?`legacy`:`fallback`),orbMetadata:v.root.userData.orbMetadata,environmentState:a,cloudShadows:c,birds:O,dispose(){k||(k=!0,c.dispose(),O?.dispose(),d.dispose(),p.dispose(),_?.dispose(),g.dispose(),E.dispose(),v.dispose(),D?.dispose(),b.shadow.dispose(),l.clear())}}}var ln=[320,384,448],un={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function dn(e){let t=Number(e.get(`pixelSize`));return{resolution:ln.some(e=>e===t)?t:un.resolution,finish:e.get(`finish`)===`soft`?`soft`:un.finish,storage:`auto`}}function fn(t,n){let r=n.storage!==`byte`&&t.extensions.has(`EXT_color_buffer_float`),o=new c(1,1,{type:r?a:ae,minFilter:M,magFilter:M,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});o.texture.colorSpace=r?i:y,o.texture.name=`courtyard-pixel-scene`;let s=new N;s.setAttribute(`position`,new e([-1,-1,0,3,-1,0,-1,3,0],3)),s.setAttribute(`uv`,new e([0,0,2,0,0,2],2));let l=un.finishes[n.finish],u=new b({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:o.texture},uSampleSize:{value:new A(1,1)},uLevels:{value:l.levels},uDither:{value:l.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),d=new ne,p=new P(-1,1,1,-1,0,1),m=new f(s,u);m.frustumCulled=!1,d.add(m);let h=!1,g=0;function _(){o.dispose(),s.dispose(),u.dispose()}return{releaseGpuResources:_,resize(e,t){let r=Math.min(1,n.resolution/Math.max(e,t)),i=Math.max(1,Math.round(e*r)),a=Math.max(1,Math.round(t*r));(i!==o.width||a!==o.height)&&(o.setSize(i,a),u.uniforms.uSampleSize.value.set(i,a),g++)},render(e,n){t.setRenderTarget(o),t.render(e,n),t.setRenderTarget(null),t.render(d,p)},getInfo(){return{sampleWidth:o.width,sampleHeight:o.height,designResolution:n.resolution,finish:n.finish,storage:r?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:l.levels,dither:l.dither,allocations:g}},dispose(){h||(h=!0,_(),d.clear())}}}function pn(e){let t=new Set,n=new Set,r=new Set;e.traverse(e=>{if(e instanceof f||e instanceof x){t.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])n.add(t)}e instanceof L&&e.dispose(),e instanceof ie&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of t)e.dispose();for(let e of n){for(let t of Object.values(e))t instanceof g&&r.add(t);if(e instanceof b)for(let t of Object.values(e.uniforms)){let e=Array.isArray(t.value)?t.value:[t.value];for(let t of e)t instanceof g&&r.add(t)}e.dispose()}for(let e of r)e.dispose()}function mn(e,t,n,r=dn(new URLSearchParams),i){let a=new oe({antialias:!1,alpha:!1});a.outputColorSpace=y,a.toneMapping=0,a.shadowMap.enabled=!0,a.shadowMap.type=1,a.shadowMap.autoUpdate=!1,a.shadowMap.needsUpdate=!0,a.info.autoReset=!1;let o=fn(a,r),s=new A,c=a.domElement;c.setAttribute(`role`,`img`),c.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(c);let l=t,u=!1,d=!1,f=!1,p=!1,m=!0,h,g,_,v=0,b=0,x=0,S=0;function C(){_!==void 0&&cancelAnimationFrame(_),_=void 0,v=0}function w(){u||d||p||m||!h||_!==void 0||v===0||(_=requestAnimationFrame(e=>{_=void 0,v--,u||d||p||m||(h?.(e),w())}))}function T(){u||d||p||m||!h||(v=Math.max(v,2),w())}function E(){let e=!u&&!d&&!p;(!e||m)&&C(),a.setAnimationLoop(e&&m&&h?h:null),e&&!m&&T()}function D(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||u)return;let r=Math.min(window.devicePixelRatio||1,pe.maxDevicePixelRatio),i=Math.max(1,Math.floor(t.width)),d=Math.max(1,Math.floor(t.height));(i!==b||d!==x||r!==S)&&(b=i,x=d,S=r,a.setPixelRatio(r),a.setSize(i,d,!1),a.getDrawingBufferSize(s),o.resize(s.x,s.y)),c.dataset.renderMode=l;let f=o.getInfo();c.dataset.sampleWidth=String(l===`pixel`?f.sampleWidth:s.x),c.dataset.sampleHeight=String(l===`pixel`?f.sampleHeight:s.y),c.dataset.pixelProfile=String(f.designResolution),c.dataset.finish=f.finish,n(t.width/t.height),T()}function O(t){t.preventDefault(),d=!0,f=!0,e.dataset.renderState=`context-lost`,E(),o.releaseGpuResources(),g&&pn(g),i?.(`context-lost`)}function k(){d=!1,b=0,a.shadowMap.needsUpdate=!0,i?.(`restored`),D(),E()}c.addEventListener(`webglcontextlost`,O),c.addEventListener(`webglcontextrestored`,k);let j=new ResizeObserver(D);j.observe(e),window.addEventListener(`resize`,D);let M;function N(){M?.removeEventListener(`change`,P),M=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),M.addEventListener(`change`,P)}function P(){N(),D()}return N(),D(),{canvas:c,setMode(e){l=e,D()},setAnimating(e){m=e,E()},setSuspended(e){p!==e&&(p=e,E())},renderOnce(){h?.(performance.now()),T()},getStats(){return{geometries:a.info.memory.geometries,textures:a.info.memory.textures,programs:a.info.programs?.length??0,calls:a.info.render.calls,triangles:a.info.render.triangles,mode:l,outputWidth:a.domElement.width,outputHeight:a.domElement.height,pixel:l===`pixel`?o.getInfo():null}},start(t,n,r){g=t,h=s=>{u||d||p||(r?.(s),a.info.reset(),l===`pixel`?o.render(t,n):(a.setRenderTarget(null),a.render(t,n)),e.dataset.renderState=`ready`,f&&(f=!1,i?.(`ready`),T()))},E()},dispose(){u||(u=!0,C(),j.disconnect(),window.removeEventListener(`resize`,D),M.removeEventListener(`change`,P),c.removeEventListener(`webglcontextlost`,O),c.removeEventListener(`webglcontextrestored`,k),a.setAnimationLoop(null),h=void 0,g=void 0,o.dispose(),a.dispose(),!a.getContext().isContextLost()&&a.extensions.has(`WEBGL_lose_context`)&&a.forceContextLoss(),c.remove())}}}function hn(e,t=W.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function gn(e,t,n=!1,r={}){let i=window.matchMedia(`(prefers-reduced-motion: reduce)`),a=hn(t),o=n||r.retainReducedPause&&i.matches?!0:null,s=!1;function c(){return{playing:!document.hidden&&!(o??i.matches),hidden:document.hidden,reducedMotion:i.matches}}function l(){s||(a.resetTimestamp(),e(c()))}function u(){i.matches&&o!==!0&&(o=r.retainReducedPause?!0:null),l()}return document.addEventListener(`visibilitychange`,l),i.addEventListener(`change`,u),{get state(){return c()},get time(){return a.time},advance(e){return a.tick(e,c().playing)},resetTimestamp:a.resetTimestamp,toggle(){o=!(o??i.matches),l()},dispose(){s||(s=!0,document.removeEventListener(`visibilitychange`,l),i.removeEventListener(`change`,u))}}}export{Xt as a,me as c,fe as d,de as f,se as g,ce as h,cn as i,pe as l,le as m,mn as n,Fe as o,ue as p,dn as r,W as s,gn as t,z as u};