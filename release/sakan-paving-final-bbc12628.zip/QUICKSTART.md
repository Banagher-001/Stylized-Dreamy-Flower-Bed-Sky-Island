# sakan · 创作庭院

成品版本 `sakan-paving-final-bbc12628`。

1. 完整解压 ZIP。
2. 安装 Node.js 22.12 或更高版本。
3. Windows 双击 `START-PREVIEW.cmd`。也可在解压目录的终端运行下列命令。

```bash
node scripts/preview-site.mjs --port 0
```

打开终端显示的本机 HTTP 地址。首页展示八块错落踏石、实体青苔和粒子水球。窄屏可从「水潭」一节进入庭院现场。

预览脚本直接读取包内成品，安装 Node.js 后即可启动。将终端窗口留在运行状态，按 Ctrl+C 可停止服务。
