import { createArtMaterial } from './createArtMaterial';

export function createStoneMaterial() {
  return createArtMaterial('stone');
}
