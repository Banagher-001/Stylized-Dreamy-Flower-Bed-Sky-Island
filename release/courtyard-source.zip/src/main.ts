import './styles.css';
import { pagePalette, paletteSwatches } from './config/palette';
import { renderConfig } from './config/scene';
import type { RenderMode } from './config/scene';
import { createScene } from './scene/createScene';
import { createRenderer } from './rendering/createRenderer';
import type { RendererState } from './rendering/createRenderer';
import { createAnimationController } from './animation/createAnimationController';
import type { AnimationState } from './animation/createAnimationController';
import { waterConfig } from './config/water';
import { resolveVisualOptions } from './config/visual';
import { resolveEnvironmentOptions } from './config/environment';

for (const [name, color] of Object.entries(pagePalette)) {
  document.documentElement.style.setProperty(`--color-${name}`, color);
}

const app = document.querySelector<HTMLDivElement>('#app');
if (!app) throw new Error('Missing application root.');

app.innerHTML = `
  <main class="study">
    <header class="masthead">
      <div class="identity">
        <svg class="mark" viewBox="0 0 32 32" fill="none" aria-hidden="true">
          <path d="m16 3 12 7v13l-12 7-12-7V10Z M4 10l12 7 12-7 M16 17v13" />
        </svg>
        <div>
          <h1>庭院习作</h1>
          <p class="eyebrow">A STUDY OF LIGHT & COLOR</p>
        </div>
      </div>
      <span class="view-label">固定视角<span aria-hidden="true"> ↗</span></span>
    </header>

    <figure class="composition" aria-label="光与颜色的场景习作">
      <div class="scene-host" id="scene-host" data-render-state="loading">
        <p id="scene-notice" class="scene-notice" hidden></p>
      </div>
      <figcaption class="scene-caption">
        <span>一方水池，几段旧时光。</span>
        <span class="caption-note">庭院的轮廓</span>
      </figcaption>
    </figure>

    <section class="tools" aria-label="画面显示设置">
      <p class="tools-label">观看方式</p>
      <div class="tool-actions">
        <div class="mode-controls" role="group" aria-label="渲染模式">
          <button type="button" data-mode="native" aria-pressed="true">正常画面</button>
          <button type="button" data-mode="pixel" aria-pressed="false">像素预览</button>
        </div>
        <button type="button" id="motion-control" class="motion-control">暂停动效</button>
      </div>
    </section>

    <footer class="palette-footer" aria-label="场景基础色板">
      <span class="palette-title">庭院色谱</span>
      <ul class="swatches"></ul>
    </footer>
    <p id="render-status" class="sr-only" role="status" aria-live="polite"></p>
  </main>
`;

const swatches = app.querySelector<HTMLUListElement>('.swatches')!;
for (const swatch of paletteSwatches) {
  const item = document.createElement('li');
  item.className = 'swatch';
  item.title = `${swatch.name} ${swatch.color}`;
  const chip = document.createElement('span');
  chip.className = 'swatch-chip';
  chip.style.backgroundColor = swatch.color;
  chip.setAttribute('aria-hidden', 'true');
  const label = document.createElement('span');
  label.textContent = swatch.name;
  item.append(chip, label);
  swatches.append(item);
}

const host = app.querySelector<HTMLDivElement>('#scene-host')!;
const sceneNotice = app.querySelector<HTMLParagraphElement>('#scene-notice')!;
const status = app.querySelector<HTMLParagraphElement>('#render-status')!;
const buttons = [...app.querySelectorAll<HTMLButtonElement>('[data-mode]')];
const motionButton = app.querySelector<HTMLButtonElement>('#motion-control')!;
const query = new URLSearchParams(window.location.search);
const requestedMode = query.get('render');
let mode: RenderMode = requestedMode === 'pixel' || requestedMode === 'native'
  ? requestedMode
  : renderConfig.defaultMode;

const world = createScene(resolveEnvironmentOptions(query));
let view: ReturnType<typeof createRenderer> | undefined;
const listenerController = new AbortController();
const timeParameter = query.get('waterTime')?.trim();
const parsedTime = timeParameter ? Number(timeParameter) : NaN;
const fixedTime = Number.isFinite(parsedTime) && parsedTime >= 0 && parsedTime <= 86400 ? parsedTime : undefined;

function syncAnimation(state: AnimationState) {
  motionButton.textContent = state.playing ? '暂停动效' : '播放动效';
  motionButton.title = state.reducedMotion && !state.playing ? '已按减少动态设置暂停，点按可播放' : '';
  host.dataset.motionState = state.hidden ? 'hidden' : state.playing ? 'running' : 'paused';
  view?.setSuspended(state.hidden);
  view?.setAnimating(state.playing);
}
const animation = createAnimationController(syncAnimation, fixedTime ?? waterConfig.initialTime, fixedTime !== undefined);
let recoveryTimer: number | undefined;

function syncRendererState(state: RendererState) {
  if (state === 'restored') {
    animation.resetTimestamp();
    return;
  }
  window.clearTimeout(recoveryTimer);
  recoveryTimer = undefined;
  const lost = state === 'context-lost';
  sceneNotice.hidden = !lost;
  for (const button of [...buttons, motionButton]) button.disabled = lost;
  if (lost) {
    sceneNotice.textContent = '画面正在恢复，请稍候。';
    status.textContent = '图形连接中断，正在恢复画面。';
    recoveryTimer = window.setTimeout(() => {
      sceneNotice.textContent = '画面恢复较慢，可刷新页面重试。';
      status.textContent = sceneNotice.textContent;
    }, 4000);
  } else status.textContent = '画面已恢复。';
}

function updateControls() {
  for (const button of buttons) {
    button.setAttribute('aria-pressed', String(button.dataset.mode === mode));
  }
  status.textContent = mode === 'pixel' ? '已切换为像素预览。' : '已切换为正常画面。';
}

try {
  view = createRenderer(host, mode, world.setAspect, resolveVisualOptions(query), syncRendererState);
  view.start(world.scene, world.camera, (timestamp) => {
    const time = animation.advance(timestamp);
    world.update(time);
    host.dataset.waterTime = time.toFixed(6);
    host.dataset.sceneTime = time.toFixed(6);
  });
  syncAnimation(animation.state);
  updateControls();

  motionButton.addEventListener('click', () => {
    animation.toggle();
    status.textContent = animation.state.playing ? '场景动效已继续。' : '场景动效已暂停。';
  }, { signal: listenerController.signal });

  for (const button of buttons) {
    button.addEventListener('click', () => {
      mode = button.dataset.mode as RenderMode;
      view?.setMode(mode);
      const url = new URL(window.location.href);
      if (mode === renderConfig.defaultMode) url.searchParams.delete('render');
      else url.searchParams.set('render', mode);
      window.history.replaceState(null, '', url);
      updateControls();
    }, { signal: listenerController.signal });
  }
} catch (error) {
  view?.dispose();
  world.dispose();
  host.dataset.renderState = 'error';
  const message = document.createElement('p');
  message.className = 'render-error';
  message.setAttribute('role', 'alert');
  message.textContent = '场景暂时无法显示，请开启浏览器图形加速后刷新页面。';
  host.replaceChildren(message);
  for (const button of buttons) button.disabled = true;
  motionButton.disabled = true;
  animation.dispose();
  status.textContent = '场景初始化失败。';
  console.error('Scene initialization failed.', error);
}

function dispose() {
  window.clearTimeout(recoveryTimer);
  listenerController.abort();
  animation.dispose();
  view?.dispose();
  world.dispose();
}

if (import.meta.hot) {
  import.meta.hot.accept();
  import.meta.hot.dispose(dispose);
}
