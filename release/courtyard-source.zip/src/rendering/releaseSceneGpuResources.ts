import { DirectionalLight, InstancedMesh, Mesh } from 'three';
import type { BufferGeometry, Material, Scene } from 'three';

/** Detach the lost GPU generation while retaining all CPU scene/instance data. */
export function releaseSceneGpuResources(scene: Scene) {
  const geometries = new Set<BufferGeometry>();
  const materials = new Set<Material>();
  scene.traverse((object) => {
    if (object instanceof Mesh) {
      geometries.add(object.geometry);
      for (const material of Array.isArray(object.material) ? object.material : [object.material]) {
        materials.add(material);
      }
    }
    if (object instanceof InstancedMesh) object.dispose();
    if (object instanceof DirectionalLight) {
      object.shadow.map?.dispose();
      object.shadow.mapPass?.dispose();
    }
  });
  for (const geometry of geometries) geometry.dispose();
  for (const material of materials) material.dispose();
}
