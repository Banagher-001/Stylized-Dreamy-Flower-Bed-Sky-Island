# sakan · 张辰翰的个人作品集

以固定正交镜头的风格化庭院作为动态封面的个人作品集，采用 Three.js + TypeScript + Vite。页面依次为封面、个人介绍与作品策展展示。

当前阶段：**个人作品集扩展**。使用张辰翰 / sakan（萨坎）的真实介绍：现于枫叶互动制作 AI 动画，此前在游族网络工作，创作涵盖 AI 图像、AI 视频和 Vibe Coding。新增错位作品编排、分类筛选、项目档案弹窗、视频与画面切片；庭院离屏或被弹窗覆盖时停止绘制。当前草稿尚未发布，也未提交/推送到 GitHub。

设计和内容替换位置见 [个人作品集说明](docs/portfolio-design.md)，本轮结果见 [作品集验证记录](docs/portfolio-verification.md)。两张 AI 概念主视觉已标注为网页设计样片，尚未替换为个人真实影像项目。真实手机、物理 GPU 帧率及 Safari 实机尚未验证；Firefox 的已知深度比较采样提示继续单列。

第 1～9 步的场景建设与验证保留为历史记录，包括 [第九步验收](docs/step-9-final-verification.md) 和 [平台覆盖表](docs/step-9-platform-matrix.md)，不将其旧页面的测试计数当作本轮作品集结果。

## 环境

已验证 Node.js **24.22.1**、npm **11.9.0**。`.nvmrc` 记录实际使用的 Node.js 版本。

依赖版本：Three.js **0.187.0**、Vite **8.3.5**、TypeScript **7.0.2**、`@types/three` **0.187.0**。完整依赖由 `package-lock.json` 锁定。

浏览器需要支持 WebGL 2。没有后端、数据库、外部图片服务或 API 密钥要求。应用运行不请求 CDN。

## 启动

在仓库根目录执行：

```bash
npm ci
npm run dev
```

开发服务器默认使用 5173 端口。此云任务中的仓库路径为 `/workspace/Stylized-Dreamy-Flower-Bed-Sky-Island`。使用现有隔离任务和 checkout，无需创建 Git worktree。

云环境可使用工作区内缓存，避免写入受保护的用户目录：

```bash
npm ci --cache /workspace/.cache/npm
```

复装依赖前先停止自己启动的开发 / 预览进程，安装完成后重新启动，避免旧进程引用失效的 Vite 依赖预构建缓存。

## 类型检查与生产构建

```bash
npm run typecheck
npm run build
npm run preview
```

`build` 会先运行严格类型检查，再生成 `dist/`。`preview` 默认使用 4173 端口；它用于检查产物，不是面向公网的生产服务器。可用 `-- --port 4173 --strictPort` 固定端口。

Vite 将 Three.js 的核心与 WebGL 渲染模块分包，应用逻辑单独输出；没有提高告警阈值或禁用检查。

需要复验实际 gzip 传输时，在构建后运行：

```bash
node scripts/serve-dist.mjs dist 4174
```

此工具只监听本机，入口使用 `no-cache`，哈希资源使用长期缓存；重新构建后须重启。它用于本地产物验证。网站可直接将 `dist/` 的内容作为静态站点根目录，配置详情见 [交付说明](docs/step-9-handoff.md)。

## 画面调整位置

| 文件 | 用途 |
| --- | --- |
| `src/config/palette.ts` | 场景与页面色板、展示色块 |
| `src/content/portfolio.ts` | 姓名、化名、介绍、经历、能力、项目和媒体内容 |
| `src/portfolio/createPortfolio.ts` | 页面结构、分类、项目档案、焦点与滚动入场 |
| `src/assets/` | 本地项目主视觉、分镜与无声动效视频，由 Vite 输出哈希资源 |
| `src/config/scene.ts` | 已确认的固定镜头、地面与默认观看方式 |
| `src/config/visual.ts` | 像素采样档位、默认值与可选色阶处理 |
| `src/config/environment.ts` | 草花弯曲、树影微动、可选飘花与对照参数 |
| `src/config/lighting.ts` | 主光、补光、阴影精度、初步树影遮罩 |
| `src/config/stone.ts` | 石头倒角、接缝、分层、缺口变体和细微色差 |
| `src/config/vegetation.ts` | 分布种子、草花数量、聚集与留白区域、地面变化和树影细节 |
| `src/config/water.ts` | 水色、流速、水柱、水滴、波纹、固定种子和初始时间 |
| `src/config/layout.ts` | 喷泉、柱子、矮墙与石板的位置、尺寸、旋转 |
| `src/scene/createScene.ts` | 场景组装、基础光照与资源清理 |
| `src/scene/createBlockout.ts` | 沿用原组装入口，生成六组已细化的石头建筑，复用几何体与材质 |
| `src/geometry/createStoneBlockGeometry.ts` | 封闭凸多面体石块、平面倒角、缺角与稳定色差属性 |
| `src/geometry/createFlowerGeometry.ts` | 低模草簇、短茎和四瓣/五瓣花头 |
| `src/scene/createVegetation.ts` | 建筑避让、固定分布、实例矩阵/颜色与资源清理 |
| `src/scene/createFountainEffects.ts` | 解析水滴轨迹、中央出水、落水事件和实例复用 |
| `src/scene/createFloatingPetals.ts` | 默认关闭的固定容量飘花对照 |
| `src/animation/createAnimationController.ts` | 统一时钟、暂停/恢复、减少动态和可见性事件 |
| `src/animation/environmentMotion.ts` | 共享环境状态、独立风相位与解析参考 |
| `src/materials/createArtMaterial.ts` | 共享风格化颜色响应，保留 Three.js 实际投影管线 |
| `src/materials/createGroundMaterial.ts` | 草地受光色、建筑阴影与地面树影 |
| `src/materials/createStoneMaterial.ts` | 暖顶面、浅侧面、蓝青暗面 |
| `src/materials/createWaterMaterial.ts` | 水面反射色块、短弧波纹、落水波纹和水体明暗，保留实际投影 |
| `src/materials/createVegetationMaterial.ts` | 双面植物材质，接收建筑投影和美术树影 |
| `src/materials/applyEnvironmentMotion.ts` | GPU 圆弧弯曲、同步法线与稳定的树影扰动 |
| `src/rendering/createRenderer.ts` | 输出尺寸、DPR 变化、模式切换与循环清理 |
| `src/rendering/createPixelPipeline.ts` | 低分辨率目标、最近邻取样、单次 sRGB 输出与资源释放 |
| `src/rendering/releaseSceneGpuResources.ts` | 上下文丢失时释放旧 GPU 缓存，保留可重建的场景数据 |
| `src/styles.css` | 方形布局、响应式页面与控件 |
| `src/main.ts` | 初始化、模式切换、无障碍状态、热更新清理 |

相机采用 `position`、`target`、`viewHeight` 配置；无拖拽或缩放控制。窗口变化只更新投影与画布尺寸，不改变构图。

## 像素预览

默认进入像素预览，使用页面上的「正常画面」「像素预览」按钮切换。`?render=native` 明确指定正常模式，`?render=pixel` 指定像素模式。其他值使用默认模式。

- 两种模式的输出画布均为 CSS 显示尺寸 × DPR，DPR 上限为 2。
- 正常模式直接渲染；像素模式先采样到长边默认 **384** 的离屏目标，再按源像素中心最近邻放大。小窗口的采样尺寸不超过实际输出尺寸。
- 例如 680×680 的显示区域，DPR 1 的输出为 680×680，DPR 2 的输出为 1360×1360；两者的默认像素场景采样均为 384×384。
- 比较参数 `pixelSize=320`、`pixelSize=384`、`pixelSize=448`；无效值使用 384。默认 `clean` 保持原色，`finish=soft` 用于可选的轻微色阶/静态抖动对照。
- 非整数放大保持最近邻、不混色；相邻像素块宽度可相差一个物理像素。文字、按钮、色板保持正常清晰度。

第七步已替换早期的 CSS 尺寸 0.5 倍预览。采样格式优先使用线性半浮点，缺少扩展时使用 sRGB8；第九步在三种引擎中分别检查了两条路径的 GPU 色板与棋盘。完整参数和对照见 [第七步记录](docs/step-7-pixel.md)。真实设备与硬件性能的覆盖范围见平台表。

## 整场景动效与固定时间

- 页面「暂停动效」「播放动效」按钮控制喷泉、草花、树影及启用后的飘花，支持键盘和触摸。
- 系统启用“减少动态”时默认静止，用户可主动播放。
- 页面隐藏事件停止时间推进和绘制，恢复时重置帧时间基准，避免快进。
- 暂停时只按需要重绘。水与植物保持不投射新的细碎阴影，静态建筑阴影图复用。
- 验收参数 `?waterTime=2` 继续兼容；第八步起固定整场景时间为 2 秒并暂停。可与 `render=pixel` 组合。允许 0～86400 的有限数值；空值、负值、非有限数及超范围值回到默认状态，并尊重减少动态设置。
- 固定时间只决定初始验收状态，点击播放后可以继续。种子与时间相同时，水滴、波纹、草花、树影及画面可复现。

环境对照参数：`env=off` 关闭第八步新增环境动效，可精确恢复第七步；`wind=off` 关闭草花轻摆；`canopy=off` 关闭新增树影变化并保留原静态树影；`petals=on` 开启稀疏飘花对照。它们只用于 URL/配置对照，不增加界面控件。完整参数见 [第八步记录](docs/step-8-environment-motion.md)。

控件最小触达尺寸为 44×44 CSS 像素。图形上下文中断时显示恢复提示并暂时禁用控件，恢复后保持原暂停状态。无 WebGL 2 时显示可读提示；不支持图形渲染的设备无法显示三维场景。

[5 秒动效演示](docs/evidence/step-6/water-demo.mp4)按 1/12 秒间隔采样渲染，展示设计时间轴，不是实时设备帧率测试。

[第七步像素动效演示](docs/evidence/step-7/pixel-demo.mp4)使用相同采样方法，默认 384 档。

[第八步 12 秒场景动效](docs/evidence/step-8/environment-demo.mp4)以固定设计时间采样，包含水、草花和树影；不是硬件帧率测试。

## 视觉与验证资料

- [当前作品集设计与内容说明](docs/portfolio-design.md)
- [当前作品集验证记录](docs/portfolio-verification.md)
- [当前作品集检查工具](tests/portfolio/README.md)
- [第一步视觉基准](docs/visual-baseline.md)
- [第一步验收报告](docs/step-1-verification.md)
- [第二步构图与执行记录](docs/step-2-composition.md)
- [第二步验收报告](docs/step-2-verification.md)
- [第三步光影与参数记录](docs/step-3-lighting.md)
- [第三步验收报告](docs/step-3-verification.md)
- [第四步石头建筑与参数记录](docs/step-4-stone.md)
- [第四步验收报告](docs/step-4-verification.md)
- [第五步环境与参数记录](docs/step-5-environment.md)
- [第五步验收报告](docs/step-5-verification.md)
- [第六步水动效与参数记录](docs/step-6-water.md)
- [第六步验收报告](docs/step-6-verification.md)
- [第七步像素尺度与执行记录](docs/step-7-pixel.md)
- [第七步验收报告](docs/step-7-verification.md)
- [第八步环境微动与执行记录](docs/step-8-environment-motion.md)
- [第八步验收报告](docs/step-8-verification.md)
- [第九步最终验收报告](docs/step-9-final-verification.md)
- [第九步平台覆盖与实机补验](docs/step-9-platform-matrix.md)
- [第九步交付说明](docs/step-9-handoff.md)
- [可选复验工具](tests/final/README.md)
- 各步截图保存在 `docs/evidence/step-1/` 至 `docs/evidence/step-9/`；[第九步证据索引](docs/evidence/step-9/README.md) 区分最终结果与诊断过程。

`release/courtyard-*.zip` 与 `release/manifest.json` 保留为第九步独立场景的交付快照。当前个人作品集使用 `release/portfolio-source.zip`、`release/portfolio-site.zip` 和 `release/portfolio-manifest.json`。没有发布环境、部署网站或推送仓库。
