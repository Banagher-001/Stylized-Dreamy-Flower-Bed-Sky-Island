# sakan · 庭院预览

版本 `particle-orb-step7-99634b67a4c3f8f7`。

1. 完整解压本压缩包。
2. 安装 Node.js 24 LTS，或使用 Node.js 22.12 及以上版本。
3. Windows 双击 `START-PREVIEW.cmd`。也可以在解压目录的终端运行以下命令。

```bash
node scripts/preview-site.mjs --port 0
```

打开终端显示的完整本机 HTTP 地址。普通首页会显示完整的粒子水球，滚到「水潭」看近景。窄屏在「水潭」一节选择「进入庭院现场」。需要回看旧水球时，在地址末尾加 `?orb=lively`。

成品包含站内的罗森便利店和瓶中海洋，可用同一个本地服务浏览。观看时请保留终端窗口，按 Ctrl+C 停止。
