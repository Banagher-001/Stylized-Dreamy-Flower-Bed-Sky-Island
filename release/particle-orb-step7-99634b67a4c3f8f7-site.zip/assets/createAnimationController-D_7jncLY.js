import{A as e,An as t,E as n,F as r,G as i,I as a,J as o,L as s,Mn as c,On as l,R as u,T as d,X as f,Y as p,Z as m,_ as h,a as g,at as _,bn as v,dn as y,dt as b,et as x,f as S,ft as C,gn as w,hn as T,k as E,kn as D,ln as O,mn as k,nt as A,o as j,ot as M,pn as N,q as P,r as F,sn as ee,st as te,u as ne,un as I,ut as re,w as L,z as R}from"./three-core-BVdTLq0G.js";import{t as ie}from"./three-renderer-C2PiHy76.js";var z={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},ae={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`};z.grassBase,z.stoneLight,z.stoneShade,z.treeShadow,z.waterBase,z.flower;var oe=new URL(`courtyard-motion-7fR7fsF8.mp4`,import.meta.url).href,se=new URL(`courtyard-keyframe-00-Dnvt_afN.png`,import.meta.url).href,ce=new URL(`courtyard-keyframe-03-BpIvPl5V.png`,import.meta.url).href,le=new URL(`signal-garden-CbiDrnMk.webp`,import.meta.url).href,ue=new URL(`liquid-form-Yl5oqdSL.webp`,import.meta.url).href,de={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},fe={defaultMode:`pixel`,maxDevicePixelRatio:2},B={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},V={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},column:{layerRatios:[1.07,.96,1.03,.94],layerSeeds:[11,29,47],layerChips:[0,.028,.052],baseBevel:.024,capBevel:.038,profiles:[{layers:[0,1,0,2],offsets:[-.012,.012,-.008,0],capCorner:2,capChip:.12},{layers:[1,2,0,1],offsets:[.008,-.01,.01,0],capCorner:1,capChip:.095},{layers:[2,0,1,0],offsets:[-.008,.012,-.008,0],capCorner:3,capChip:.145}]},fountain:{copingHeight:.14,jointWidth:.032,bevel:.024,chippedSegments:[1,5],chipSize:.1},wall:{bodyBlocks:3,capBlocks:2},path:{bevel:.014,cornerCut:.045,chippedSlabs:[1,4,6],chipSize:.065}},H={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25]},grass:{count:240,gapCount:12,minHeight:.065,maxHeight:.14,clearance:.06,gapMinHeight:.105,gapMaxHeight:.13,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},U={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function pe(e){return{enabled:e.get(`env`)!==`off`&&U.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||U.petals.enabled}}var W={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function me(e={}){let t={...pe(new URLSearchParams),...e};return{options:t,time:{value:W.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function he(e,t){let n=Math.sin(e*12.9898+t*78.233+U.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var ge=Math.hypot(...U.wind.direction),_e=[U.wind.direction[0]/ge,U.wind.direction[1]/ge],G=e=>e.toFixed(10),ve=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${_e.map(G).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,ye=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function be(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${ve}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${ye}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${G(U.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${G(U.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function xe(e,n,r={}){let i=new x,a=e===`foliage`||e===`flower`;i.name=`courtyard-${e}`,i.userData.artSurface=e;let o=n?.options.enabled&&(a||e===`ground`);return i.customProgramCacheKey=()=>`courtyard-art-${e}-v3${o?`-environment-v1`:``}`,i.onBeforeCompile=i=>{let s=B.treeShadows,c=H.ground,l=H.treeDetail;Object.assign(i.uniforms,{uArtSunAmount:{value:B.sun.intensity},uArtFillAmount:{value:B.fill.intensity},uArtStoneVariation:{value:V.colorVariation},uArtGrass:{value:new S(z.grassBase)},uArtGrassLight:{value:new S(z.grassLight)},uArtGrassDark:{value:new S(z.grassDark)},uArtGrassShadow:{value:new S(z.treeShadow)},uArtStoneTop:{value:new S(r.top??z.stoneLight)},uArtStoneSide:{value:new S(r.side??z.stoneSide)},uArtStoneShade:{value:new S(r.shade??z.stoneShade)},uArtWater:{value:new S(z.waterBase)},uArtWaterShade:{value:new S(z.waterShade)},uArtPlantShade:{value:new S(z.plantShade)},uArtFlowerShade:{value:new S(z.flowerShade)},uArtFlowerCenter:{value:new S(z.flowerCenter)},uArtGroundEnabled:{value:+!!c.enabled},uArtGroundScales:{value:new t(c.macroScale,c.macroStrength,c.detailScale,c.detailStrength)},uArtGroundDensity:{value:c.detailDensity},uArtQuietRegion:{value:new t(c.quietCenter[0],c.quietCenter[1],c.quietRadius[0],c.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!l.enabled},uArtTreeDetail:{value:new t(l.branchScale,l.leafScale,l.edgeBreakup,l.gapStrength)},uArtTreesEnabled:{value:+!!s.enabled},uArtTreeNoiseScale:{value:s.edgeNoiseScale},uArtTreeNoiseAmount:{value:s.edgeNoiseAmount},uArtTreeSoftness:{value:s.edgeSoftness},uArtTreePatches:{value:s.patches.map(e=>new t(e.center[0],e.center[1],e.radius[0],e.radius[1]))},uArtTreeRotations:{value:s.patches.map(e=>e.rotation)}}),i.vertexShader=i.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${e===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${a?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${e===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${a?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let u=`
      varying vec3 vArtWorldPosition;
      ${e===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${a?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${s.patches.length}];
      uniform float uArtTreeRotations[${s.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${s.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;i.fragmentShader=i.fragmentShader.replace(`#include <common>`,`#include <common>\n${u}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[e]}\n#include <opaque_fragment>`),o&&be(i,a,n)},i}function Se(e){return xe(`ground`,e)}var K={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08,baseHeight:.18,shaftWidth:.72,shaftDepth:.78,shaftHeight:3.05,capWidth:1.02,capDepth:1.04,capHeight:.24},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,columns:4,rows:2,stepX:.74,stepZ:.63,slabWidth:.63,slabDepth:.52,slabHeight:.09}},q=1e-7;function Ce(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<q*q)||t.push(n);return t}function we(e,t,n){let r=[],i=[];for(let a of e){let e=[];for(let r=0;r<a.length;r++){let o=a[r],s=a[(r+1)%a.length],c=t.dot(o)-n,l=t.dot(s)-n;if(c<=q&&e.push(o),c<-1e-7&&l>q||c>q&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),i.push(t)}else Math.abs(c)<=q&&i.push(o)}let o=Ce(e);o.length>=3&&r.push(o)}let a=Ce(i);if(a.length>=3){let e=a.reduce((e,t)=>e.add(t),new D).divideScalar(a.length),n=Math.abs(t.y)<.9?new D(0,1,0):new D(1,0,0),i=t.clone().cross(n).normalize(),o=t.clone().cross(i).normalize();a.sort((t,n)=>{let r=t.clone().sub(e),a=n.clone().sub(e);return Math.atan2(r.dot(o),r.dot(i))-Math.atan2(a.dot(o),a.dot(i))}),r.push(a)}return r}function Te(t,n){let r=t.getAttribute(`position`),i=Math.sin(n*12.9898+.73)*.65,a=new Float32Array(r.count);for(let e=0;e<r.count;e++)a[e]=i+Math.sin(r.getX(e)*1.6+r.getZ(e)*2.3+n)*.25;return t.setAttribute(`stoneTint`,new e(a,1)),t}function Ee(t,n,r){if(t.length<3||n<=0)throw Error(`Stone prism needs a polygon and positive height.`);let i=t.map(([e,t])=>[e,t]);i.reduce((e,t,n)=>{let r=i[(n+1)%i.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(i=i.reverse());let a=n/2,o=i.map(([e,t])=>new D(e,a,t)),s=i.map(([e,t])=>new D(e,-a,t)),c=[o,[...s].reverse()],l=[];for(let e=0;e<i.length;e++){let t=(e+1)%i.length,n=s[e],r=s[t];c.push([n,r,o[t],o[e]]);let a=r.clone().sub(n).cross(new D(0,1,0)).normalize();l.push({normal:a,distance:a.dot(n)})}let u=Math.min(r.bevel,n*.2);for(let e=0;e<l.length;e++){let t=l[e];for(let e of[-1,1]){let n=t.normal.clone().add(new D(0,e,0)),r=(t.distance+a-u)/n.length();c=we(c,n.normalize(),r)}let n=l[(e+l.length-1)%l.length],i=n.normal.clone().add(t.normal),o=(n.distance+t.distance-r.cornerCut)/i.length();c=we(c,i.normalize(),o)}if(r.chipSize&&r.chipSize>0){let e=(r.chipCorner??0)%l.length,t=l[(e+l.length-1)%l.length],n=l[e],i=t.normal.clone().add(n.normal).add(new D(0,1,0)),o=(t.distance+n.distance+a-r.chipSize)/i.length();c=we(c,i.normalize(),o)}let d=[],f=[];for(let e of c){let t=e.reduce((e,t)=>e.add(t),new D).divideScalar(e.length),n=new D;for(let r=0;r<e.length;r++)n.add(e[r].clone().sub(t).cross(e[(r+1)%e.length].clone().sub(t)));if(!(n.lengthSq()<q*q)){n.normalize();for(let r=0;r<e.length;r++){let i=e[r],a=e[(r+1)%e.length];if(!(i.clone().sub(t).cross(a.clone().sub(t)).lengthSq()<q*q))for(let e of[t,i,a])d.push(e.x,e.y,e.z),f.push(n.x,n.y,n.z)}}}let p=new j;return p.setAttribute(`position`,new e(d,3)),p.setAttribute(`normal`,new e(f,3)),Te(p,r.seed),p.computeBoundingBox(),p.computeBoundingSphere(),p.userData.stoneSolid=!0,p}function De(e,t,n,r){let i=e/2,a=n/2;return Ee([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}function Oe(e){return xe(`stone`,void 0,e)}function ke(){return{time:{value:W.initialTime},impacts:{value:Array.from({length:W.ripples.capacity},()=>new t(0,0,0,0))}}}function Ae(e=ke(),n=`surface`){let r=xe(`water`);r.name=`courtyard-water-${n}`,r.flatShading=n===`jet`,r.userData.waterKind=n,r.customProgramCacheKey=()=>`courtyard-water-${n}-v1`;let i=r.onBeforeCompile.bind(r);return r.onBeforeCompile=(r,a)=>{i(r,a);let o=K.fountain;Object.assign(r.uniforms,{uWaterTime:e.time,uWaterImpacts:e.impacts,uWaterEnabled:{value:+!!W.enabled},uWaterBase:{value:new S(W.colors.base)},uWaterDeep:{value:new S(W.colors.deep)},uWaterShade:{value:new S(W.colors.shade)},uWaterWhite:{value:new S(W.colors.highlight)},uWaterJet:{value:new S(W.colors.jet)},uWaterOrigin:{value:new t(o.position[0],o.position[2],Math.cos(o.rotationY),Math.sin(o.rotationY))},uWaterSurface:{value:new t(W.surface.flowSpeed,W.surface.reflectionThreshold,W.surface.waveSpeed,W.surface.waveStrength)},uWaterRipple:{value:new t(W.ripples.lifetime,W.ripples.speed,W.ripples.strength,o.innerRadius*Math.cos(Math.PI/8))}});let s=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${W.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,c=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,l=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!r.fragmentShader.includes(l))throw Error(`Water shader extension anchor changed.`);r.fragmentShader=r.fragmentShader.replace(`void main() {`,`${s}\nvoid main() {`).replace(l,n===`surface`?c:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},r}function je(e){let t=new r;t.name=`courtyard-blockout`;let n=new Set;function i(e){return n.add(e),e}let a=new Map,o=Oe(),s=Ae(e);function c(e,t,n,r,s,c,l=0,u=0,d={}){let p={bevel:V.bevel,cornerCut:V.cornerCut,seed:11,...d},m=JSON.stringify([n,r,s,p]),h=a.get(m);h||(h=i(De(n,r,s,p)),a.set(m,h));let g=new f(h,o);return g.name=t,g.position.set(l,c+r/2,u),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let l=K.fountain,u=new r;u.name=`fountain`,u.position.set(...l.position),u.rotation.y=l.rotationY,t.add(u);let d=new f(i(Ee(Array.from({length:8},(e,t)=>[Math.cos(t*Math.PI/4)*l.baseRadius,-Math.sin(t*Math.PI/4)*l.baseRadius]),l.baseHeight,{bevel:.018,cornerCut:.025,seed:11})),o);d.name=`fountain-base`,d.position.y=l.baseHeight/2,d.castShadow=!0,d.receiveShadow=!0,u.add(d);let p=new y,m=new te;for(let e=0;e<8;e++){let t=e*Math.PI/4,n=-t,r=Math.cos(t)*l.outerRadius,i=Math.sin(t)*l.outerRadius,a=Math.cos(n)*l.innerRadius,o=Math.sin(n)*l.innerRadius;e===0?(p.moveTo(r,i),m.moveTo(a,o)):(p.lineTo(r,i),m.lineTo(a,o))}p.closePath(),m.closePath(),p.holes.push(m);let h=new r;h.name=`fountain-rim`,h.position.y=l.baseHeight,u.add(h);let g=V.fountain,_=l.rimHeight-g.copingHeight,v=new f(i(Te(new E(p,{depth:_,bevelEnabled:!1,steps:1,curveSegments:1}),11)),o);v.name=`fountain-rim-wall`,v.rotation.x=-Math.PI/2,v.castShadow=!0,v.receiveShadow=!0,h.add(v);function b(e){let t=Math.cos(Math.PI/4)*e,n=-Math.sin(Math.PI/4)*e,r=g.jointWidth/(2*Math.hypot(t-e,n));return[[e+(t-e)*r,n*r],[t+(e-t)*r,n*(1-r)]]}let[x,S]=b(l.outerRadius),[C,w]=b(l.innerRadius),T=new Map;for(let e=0;e<8;e++){let t=g.chippedSegments.some(t=>t===e),n=t?`chip-${e%2}`:`plain-${e%2}`,r=T.get(n);r||(r=i(Ee([x,S,w,C],g.copingHeight,{bevel:g.bevel,cornerCut:.025,seed:29+e%2,chipSize:t?g.chipSize:0,chipCorner:e%2})),T.set(n,r));let a=new f(r,o);a.name=`fountain-coping-${e}`,a.position.y=_+g.copingHeight/2,a.rotation.y=e*Math.PI/4,a.castShadow=!0,a.receiveShadow=!0,h.add(a)}let D=new f(i(new ne(l.innerRadius-.008,8)),s);D.name=`fountain-water`,D.rotation.x=-Math.PI/2,D.position.y=l.waterHeight,D.receiveShadow=!0,u.add(D),c(u,`fountain-pedestal-foot`,l.pedestalFootSize,l.pedestalFootHeight,l.pedestalFootSize,l.baseHeight);let O=l.baseHeight+l.pedestalFootHeight;c(u,`fountain-pedestal`,l.pedestalSize,l.pedestalHeight,l.pedestalSize,O),c(u,`fountain-pedestal-cap`,l.pedestalCapSize,l.pedestalCapHeight,l.pedestalCapSize,O+l.pedestalHeight,0,0,{bevel:.016,chipSize:.06,chipCorner:2,seed:29});let k=K.columnShape;for(let[e,n]of K.columns.entries()){let i=new r;i.name=n.name;let[a,o,s]=n.position;i.position.set(a,o,s),i.rotation.y=n.rotationY;let l=V.column,u=l.profiles[e];c(i,`${n.name}-base`,k.baseWidth,k.baseHeight,k.baseDepth,0,0,0,{bevel:l.baseBevel,chipSize:.04,chipCorner:e%2,seed:29});let d=new r;d.name=`${n.name}-shaft`,i.add(d);let f=V.joints.width,p=l.layerRatios,m=k.shaftHeight-f*(p.length-1),h=p.reduce((e,t)=>e+t,0),g=k.baseHeight;for(let e=0;e<p.length;e++){let t=m*p[e]/h,r=u.layers[e];c(d,`${n.name}-block-${e}`,k.shaftWidth,t,k.shaftDepth,g,u.offsets[e],0,{seed:l.layerSeeds[r],chipSize:l.layerChips[r],chipCorner:r}),g+=t,e<p.length-1&&(c(d,`${n.name}-joint-${e}`,k.shaftWidth-V.joints.recess*2,f,k.shaftDepth-V.joints.recess*2,g,0,0,{bevel:0,cornerCut:0,seed:47}),g+=f)}c(i,`${n.name}-cap`,k.capWidth,k.capHeight,k.capDepth,k.baseHeight+k.shaftHeight,0,0,{bevel:l.capBevel,chipSize:u.capChip,chipCorner:u.capCorner,seed:47+e}),t.add(i)}let A=K.wall,j=new r;j.name=`wallLeft`,j.position.set(...A.position),j.rotation.y=A.rotationY,c(j,`wallLeft-base`,A.length+A.endSize,A.baseHeight,A.baseDepth,0);let M=new r;M.name=`wallLeft-body`,j.add(M);let N=V.wall.bodyBlocks,P=V.joints.width,F=(A.length-(N-1)*P)/N;for(let e=0;e<N;e++){let t=-A.length/2+F/2+e*(F+P);c(M,`wallLeft-body-${e}`,F,A.height,A.depth,A.baseHeight,t,0,{seed:11+e*18,chipSize:e===N-1?.075:0,chipCorner:2}),e<N-1&&c(M,`wallLeft-body-joint-${e}`,P,A.height,A.depth-V.joints.recess*2,A.baseHeight,t+F/2+P/2,0,{bevel:0,cornerCut:0,seed:47})}let ee=new r;ee.name=`wallLeft-cap`,j.add(ee);let I=V.wall.capBlocks,re=(A.length-(I-1)*P)/I;for(let e=0;e<I;e++){let t=-A.length/2+re/2+e*(re+P);c(ee,`wallLeft-cap-${e}`,re,A.capHeight,A.capDepth,A.baseHeight+A.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===I-1?.065:0,chipCorner:2}),e<I-1&&c(ee,`wallLeft-cap-joint-${e}`,P,A.capHeight*.65,A.capDepth-V.joints.recess*2,A.baseHeight+A.height,t+re/2+P/2,0,{bevel:0,cornerCut:0,seed:47})}c(j,`wallLeft-end`,A.endSize,A.endHeight,A.endSize,A.baseHeight,A.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(j);let L=K.path,R=new r;R.name=`pathRight`,R.position.set(...L.position),R.rotation.y=L.rotationY;for(let e=0;e<L.rows;e++)for(let t=0;t<L.columns;t++)c(R,`pathRight-slab-${e}-${t}`,L.slabWidth,L.slabHeight,L.slabDepth,0,(t-(L.columns-1)/2)*L.stepX,(e-(L.rows-1)/2)*L.stepZ,{bevel:V.path.bevel,cornerCut:V.path.cornerCut,seed:11+(e*L.columns+t)%3*18,chipSize:V.path.chippedSlabs.some(n=>n===e*L.columns+t)?V.path.chipSize:0,chipCorner:(e*L.columns+t)%4});t.add(R);let ie=!1;return{root:t,dispose(){if(!ie){ie=!0,t.removeFromParent(),t.clear();for(let e of n)e.dispose();o.dispose(),s.dispose()}}}}function Me(t,n,r){let i=new j;return i.setAttribute(`position`,new e(t,3)),i.setAttribute(`plantPart`,new e(n,1)),i.setAttribute(`plantHeight`,new e(r,1)),i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function Ne(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>Me(e,t,n)}}function Pe(){let e=Ne();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function Fe(){let e=Ne();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function Ie(e){let t=Ne();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function Le(e,t){let n=xe(e,t);return n.side=2,n}function Re(e,t,n,r=.035){let i=K.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=K.columnShape;for(let n of K.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=K.wall;if(f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY))return!1;let h=K.path;for(let n=0;n<h.rows;n++)for(let r=0;r<h.columns;r++){let i=(r-(h.columns-1)/2)*h.stepX,a=(n-(h.rows-1)/2)*h.stepZ;if(f(e,t,h.position[0]+Math.cos(h.rotationY)*i+Math.sin(h.rotationY)*a,h.position[2]-Math.sin(h.rotationY)*i+Math.cos(h.rotationY)*a,h.slabWidth,h.slabDepth,h.rotationY))return!1}return!0}function ze(e,t){let n=new r;n.name=`courtyard-vegetation`;let i=H.seed;function a(){i+=1831565813;let e=Math.imul(i^i>>>15,1|i);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let o=(e,t)=>e+(t-e)*a();function s(t,n){let r=new D(t,0,n).project(e);return Math.abs(r.x)<.98&&Math.abs(r.y)<.98}function c(e,t){let n=H.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let l=[],d=[];if(H.enabled){for(let e=0;l.length<H.grass.count&&e<H.grass.count*120;e++){let e,t;if(a()<.48){let n=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],r=a()*Math.PI*2,i=Math.sqrt(a())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=o(-7.5,7.4),t=o(-8.7,8.4);!s(e,t)||!Re(e,t,H.grass.clearance)||c(e,t)&&a()<.9||l.push({x:e,z:t,height:o(H.grass.minHeight,H.grass.maxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:H.grass.clearance,gap:!1})}for(let e=0;d.length<H.flowers.count&&e<H.flowers.count*120;e++){let e=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],t=a()*Math.PI*2,n=a()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,l=o(H.flowers.minDiameter,H.flowers.maxDiameter),u=l*.55+.01;s(r,i)&&!c(r,i)&&Re(r,i,u)&&(d.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+u)*.85)||d.push({x:r,z:i,height:o(H.flowers.minHeight,H.flowers.maxHeight),diameter:l,rotation:a()*Math.PI*2,color:a(),radius:u,gap:!1}))}if(l.length!==H.grass.count||d.length!==H.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=K.path,t=[];for(let n=0;n<e.rows;n++)for(let r=0;r<e.columns-1;r++)t.push([(r-(e.columns-2)/2)*e.stepX,(n-(e.rows-1)/2)*e.stepZ]);for(let n=0;n<e.columns;n++)t.push([(n-(e.columns-1)/2)*e.stepX,0]);t.push([-e.stepX,0],[e.stepX,0]);for(let[n,r]of t.slice(0,H.grass.gapCount)){let t=e.position[0]+Math.cos(e.rotationY)*n+Math.sin(e.rotationY)*r+o(-.006,.006),i=e.position[2]-Math.sin(e.rotationY)*n+Math.cos(e.rotationY)*r+o(-.006,.006);if(!Re(t,i,.023,.008))throw Error(`Paving gap vegetation intersects stone.`);l.push({x:t,z:i,height:o(H.grass.gapMinHeight,H.grass.gapMaxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:.023,gap:!0})}}let f=[],m=[],h=[];if(H.enabled){let e=Le(`foliage`,t),r=Le(`flower`,t);m.push(e,r);let i=Pe(),a=Fe(),o=Ie(4),s=Ie(5);f.push(i,a,o,s);function c(e,r,i,a,o){let s=new R(r,i,a.length);s.name=e,s.castShadow=!1,s.receiveShadow=!0;let c=new p,l=new C,d=new D(0,1,0),f=new S(o===`flower`?z.flower:o===`stem`?z.plantStem:z.grassBlade),m=new S(o===`flower`?z.flowerLight:z.grassBladeLight);if(a.forEach((e,t)=>{l.setFromAxisAngle(d,e.rotation);let n=o===`flower`?e.diameter:e.height,r=o===`grass`&&e.gap?H.grass.gapWidthScale:1;c.compose(new D(e.x,H.rootHeight+(o===`flower`?e.height:0),e.z),l,new D(n*r,n,n*r)),s.setMatrixAt(t,c),s.setColorAt(t,f.clone().lerp(m,o===`stem`?e.color*.25:o===`flower`?e.color*.6:e.color*.85))}),s.instanceMatrix.needsUpdate=!0,s.instanceColor&&(s.instanceColor.needsUpdate=!0),t?.options.enabled){let e=new Float32Array(a.length*3),t=new Float32Array(a.length*4);a.forEach((n,r)=>{let i=o===`grass`?n.gap?U.wind.gapAngle:U.wind.grassAngle:U.wind.flowerAngle;e.set([n.x,H.rootHeight,n.z],r*3),t.set([n.height,i,he(n.x,n.z),+(o===`flower`)],r*4)}),r.setAttribute(`windRoot`,new u(e,3)),r.setAttribute(`windShape`,new u(t,4))}s.computeBoundingBox(),s.computeBoundingSphere(),t?.options.enabled&&(s.boundingBox.expandByScalar(.02),s.boundingSphere.radius+=.02),s.userData.plants=a,s.userData.plantType=o,h.push(s),n.add(s)}c(`grass-clusters`,i,e,l,`grass`),c(`flower-stems`,a,e,d,`stem`),c(`flowers-four-petal`,o,r,d.filter((e,t)=>t%2==0),`flower`),c(`flowers-five-petal`,s,r,d.filter((e,t)=>t%2==1),`flower`)}n.userData.seed=H.seed,n.userData.counts={grass:l.length,flowers:d.length,batches:h.length};let g=!1;return{root:n,dispose(){if(!g){g=!0;for(let e of h)e.dispose();for(let e of f)e.dispose();for(let e of m)e.dispose();n.removeFromParent(),n.clear()}}}}var Be={primary:{amplitude:.032,period:4,direction:[2.5,2,-1.55]},secondary:{amplitude:.008,period:2.6,direction:[-3.1,1.2,4.4]},stemFade:[-.84,-.48],interiorFollow:.25},J={axis:[.766434,-.575767,.28473],front:[.330778,.733779,.593426],offset:-.306825,frontTime:3.5,crestWidth:[.056,.167],backWeight:.3,colors:{crest:`#E2F5FB`,shade:`#4C8BAE`}},Ve={clearance:.02,beads:[{direction:[-.82,-.26,.51],phase:.36,formationTime:.16,radius:.024,speed:.84,vy:-.06,strength:1.6},{direction:[-.74,-.25,.62],phase:.88,formationTime:.14,radius:.019,speed:.81,vy:-.06,strength:1.12}]},Y={radius:.26,centerY:1.37,floatAmplitude:.03,floatPeriod:6,sphereSegments:[12,8],shape:{first:.025,second:.009,x:.012,y:.015,z:.012,yRatio:.96,envelope:(1.025+.009)*1.012},flow:{mainPeriod:7.2,detailPeriod:4.1,turnPeriod:23,main:[2.2,7.4,.8],bend:[3.2,0,2],bendStrength:.8,detail:[2.1,-3,7]},stemRadius:.04,stemOverlap:.025,releaseLatitude:-.16,releaseMargin:.004,colors:{base:`#80B9D5`,light:`#ADDCE8`,side:`#4D89B2`,shade:`#427192`,white:`#F3FBFF`}},He=Math.PI*2,X=Y.flow,Ue=(e,t)=>(e%t+t)%t/t*He;function We(e,n=new t){let r=Ue(e,X.turnPeriod);return n.set(Math.cos(r),Math.sin(r),Ue(e,X.mainPeriod),Ue(e,X.detailPeriod))}function Ge(e,t,n,r){let i=r.x*e-r.y*n,a=r.y*e+r.x*n,o=i*X.bend[0]+t*X.bend[1]+a*X.bend[2]+r.w,s=i*X.main[0]+t*X.main[1]+a*X.main[2]+X.bendStrength*Math.sin(o)+r.z,c=i*X.detail[0]+t*X.detail[1]+a*X.detail[2]-r.w;return 1+Y.shape.first*Math.cos(s)+Y.shape.second*Math.sin(c)}function Ke(e,t,n,r,i=new D){let a=r.x*e-r.y*n,o=r.y*e+r.x*n,s=a*X.bend[0]+t*X.bend[1]+o*X.bend[2]+r.w,c=a*X.main[0]+t*X.main[1]+o*X.main[2]+X.bendStrength*Math.sin(s)+r.z,l=a*X.detail[0]+t*X.detail[1]+o*X.detail[2]-r.w,u=-Y.shape.first*Math.sin(c),d=Y.shape.second*Math.cos(l),f=X.bendStrength*Math.cos(s),p=u*(X.main[0]+f*X.bend[0])+d*X.detail[0],m=u*(X.main[1]+f*X.bend[1])+d*X.detail[1],h=u*(X.main[2]+f*X.bend[2])+d*X.detail[2],g=r.x*p+r.y*h,_=-r.y*p+r.x*h,v=1+Y.shape.first*Math.cos(c)+Y.shape.second*Math.sin(l),y=e*g+t*m+n*_;return i.set(e-(g-e*y)/v,t-(m-t*y)/v,n-(_-n*y)/v).normalize()}var qe=Math.PI*2/Y.floatPeriod,Je=()=>({y:0,sx:1,sy:1,sz:1});function Ye(e,t=Je()){let n=e*qe;return t.y=Y.centerY+Y.floatAmplitude*Math.sin(n),t.sx=1+Y.shape.x*Math.sin(n*.73),t.sy=Y.shape.yRatio*(1+Y.shape.y*Math.sin(n+.8)),t.sz=1+Y.shape.z*Math.cos(n*.81),t}var Xe=()=>({birthTime:NaN,x:0,y:0,z:0,vx:0,vy:0,vz:0,duration:0,impactX:0,impactZ:0});function Ze(e,t){let n=W.drops.gravity;return(t+Math.sqrt(t*t+2*n*e))/n}function Qe(e,t){return e.duration=Ze(e.y-K.fountain.waterHeight-t,e.vy),e.impactX=e.x+e.vx*e.duration,e.impactZ=e.z+e.vz*e.duration,e}var $e=Je(),et=new t,tt=new D;function nt(e,t,n=Xe()){let r=Ye(t,$e),i=Math.hypot(e.vx,e.vz),a=Y.releaseLatitude,o=Math.sqrt(1-a*a),s=e.vx/i*o,c=a,l=e.vz/i*o;We(t,et);let u=Y.radius*Ge(s,c,l,et);Ke(s,c,l,et,tt),tt.set(tt.x/r.sx,tt.y/r.sy,tt.z/r.sz).normalize();let d=e.radius+Y.releaseMargin;return n.birthTime=t,n.x=s*u*r.sx+tt.x*d,n.y=r.y+c*u*r.sy+tt.y*d,n.z=l*u*r.sz+tt.z*d,n.vx=e.vx,n.vz=e.vz,n.vy=e.vy+Y.floatAmplitude*qe*Math.cos(t*qe),Qe(n,e.radius)}function rt(e,t,n){return n.set(e.x+e.vx*t,e.y+e.vy*t-.5*W.drops.gravity*t*t,e.z+e.vz*t)}function it(e){let t=e.geometry.getAttribute(`position`),n=e.geometry.getAttribute(`orbDirection`),r=e.geometry.getAttribute(`orbLayer`),i=K.fountain,a=i.baseHeight+i.pedestalFootHeight+i.pedestalHeight+i.pedestalCapHeight,{primary:o,secondary:s,stemFade:c}=Be,{yRatio:l}=Y.shape,u=new D(...o.direction),d=new D(...s.direction);return Ve.beads.map(f=>{let p=new D(...f.direction),m=new D,h=0,g=-1/0;for(let e=0;e<t.count;e++){if(r.getX(e)!==0)continue;let t=m.fromBufferAttribute(n,e).dot(p);t>g&&(g=t,h=e)}m.fromBufferAttribute(n,h);let _=new D().fromBufferAttribute(t,h),v=new D(m.x,m.y*l,m.z),y=new D(m.x,m.y/l,m.z).normalize(),b=new D(y.x,0,y.z).normalize(),x=m.dot(u),S=m.dot(d),C=P.smoothstep(m.y,...c),w=new D;function T(t,n,r){let i=o.amplitude*Math.cos(x+Ue(t,o.period))+s.amplitude*Math.sin(S+Ue(t,s.period));return r.copy(_).addScaledVector(v,i*C).add(e.position).addScaledVector(y,f.radius*n)}function E(e,t){T(e,1,w);let n=Ze(w.y-a-f.radius,f.vy),r=i.pedestalCapSize/2+f.radius+Ve.clearance,o=Math.min((r-Math.sign(b.x)*w.x)/Math.abs(b.x),(r-Math.sign(b.z)*w.z)/Math.abs(b.z)),s=Math.max(f.speed,o/n);return t.birthTime=e,t.x=w.x,t.y=w.y,t.z=w.z,t.vx=b.x*s,t.vy=f.vy,t.vz=b.z*s,Qe(t,f.radius)}return{...f,anchorIndex:h,sampleAttached:T,sampleFlight:E}})}function at(e){let t=xe(`water`);t.name=`courtyard-living-orb`,t.flatShading=!0,t.customProgramCacheKey=()=>`courtyard-living-orb-flow-v2`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r),Object.assign(t.uniforms,{uOrbPhases:{value:e},uOrbBase:{value:new S(Y.colors.base)},uOrbLight:{value:new S(Y.colors.light)},uOrbSide:{value:new S(Y.colors.side)},uOrbShade:{value:new S(Y.colors.shade)},uOrbWhite:{value:new S(Y.colors.white)}});let i=e=>`vec3(${e.map(e=>e.toFixed(6)).join(`, `)})`,a=Y.flow,o=`
      // Rest coordinates interpolate across faces; normalize only per fragment.
      // No atan/UV wrapping, screen coordinates or independently running clock.
      vec3 rest = normalize(vOrbRest);
      vec3 q = vec3(uOrbPhases.x * rest.x - uOrbPhases.y * rest.z, rest.y,
                    uOrbPhases.y * rest.x + uOrbPhases.x * rest.z);
      float bend = dot(q, ${i(a.bend)}) + uOrbPhases.w;
      float mainPhase = dot(q, ${i(a.main)}) + ${a.bendStrength.toFixed(6)} * sin(bend) + uOrbPhases.z;
      float detailPhase = dot(q, ${i(a.detail)}) - uOrbPhases.w;
      float wave = cos(mainPhase);
      // Derivative filtering broadens the crest at the original 384px sampling.
      // Unresolvable secondary ripples fade out instead of flashing single pixels.
      float aa = clamp(fwidth(wave) * .65, .035, .38);
      float flowBand = smoothstep(-.45 - aa, .45 + aa, wave);
      float crest = smoothstep(.76 - aa, .96 + aa, wave);
      float detailVisibility = 1.0 - smoothstep(.55, 1.6, fwidth(detailPhase));
      float detailWave = sin(detailPhase);
      float shortCrest = smoothstep(.72 - aa, .98 + aa, detailWave) * detailVisibility;
      vec3 orbNormal = inverseTransformDirection(normal, viewMatrix);
      float sunFace = .5;
      #if NUM_DIR_LIGHTS > 0
        sunFace = max(dot(normal, directionalLights[0].direction), 0.0);
      #endif
      float volume = smoothstep(-.6, .7, orbNormal.y) * .6 + sunFace * .4;
      vec3 orbColor = mix(uOrbSide, uOrbBase, smoothstep(.08, .92, volume));
      orbColor = mix(orbColor, uOrbLight, flowBand * .46);
      orbColor = mix(orbColor, uOrbSide, (1.0 - flowBand) * .20);
      float edge = pow(1.0 - clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0), 2.6);
      float litCrest = mix(.52, 1.0, sunFace) * mix(.65, 1.0, smoothstep(-.7, .55, orbNormal.y));
      float rim = smoothstep(.35, .85, edge) * smoothstep(-.15, .6, orbNormal.y);
      float movingHighlight = crest * litCrest * .85 + shortCrest * flowBand * .12;
      orbColor = mix(orbColor, uOrbWhite, clamp(movingHighlight + rim * .13, 0.0, .86));
      outgoingLight = mix(uOrbShade, orbColor, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Orb shader extension anchor changed.`);if(!t.vertexShader.includes(`#include <begin_vertex>`))throw Error(`Orb rest-position anchor changed.`);t.vertexShader=t.vertexShader.replace(`#include <common>`,`#include <common>
attribute vec3 orbRest; varying vec3 vOrbRest;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vOrbRest = orbRest;`),t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      varying vec3 vOrbRest;
      uniform vec4 uOrbPhases;
      uniform vec3 uOrbBase; uniform vec3 uOrbLight; uniform vec3 uOrbSide; uniform vec3 uOrbShade; uniform vec3 uOrbWhite;
    
void main() {`).replace(s,o)},t}var ot=600,st=Math.round(ot*.18),ct=2.6001,lt=Math.PI*(3-Math.sqrt(5)),ut=Y.radius-.013,dt=1.3,ft=[.034,.049],pt={body:`#7DB2CD`,shade:`#659CBE`,light:`#CEE4EE`};function mt(n){let r=n!==`particles`,i=n===`particle-flow`||n===`particle-drops`,a=new Float32Array(2124),s=new Float32Array(2124),c=new Float32Array(708),u=new Float32Array(708);function d(e,t,n){for(let r=0;r<t;r++){let i=e+r,o=i*3,l=2*(r+.5)/t-1,d=r*lt+(n?.7:0),f=Math.sqrt(1-l*l),p=f*Math.cos(d),m=f*Math.sin(d),h=n?.202*Math.cbrt((.27+r*.754877666)%1):ut+.0028*Math.sin(r*2.17);a[o]=p*h,a[o+1]=l*h*Y.shape.yRatio,a[o+2]=m*h,s[o]=p,s[o+1]=l,s[o+2]=m,c[i]=Number(n),u[i]=(ft[0]+(ft[1]-ft[0])*((.31+r*.618033989)%1))*(n?.86:1)}}d(0,ot,!1),d(ot,st,!0);let f=new j;f.setAttribute(`position`,new e(a,3)),f.setAttribute(`orbDirection`,new e(s,3)),f.setAttribute(`orbLayer`,new e(c,1)),f.setAttribute(`orbDiameter`,new e(u,1)),f.computeBoundingBox(),f.computeBoundingSphere();let{primary:p,secondary:m,stemFade:h,interiorFollow:g}=Be,_=Ye(ct).y,v=_+f.boundingBox.min.y,y=r?p.amplitude+m.amplitude:0;f.boundingSphere.radius+=ft[1]/2+y,f.boundingBox.expandByScalar(y);let x=r?new l:void 0,C;if(i){let e=new D(...J.axis).normalize(),t=new D(...J.front).projectOnPlane(e).normalize(),n=new D().crossVectors(e,t);C=new o().set(t.x,t.y,t.z,n.x,n.y,n.z,e.x,e.y,e.z)}let w=new I({name:`courtyard-particle-orb`,transparent:!0,depthTest:!0,depthWrite:!1,toneMapped:!1,defines:{...r&&{ORB_WAVE:1},...i&&{ORB_FLOW:1}},uniforms:{uSampleHeight:{value:1},uMinimumPointSize:{value:dt},uSunDirection:{value:new D(...B.sun.position).normalize()},uBody:{value:new S(pt.body)},uShade:{value:new S(pt.shade)},uLight:{value:new S(pt.light)},...x&&{uWavePhase:{value:x},uPrimaryWave:{value:new t(...p.direction,p.amplitude)},uSecondaryWave:{value:new t(...m.direction,m.amplitude)},uStemFade:{value:new l(...h)},uInteriorFollow:{value:g},uOrbYRatio:{value:Y.shape.yRatio}},...C&&{uFlowBasis:{value:C},uFlowOffset:{value:J.offset},uFlowFrontPhase:{value:Ue(J.frontTime,p.period)},uFlowCrestWidth:{value:new l(...J.crestWidth)},uFlowBackWeight:{value:J.backWeight},uFlowLight:{value:new S(J.colors.crest)},uFlowShade:{value:new S(J.colors.shade)}}},vertexShader:`
      attribute vec3 orbDirection;
      attribute float orbLayer;
      attribute float orbDiameter;
      uniform float uSampleHeight;
      uniform float uMinimumPointSize;
      uniform vec3 uSunDirection;
      uniform vec3 uBody;
      uniform vec3 uShade;
      uniform vec3 uLight;
      varying vec3 vColor;
      varying float vOpacity;

      #ifdef ORB_WAVE
        uniform vec2 uWavePhase;
        uniform vec4 uPrimaryWave;
        uniform vec4 uSecondaryWave;
        uniform vec2 uStemFade;
        uniform float uInteriorFollow;
        uniform float uOrbYRatio;

        vec3 displaceOrbPoint(vec3 rest, vec3 direction, float layer) {
          float primary = uPrimaryWave.w * cos(dot(direction, uPrimaryWave.xyz) + uWavePhase.x);
          float secondary = uSecondaryWave.w * sin(dot(direction, uSecondaryWave.xyz) + uWavePhase.y);
          // Keep the lower cap attached to the pedestal's water column.
          float weight = smoothstep(uStemFade.x, uStemFade.y, direction.y) * mix(1.0, uInteriorFollow, layer);
          vec3 ellipticalDirection = direction * vec3(1.0, uOrbYRatio, 1.0);
          return rest + ellipticalDirection * ((primary + secondary) * weight);
        }
      #endif

      #ifdef ORB_FLOW
        uniform mat3 uFlowBasis;
        uniform float uFlowOffset;
        uniform float uFlowFrontPhase;
        uniform vec2 uFlowCrestWidth;
        uniform float uFlowBackWeight;
        uniform vec3 uFlowLight;
        uniform vec3 uFlowShade;

        vec3 colorOrbFlow(vec3 water, vec3 direction, float facing, float lift, float layer) {
          vec3 orbit = uFlowBasis * direction;
          vec2 around = orbit.xy * inversesqrt(max(dot(orbit.xy, orbit.xy), 0.000001));
          float across = orbit.z - uFlowOffset;
          // The highlight slows through the front arc, then continues around the back.
          float phase = uWavePhase.x - uFlowFrontPhase;
          float travel = phase - .26 * sin(phase) + .24 * (1.0 - cos(phase));
          vec2 heading = vec2(cos(travel - .04), sin(travel - .04));
          float lengthMask = smoothstep(.63, .928, dot(around, heading));
          float taper = mix(.64, 1.0, lengthMask);
          float crest = 1.0 - smoothstep(uFlowCrestWidth.x * taper, uFlowCrestWidth.y * taper, abs(across));
          float trough = 1.0 - smoothstep(.024, .104, abs(across - .172));
          float visibility = mix(uFlowBackWeight, 1.0, smoothstep(-.29, .66, facing));
          float surface = mix(1.0, .14, layer);
          float strength = lengthMask * visibility * surface;
          float liftLight = mix(.58, 1.0, smoothstep(-.028, .030, lift));
          return mix(mix(water, uFlowShade, .36 * strength * trough),
                     uFlowLight, .97 * strength * crest * liftLight);
        }
      #endif

      void main() {
        vec3 direction = normalize(mat3(modelMatrix) * orbDirection);
        vec3 viewDirection = normalize(normalMatrix * orbDirection);
        float facing = viewDirection.z;
        float front = smoothstep(-.52, .76, facing);
        float sun = max(dot(direction, uSunDirection), 0.0);
        float rim = pow(1.0 - abs(facing), 2.0);
        vec3 blue = mix(uShade, uBody, .18 + .64 * front + .16 * sun);
        vec3 viewLight = mat3(viewMatrix) * uSunDirection;
        vec3 halfDirection = normalize(viewLight + vec3(0.0, 0.0, 1.0));
        float directGleam = smoothstep(.86, .992, dot(viewDirection, halfDirection));
        float rimGleam = rim * pow(sun, 3.0);
        float gleam = min(.94 * directGleam + .28 * rimGleam, 1.0);
        #ifdef ORB_FLOW
          gleam *= .62;
        #endif
        vColor = mix(blue, uLight, gleam * mix(1.0, .35, orbLayer));
        vOpacity = (.33 + .49 * front + .09 * rim) * mix(1.0, .42, orbLayer);
        vec3 localPosition = position;
        #ifdef ORB_WAVE
          localPosition = displaceOrbPoint(position, orbDirection, orbLayer);
        #endif
        #ifdef ORB_FLOW
          float lift = dot(localPosition - position, orbDirection);
          vColor = colorOrbFlow(vColor, orbDirection, facing, lift, orbLayer);
        #endif
        gl_Position = projectionMatrix * modelViewMatrix * vec4(localPosition, 1.0);
        gl_PointSize = max(uMinimumPointSize, .5 * abs(projectionMatrix[1][1]) * uSampleHeight * orbDiameter);
      }
    `,fragmentShader:`
      varying vec3 vColor;
      varying float vOpacity;
      void main() {
        float distanceToCenter = length(2.0 * gl_PointCoord - 1.0);
        float coverage = 1.0 - smoothstep(.60, 1.0, distanceToCenter);
        if (coverage < .015) discard;
        gl_FragColor = vec4(vColor, vOpacity * coverage);
        #include <colorspace_fragment>
      }
    `}),T=new b(f,w);return T.name=`fountain-water-crown`,T.position.y=_,T.onBeforeRender=e=>{w.uniforms.uSampleHeight.value=e.getRenderTarget()?.height??e.domElement.height},{object:T,metadata:{radius:Y.radius,centerY:_,amplitude:0,period:0,referenceTime:ct,shellCount:ot,interiorCount:st,vertices:708,triangles:0,shellRadius:ut,minimumPointSize:dt,diameter:ft,colors:pt,addedTextures:0,addedPasses:0,...r&&{wave:Be,maximumDisplacement:y},...i&&{surfaceFlow:J}},update(e){return x?.set(Ue(e,p.period),Ue(e,m.period)),v},dispose(){f.dispose(),w.dispose()}}}function ht(){let e=new t,n=Je(),r=at(e),i=new k(1,...Y.sphereSegments),a=i.getAttribute(`position`);a.setUsage(d);let o=new Float32Array(a.array);i.setAttribute(`orbRest`,new g(o,3)),i.boundingSphere=new N(new D,Y.shape.envelope),i.boundingBox=new F(new D().setScalar(-Y.shape.envelope),new D().setScalar(Y.shape.envelope));let s=new f(i,r);return s.name=`fountain-water-crown`,s.receiveShadow=!0,s.scale.setScalar(Y.radius),{object:s,phases:e,pose:n,metadata:{radius:Y.radius,centerY:Y.centerY,amplitude:Y.floatAmplitude,period:Y.floatPeriod,envelope:Y.shape.envelope,replacedGeometries:2,addedGeometries:0,addedTextures:0,addedPasses:0,flow:`curved-rest-sphere-v2`,vertices:a.count,triangles:i.index.count/3,restAttributeBytes:o.byteLength},update(t){Ye(t,n),We(t,e);let r=1/0;for(let t=0;t<a.count;t++){let i=t*3,s=o[i],c=o[i+1],l=o[i+2],u=Ge(s,c,l,e),d=c*u*n.sy;a.setXYZ(t,s*u*n.sx,d,l*u*n.sz),r=Math.min(r,d)}return a.needsUpdate=!0,s.position.y=n.y,n.y+r*Y.radius},dispose(){i.dispose(),r.dispose()}}}function gt(e,t,n=`lively`){let i=new r;i.name=`fountain-effects`,i.userData.orbStyle=n;let a=K.fountain;i.position.set(...a.position),i.rotation.y=a.rotationY;let o=n===`lively`?void 0:mt(n),s=o??ht(),c=n===`particle-drops`&&o?it(o.object):void 0,l=c?Be.primary.period:W.drops.period,u=Ae(e,`jet`),m=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,g=new h(Y.stemRadius,Y.stemRadius,1,8),v=new _(1,+!!c),y=new f(g,u);y.name=`fountain-water-column`,y.receiveShadow=!0;let b=new R(v,u,t.length);b.name=`fountain-water-drops`,b.receiveShadow=!0,b.instanceMatrix.setUsage(d),b.boundingBox=new F(new D(-1.75,.3,-1.75),new D(1.75,1.9,1.75)),b.boundingSphere=b.boundingBox.getBoundingSphere(new N),i.add(y,s.object,b),i.visible=W.enabled;let x=new D,S=new D,w=new C,T=new p,E=new p,O=(c??t).map((e,t)=>({drop:e,index:t,current:Xe(),previous:Xe()})),k=O.map(e=>({record:e,age:0,flight:e.current}));i.userData.flights=O,i.userData.impactEvents=k,`pose`in s&&(i.userData.orbPose=s.pose,i.userData.orbPhases=s.phases),i.userData.orbMetadata={...s.metadata,dropCapacity:t.length,rippleCapacity:e.impacts.value.length,...c&&{releasePeriod:l,beads:c.map(({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i})=>({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i}))}};let A,j=!1;function M(n){if(j||n===A)return;A=n,e.time.value=n;let r=s.update(n),o=r+Y.stemOverlap;y.position.y=(m+o)/2,y.scale.y=o-m;let c=0;for(let e of O){let{drop:t,current:r,previous:i}=e,o=`sampleAttached`in t?t:void 0,s=o?.formationTime??0,u=t.phase+Math.floor((n-t.phase+s)/l)*l;u!==r.birthTime&&(`sampleFlight`in t?(t.sampleFlight(u,r),t.sampleFlight(u-l,i)):(nt(t,u,r),nt(t,u-l,i)));let d=n-u,f=t.radius;if(o&&d<0){let e=P.smoothstep(d,-s,0);o.sampleAttached(n,e,x),f*=e}else{if(!o&&d>=r.duration)continue;if(rt(r,d,x),o){if(x.y+f<=a.waterHeight)continue}else f*=Math.min(1,d/.07,(r.duration-d)/.055)}f<5e-4||(S.setScalar(f),T.compose(x,w,S),b.setMatrixAt(c++,T))}b.count=c;for(let e=c;e<t.length;e++)b.setMatrixAt(e,E);b.instanceMatrix.needsUpdate=!0;for(let e of k){let t=e.record;e.flight=n>=t.current.birthTime+t.current.duration?t.current:t.previous,e.age=n-(e.flight.birthTime+e.flight.duration)}k.sort((e,t)=>e.age-t.age||e.record.index-t.record.index);let u=0;for(let t=0;t<e.impacts.value.length;t++){let n=k[t];n&&n.age>=0&&n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.flight.impactX,n.flight.impactZ,n.age,n.record.drop.strength),u++):e.impacts.value[t].set(0,0,0,0)}i.userData.time=n,i.userData.activeDrops=c,i.userData.activeRipples=u,i.userData.orbBottom=r,i.userData.stemTop=o}return M(W.initialTime),{root:i,update:M,dispose(){j||(j=!0,b.dispose(),g.dispose(),s.dispose(),v.dispose(),u.dispose(),i.removeFromParent(),i.clear())}}}function _t(){let e=W.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=W.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=W.jet.emitterHeight-K.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function vt(e,t,n){return n.set(e.vx*t,W.jet.emitterHeight+e.vy*t-.5*W.drops.gravity*t*t,e.vz*t)}function yt(e,t=`legacy`){if(t!==`legacy`)try{return gt(e,_t(),t)}catch(e){console.warn(`Orb detail unavailable; original water effects retained.`,e)}let n=new r;n.name=`fountain-effects`;let i=K.fountain;n.position.set(...i.position),n.rotation.y=i.rotationY;let a=_t();n.userData.dropParameters=a;let o=Ae(e,`jet`),s=i.baseHeight+i.pedestalFootHeight+i.pedestalHeight+i.pedestalCapHeight,c=W.jet.emitterHeight-s,l=new h(W.jet.stemRadius,W.jet.stemRadius,c,8),u=new k(1,8,5),d=new _(1,0),m=new f(l,o);m.name=`fountain-water-column`,m.position.y=s+c/2,m.receiveShadow=!0;let g=new f(u,o);g.name=`fountain-water-crown`,g.position.y=W.jet.emitterHeight,g.receiveShadow=!0;let v=new R(d,o,a.length);v.name=`fountain-water-drops`,v.receiveShadow=!0,v.boundingBox=new F(new D(-1.4,.3,-1.4),new D(1.4,1.45,1.4)),v.boundingSphere=v.boundingBox.getBoundingSphere(new N),n.add(m,g,v),n.visible=W.enabled;let y=new D,b=new D,x=new p,S=new C,w=new p,T=a.map(e=>({drop:e,age:0})),E=(e,t)=>e.age-t.age,O=(e,t)=>(e%t+t)%t;function A(t){e.time.value=t;let r=0;for(let e of a){let n=O(t-e.phase,W.drops.period);if(n>=e.impactTime)continue;vt(e,n,y);let i=Math.min(1,n/.07),a=Math.min(1,(e.impactTime-n)/.055),o=e.radius*Math.min(i,a);o<5e-4||(b.setScalar(o),x.compose(y,S,b),v.setMatrixAt(r++,x))}v.count=r;for(let e=r;e<a.length;e++)v.setMatrixAt(e,w);v.instanceMatrix.needsUpdate=!0;for(let e of T)e.age=O(t-e.drop.phase-e.drop.impactTime,W.drops.period);T.sort(E);let i=0;for(let t=0;t<e.impacts.value.length;t++){let n=T[t];n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),i++):e.impacts.value[t].set(0,0,0,0)}let o=W.jet.pulse,s=W.jet.radius;g.scale.set(s*(1+o*Math.sin(t*2.1)),s*.9*(1+o*Math.sin(t*2.8)),s*(1+o*Math.cos(t*2.1))),m.scale.set(1+o*Math.sin(t*2.1),1,1+o*Math.sin(t*2.1)),n.userData.time=t,n.userData.activeDrops=r,n.userData.activeRipples=i}A(W.initialTime);let j=!1;return{root:n,update:A,dispose(){j||(j=!0,v.dispose(),l.dispose(),u.dispose(),d.dispose(),o.dispose(),n.removeFromParent(),n.clear())}}}function bt(){let t=U.petals,n=U.seed+1;function r(){n+=1831565813;let e=Math.imul(n^n>>>15,1|n);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let i=Array.from({length:t.capacity},(e,n)=>{let i=0,a=0,o=!1;for(let e=0;e<1e3;e++){let e=H.flowers.clusters[Math.floor(r()*H.flowers.clusters.length)],n=r()*Math.PI*2,s=r()*e.radius;if(i=e.center[0]+Math.cos(n)*s,a=e.center[1]+Math.sin(n)*s,Re(i,a,t.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:i,z:a,phase:n*t.period/t.capacity,rotation:r()*Math.PI*2,size:.055+r()*.02}}),a=new j;a.setAttribute(`position`,new e([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),a.computeVertexNormals();let o=new m({color:z.flowerLight,side:2,toneMapped:!1});o.name=`courtyard-floating-petal`;let s=new R(a,o,t.capacity);s.name=`courtyard-floating-petals`,s.castShadow=!1;let c=new F;for(let e of i)c.expandByPoint(new D(e.x-t.drift,t.minHeight,e.z-t.drift)),c.expandByPoint(new D(e.x+t.drift,t.maxHeight,e.z+t.drift));c.expandByScalar(.05),s.boundingBox=c,s.boundingSphere=c.getBoundingSphere(new N),s.userData.parameters=i;let l=new p,u=new D,d=new D,f=new C,h=new p,g=new D(.25,1,.15).normalize(),_=!1;return{mesh:s,update(e){let n=0;for(let r of i){let i=((e-r.phase)%t.period+t.period)%t.period;if(i>=t.lifetime)continue;let a=i/t.lifetime,o=Math.min(1,i/.6,(t.lifetime-i)/.7);u.set(r.x+Math.sin(i*.6+r.rotation)*t.drift,t.maxHeight+(t.minHeight-t.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*t.drift),f.setFromAxisAngle(g,r.rotation+i*.25),d.setScalar(r.size*o),l.compose(u,f,d),s.setMatrixAt(n++,l)}s.count=n;for(let e=n;e<t.capacity;e++)s.setMatrixAt(e,h);s.instanceMatrix.needsUpdate=!0},dispose(){_||(_=!0,s.dispose(),a.dispose(),o.dispose(),s.removeFromParent())}}}var Z={flowSpeed:.035,waveSpeed:.36,waveStrength:.15,rippleStrength:.42,foamWidth:[.015,.04],colors:{shallow:`#B4DAD9`,base:`#BED4DF`,middle:`#95BECF`,deep:`#245B80`,shade:`#7FA3BF`,white:`#F2FAFC`,stoneTop:`#F0E5C1`,stoneSide:`#C7CCB6`,stoneShade:`#7095A1`,wetStone:`#557D81`,weathering:`#A3B592`}};function xt(){let e=Oe({top:Z.colors.stoneTop,side:Z.colors.stoneSide,shade:Z.colors.stoneShade});e.name=`courtyard-pool-stone`,e.customProgramCacheKey=()=>`courtyard-pool-stone-v1`;let n=e.onBeforeCompile.bind(e);return e.onBeforeCompile=(e,r)=>{n(e,r);let i=K.fountain;Object.assign(e.uniforms,{uPoolStoneOrigin:{value:new t(i.position[0],i.position[2],Math.cos(i.rotationY),Math.sin(i.rotationY))},uPoolStoneLevels:{value:new t(i.position[1],i.waterHeight,i.baseHeight,i.innerRadius)},uPoolStoneWet:{value:new S(Z.colors.wetStone)},uPoolStoneOld:{value:new S(Z.colors.weathering)}});let a=`outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;`;if(!e.fragmentShader.includes(a))throw Error(`Pool stone extension anchor changed.`);e.fragmentShader=e.fragmentShader.replace(`void main() {`,`
      uniform vec4 uPoolStoneOrigin; uniform vec4 uPoolStoneLevels;
      uniform vec3 uPoolStoneWet; uniform vec3 uPoolStoneOld;
    
void main() {`).replace(a,`${a}\n
      vec2 poolDelta = vArtWorldPosition.xz - uPoolStoneOrigin.xy;
      vec2 poolP = vec2(uPoolStoneOrigin.z * poolDelta.x - uPoolStoneOrigin.w * poolDelta.y,
                       uPoolStoneOrigin.w * poolDelta.x + uPoolStoneOrigin.z * poolDelta.y);
      vec2 poolN = vec2(uPoolStoneOrigin.z * worldNormal.x - uPoolStoneOrigin.w * worldNormal.z,
                       uPoolStoneOrigin.w * worldNormal.x + uPoolStoneOrigin.z * worldNormal.z);
      float poolY = vArtWorldPosition.y - uPoolStoneLevels.x;
      float side = 1.0 - smoothstep(.35, .85, worldNormal.y);
      float innerFace = 1.0 - smoothstep(-.08, .05, dot(poolN, poolP));
      float pedestal = 1.0 - smoothstep(.44, .58, max(abs(poolP.x), abs(poolP.y)));
      float wetNoise = artNoise(poolP * 13.0 + vec2(5.4, 8.1));
      float wetLine = 1.0 - smoothstep(uPoolStoneLevels.y + .018, uPoolStoneLevels.y + .065 + wetNoise * .025, poolY);
      float wet = wetLine * side * max(innerFace, pedestal);
      outgoingLight = mix(outgoingLight, mix(outgoingLight * .73, uPoolStoneWet, .22), wet * .72);
      float contact = (1.0 - smoothstep(.02, .075, poolY)) * side;
      outgoingLight = mix(outgoingLight, uPoolStoneWet * .78, contact * .30);
      float capStep = (1.0 - smoothstep(.004, .018, abs(poolY - .44))) * side;
      outgoingLight *= 1.0 - capStep * .10;
      float chips = max(1.0 - smoothstep(.08, .28, length(poolP - vec2(.935, -2.259))),
                        1.0 - smoothstep(.08, .28, length(poolP + vec2(.935, -2.259))));
      float weather = chips * smoothstep(.48, .72, wetNoise) * smoothstep(.48, .56, poolY);
      outgoingLight = mix(outgoingLight, uPoolStoneOld, weather * .35);
    `)},e}function St(e){let n=xe(`water`);n.name=`courtyard-water-refined-surface`,n.userData.waterKind=`refined-surface`,n.customProgramCacheKey=()=>`courtyard-water-refined-surface-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=K.fountain;Object.assign(n.uniforms,{uPoolTime:e.time,uPoolImpacts:e.impacts,uPoolOrigin:{value:new t(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uPoolMotion:{value:new t(Z.flowSpeed,Z.waveSpeed,Z.waveStrength,Z.rippleStrength)},uPoolBoundary:{value:new t(a.innerRadius*Math.cos(Math.PI/8),...Z.foamWidth,W.ripples.lifetime)},uPoolShallow:{value:new S(Z.colors.shallow)},uPoolBase:{value:new S(Z.colors.base)},uPoolMiddle:{value:new S(Z.colors.middle)},uPoolDeep:{value:new S(Z.colors.deep)},uPoolShade:{value:new S(Z.colors.shade)},uPoolWhite:{value:new S(Z.colors.white)}});let o=`
      uniform float uPoolTime;
      uniform vec4 uPoolImpacts[${W.ripples.capacity}];
      uniform vec4 uPoolOrigin; uniform vec4 uPoolMotion; uniform vec4 uPoolBoundary;
      uniform vec3 uPoolShallow; uniform vec3 uPoolBase; uniform vec3 uPoolMiddle;
      uniform vec3 uPoolDeep; uniform vec3 uPoolShade; uniform vec3 uPoolWhite;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uPoolOrigin.xy;
      vec2 p = vec2(uPoolOrigin.z * delta.x - uPoolOrigin.w * delta.y,
                    uPoolOrigin.w * delta.x + uPoolOrigin.z * delta.y);
      float t = uPoolTime;
      vec2 drift = vec2(t, -t * .25) * uPoolMotion.x;
      float broad = artNoise(p * vec2(2.2, 1.6) + drift * .5 + vec2(3.7, 6.1));
      float grain = artNoise(p * 18.0 + drift);
      vec2 q = p + vec2((broad - .5) * .20, (artNoise(p * 2.8 + vec2(8.4, 1.7) - drift) - .5) * .18) + drift * .65;
      vec2 leftShape = mat2(.96, -.28, .28, .96) * (q - vec2(-1.3, -.25));
      float leftReflection = length(leftShape / vec2(.36, 1.62));
      vec2 farShape = q - vec2(.30, -1.68);
      farShape.y += sin(farShape.x * 2.0) * .10;
      float farReflection = length(farShape / vec2(1.42, .31));
      vec2 nearShape = mat2(.91, .41, -.41, .91) * (q - vec2(1.12, .95));
      float nearReflection = length(nearShape / vec2(.24, .64));
      float silhouette = min(min(leftReflection, farReflection), nearReflection);
      silhouette += (broad - .5) * .70 + (grain - .5) * .12;
      float aa = clamp(max(fwidth(p.x), fwidth(p.y)), .003, .12);
      float detail = 1.0 - smoothstep(.035, .095, aa);
      float reflection = 1.0 - smoothstep(.93 - aa, 1.04 + aa, silhouette);
      float centerDistance = length(p);
      reflection *= smoothstep(.55, .85, centerDistance);

      float shoreDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + .5) * PI / 4.0;
        shoreDistance = min(shoreDistance, uPoolBoundary.x - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float shelf = smoothstep(.025, .18, shoreDistance);
      float depth = smoothstep(.28, 1.25, shoreDistance) * .26;
      vec3 clearWater = mix(uPoolShallow, uPoolBase, shelf);
      clearWater = mix(clearWater, uPoolMiddle, depth);
      vec3 litWater = mix(clearWater, uPoolDeep, reflection * .96);

      float wave = smoothstep(.955, .995, sin(centerDistance * 12.0 - t * uPoolMotion.y * 12.0 + broad));
      wave *= smoothstep(.65, .9, centerDistance) * (1.0 - smoothstep(1.5, 1.95, centerDistance));
      wave *= smoothstep(.52, .76, artNoise(p * 7.5 + drift)) * uPoolMotion.z;
      float glint = smoothstep(.78, .94, artNoise(p * 7.0 - drift))
        * smoothstep(.90, .99, sin(p.x * 11.0 + p.y * 6.0 - t * .72 + broad * 3.0)) * .64;
      float foam = (1.0 - smoothstep(uPoolBoundary.y, uPoolBoundary.z + aa * .35, shoreDistance))
        * smoothstep(.71, .88, artNoise(p * 12.0 + drift)) * .48;
      float impacts = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 event = uPoolImpacts[i];
        float radius = .025 + event.z * ${W.ripples.speed.toFixed(2)};
        float distanceToRing = abs(length(p - event.xy) - radius);
        float ring = 1.0 - smoothstep(.008, .018 + aa * .3, distanceToRing);
        float ageFade = pow(clamp(1.0 - event.z / uPoolBoundary.w, 0.0, 1.0), 2.0);
        float broken = smoothstep(.22, .47, artNoise(p * 9.0 + vec2(float(i) * 3.1, 5.0)));
        impacts = max(impacts, ring * ageFade * event.w * broken * uPoolMotion.w);
      }
      float white = max(max(wave, glint) * mix(.25, 1.0, detail), max(foam, impacts));
      litWater = mix(litWater, uPoolWhite, white);
      vec3 shadedWater = mix(uPoolShade, uPoolDeep * .84, reflection * .78);
      shadedWater = mix(shadedWater, uPoolWhite, white * .13);
      outgoingLight = mix(shadedWater, litWater, getShadowMask());
    `,c=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(c))throw Error(`Pool surface extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(c,s)},n}function Ct(e,t){let n=e.getObjectByName(`fountain`),r=n?.getObjectByName(`fountain-water`),i=[];if(n?.traverse(e=>{e instanceof f&&/^fountain-(base|rim-wall|coping-\d|pedestal(-foot|-cap)?)$/.test(e.name)&&i.push(e)}),!(r instanceof f)||i.length!==13)throw Error(`Pool finish requires the complete original fountain.`);let a=St(t),o=xt(),s=new Map;for(let e of[...i,r])s.set(e,e.material),e.material=e===r?a:o;let c=!1;return{metadata:{bindings:[...s.keys()].map(e=>({object:e.name,material:e.material.name})),newGeometries:0,newTextures:0,extraPasses:0},dispose(){if(!c){c=!0;for(let[e,t]of s)e.material=t;s.clear(),a.dispose(),o.dispose()}}}}var Q={period:32,speed:.22,softness:[.46,1.3],unionSoftness:.24,patches:[{along:-3,across:-1.4,radius:[4.6,3.3],density:1},{along:12,across:4.6,radius:[5.6,3.7],density:.88}],response:{ground:.18,stone:.14,foliage:.13,flower:.1,water:.075,orb:.05,jet:.045}},wt=B.sun.position,Tt=[wt[0]/wt[1],wt[2]/wt[1]],Et=_e,Dt=Q.period/Q.speed;function Ot(e){return(e*Q.speed%Q.period+Q.period)%Q.period}function kt(e,t){let n=t,r={enabled:e,active:{value:+!!e},drift:{value:Ot(t)},failures:[],update(t){e&&t!==n&&(n=t,r.drift.value=Ot(t))},snapshot(){return{enabled:e,active:r.active.value,time:n,drift:r.drift.value,repeatSeconds:Dt,failures:[...r.failures]}}};return r}var $=e=>e.toFixed(10),At=e=>`vec2(${e.map($).join(`,`)})`,jt=`
  uniform float uCloudDrift;
  uniform float uCloudActive;
  float cloudSoftMin(float a, float b) {
    float h = max(${$(Q.unionSoftness)} - abs(a - b), 0.0) / ${$(Q.unionSoftness)};
    return min(a, b) - h * h * ${$(Q.unionSoftness*.25)};
  }
  float cloudPatch(vec2 point, vec2 center, vec2 radius) {
    vec2 q = point - center;
    q.x -= ${$(Q.period)} * floor(q.x / ${$(Q.period)} + .5);
    q /= radius;
    // Evaluate derivatives before the coherent empty-space branch. The cloud
    // is already fully clear outside these bounds, including the wrap seam.
    float aa = min(max(fwidth(q.x), fwidth(q.y)) * .75, .10);
    if (abs(q.x) > 1.8 || abs(q.y) > 1.6) return 0.0;
    vec2 b = (q - vec2(.48, -.16)) * vec2(1.3, 1.18);
    vec2 c = (q + vec2(.44, -.22)) * vec2(1.15, 1.38);
    float d = cloudSoftMin(cloudSoftMin(dot(q, q), dot(b, b)), dot(c, c));
    return 1.0 - smoothstep(${$(Q.softness[0])} - aa, ${$(Q.softness[1])} + aa, d);
  }
  float cloudCoverage(vec3 world) {
    vec2 projected = world.xz - world.y * ${At(Tt)};
    const vec2 direction = ${At(Et)};
    vec2 point = vec2(dot(projected, direction) - uCloudDrift,
                      dot(projected, vec2(-direction.y, direction.x)));
    ${Q.patches.map((e,t)=>`float c${t} = cloudPatch(point, ${At([e.along,e.across])}, ${At(e.radius)}) * ${$(e.density)};`).join(`
`)}
    return 1.0 - (1.0 - c0) * (1.0 - c1);
  }
`;function Mt(e,t,n,r){let i=`#include <opaque_fragment>`;if(!e.fragmentShader.includes(i)||!e.fragmentShader.includes(`void main() {`)||!e.vertexShader.includes(`vArtWorldPosition`))throw Error(`Cloud receiver shader anchor unavailable`);let a=t===`ground`?`mix(.08, 1.0, 1.0 - occlusion)`:t===`foliage`?`mix(.10, 1.0, 1.0 - plantOcclusion)`:t===`flower`?`mix(.10, 1.0, 1.0 - flowerOcclusion)`:`mix(.12, 1.0, cloudSceneShadow) * mix(.10, 1.0, smoothstep(.015, .32, cloudLuminance))`,o=t===`water`?` * mix(1.0, .30, smoothstep(.50, .90, cloudLuminance))`:``,s=`
    // CLOUD_SHADOW_FINISH: shared world field after the original material finish.
    float cloudLuminance = dot(outgoingLight, vec3(.2126, .7152, .0722));
    float cloudMask = cloudCoverage(vArtWorldPosition);
    float cloudAmount = cloudMask * ${$(n)} * (${a})${o} * uCloudActive;
    outgoingLight *= vec3(1.0) - cloudAmount * vec3(1.0, .96, .85);
    ${i}
  `,c=e.fragmentShader.replaceAll(`getShadowMask()`,`cloudSceneShadow`).replace(`void main() {`,`void main() {
float cloudSceneShadow = getShadowMask();`).replace(`#include <common>`,`#include <common>\n${jt}`).replace(i,s);e.uniforms.uCloudDrift=r.drift,e.uniforms.uCloudActive=r.active,e.fragmentShader=c}function Nt(e){let t=new Map,n=!1;return{bind(r){!n&&e.enabled&&r.traverse(n=>{if(n instanceof f)for(let r of Array.isArray(n.material)?n.material:[n.material]){let n=r.userData.artSurface;if(!n||!(n in Q.response)||t.has(r))continue;let i=r.name===`courtyard-living-orb`?Q.response.orb:r.userData.waterKind===`jet`?Q.response.jet:Q.response[n],a=r.onBeforeCompile,o=r.customProgramCacheKey;t.set(r,{compile:a,key:o,data:r.userData.cloudShadow}),r.customProgramCacheKey=()=>`${o.call(r)}-cloud-shadow-v2-${i}`,r.onBeforeCompile=(t,o)=>{if(a.call(r,t,o),e.active.value)try{Mt(t,n,i,e)}catch(t){e.active.value=0,e.failures.push(`${r.name}: ${String(t)}`),console.warn(`Cloud shade unavailable; original surface lighting retained.`,t)}},r.userData.cloudShadow={surface:n,strength:i}}})},get metadata(){return{...e.snapshot(),materials:[...t.keys()].map(e=>({name:e.name,...e.userData.cloudShadow})),newGeometries:0,newTextures:0,extraPasses:0,extraDrawCalls:0}},dispose(){if(!n){n=!0;for(let[e,n]of t)e.onBeforeCompile=n.compile,e.customProgramCacheKey=n.key,n.data===void 0?delete e.userData.cloudShadow:e.userData.cloudShadow=n.data;t.clear()}}}}var Pt={routes:[{center:[-.6,1.3],radii:[7.2,5.5],height:4.45,rotation:.05,period:48,phase:.14,direction:1,span:.34,flapCycle:5.2,flapDuration:1.4,flapRate:1.7},{center:[.4,.7],radii:[6.1,6.4],height:5.1,rotation:-.65,period:54,phase:.55,direction:-1,span:.32,flapCycle:5.4,flapDuration:1.6,flapRate:1.9},{center:[-.4,1.1],radii:[7.8,4.9],height:5.75,rotation:.35,period:61,phase:.81,direction:1,span:.33,flapCycle:4.9,flapDuration:1.3,flapRate:1.6}],colors:{warm:`#F3EAC4`,light:`#F8FCED`,cool:`#7095A1`,tip:`#405B55`,beak:`#DCCB9D`},bodyRadius:.69,clearance:.25,desktopMargin:20,mobileMargin:14,fadePixels:26,minimumAlpha:.015},Ft=Math.PI*2,It=(e,t)=>(e%t+t)%t,Lt=e=>{let t=Math.min(1,Math.max(0,e));return t*t*t*(t*(t*6-15)+10)};function Rt(){return{position:new D,tangent:new D,rotation:new C,euler:new n(0,0,0,`YXZ`),leftWing:0,rightWing:0,flap:0,bank:0,speed:0,scale:1,phase:0}}function zt(e,t,n){let r=Pt.routes[t],i=It(e/r.period*r.direction+r.phase,1),a=Ft*i,o=Ft/r.period*r.direction,s=Math.cos(r.rotation),c=Math.sin(r.rotation),l=r.radii[0]*Math.cos(a)+.35*Math.sin(2*a),u=r.radii[1]*Math.sin(a),d=(-r.radii[0]*Math.sin(a)+.7*Math.cos(2*a))*o,f=r.radii[1]*Math.cos(a)*o,p=It(e+t*1.37,r.flapCycle),m=Lt(p/.22)*(1-Lt((p-r.flapDuration+.28)/.28)),h=Ft*r.flapRate*e+t*1.9,g=.08+m*(.54*Math.sin(h)-.04);n.position.set(r.center[0]+s*l-c*u,r.height+.055*Math.sin(2*a)+.016*m*Math.sin(h*2),r.center[1]+c*l+s*u),n.tangent.set(s*d-c*f,.11*o*Math.cos(2*a),c*d+s*f),n.speed=n.tangent.length(),n.tangent.normalize();let _=Math.atan2(n.tangent.x,n.tangent.z),v=-Math.atan2(n.tangent.y,Math.hypot(n.tangent.x,n.tangent.z)),y=-.18*r.direction*(.75+.25*Math.cos(2*a));return n.euler.set(v,_,y,`YXZ`),n.rotation.setFromEuler(n.euler),n.leftWing=g,n.rightWing=-g,n.flap=m,n.bank=y,n.scale=r.span,n.phase=i,n}function Bt(t){let n=[],r=[],i=[],a=0,o=Object.fromEntries(Object.entries(Pt.colors).map(([e,t])=>[e,new S(t)])),s=new D,c=new D,l=new D;function u(e,t,u,d){s.set(t[0]-e[0],t[1]-e[1],t[2]-e[2]),c.set(u[0]-e[0],u[1]-e[1],u[2]-e[2]),l.crossVectors(s,c).normalize();let f=o[d??(l.y>.3?`light`:l.y<-.3?`cool`:`warm`)];for(let o of[e,t,u])n.push(...o),r.push(f.r,f.g,f.b),i.push(a)}function d(e,t,n){let r=e.reduce((e,t)=>e.add(new D(...t)),new D).divideScalar(e.length);for(let[i,a,o]of t){let t=e[i],d=e[a],f=e[o];s.set(d[0]-t[0],d[1]-t[1],d[2]-t[2]),c.set(f[0]-t[0],f[1]-t[1],f[2]-t[2]),l.crossVectors(s,c),l.dot(new D(...t).sub(r))<0?u(t,f,d,n):u(t,d,f,n)}}function f(e,t,n,r=!1){let i=0;for(let t=0;t<e.length;t++){let n=e[t],r=e[(t+1)%e.length];i+=n[0]*r[1]-r[0]*n[1]}i>0&&e.reverse();let a=e.map(([e,r])=>[e,t+n/2,r]),o=e.map(([e,r])=>[e,t-n/2,r]);for(let t=1;t<e.length-1;t++)u(a[0],a[t],a[t+1],r&&t===2?`tip`:`warm`),u(o[0],o[t+1],o[t],`cool`);for(let t=0;t<e.length;t++){let n=(t+1)%e.length;u(a[t],o[t],o[n],`cool`),u(a[t],o[n],a[n],`cool`)}}if((t===`body`||t===`all`)&&(d([[0,.02,.245],[0,.02,-.225],[.085,.02,0],[-.085,.02,0],[0,.105,.005],[0,-.065,-.005]],[[4,0,2],[4,2,1],[4,1,3],[4,3,0],[5,2,0],[5,1,2],[5,3,1],[5,0,3]]),d([[0,.115,.28],[-.055,.025,.2],[.055,.025,.2],[0,.035,.37]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`warm`),d([[0,.04,.345],[-.025,.025,.32],[.025,.025,.32],[0,.025,.415]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`beak`),f([[0,-.17],[.075,-.34],[0,-.305],[-.075,-.34]],.015,.014)),t!==`body`)for(let e of t===`all`?[-1,1]:[t===`left`?-1:1])a=e,f([[0,.1],[e*.22,.035],[e*.425,-.095],[e*.3,-.19],[e*.05,-.08]],.025,.018,!0);let p=new j;return p.name=`courtyard-bird-${t}`,p.setAttribute(`position`,new e(n,3)),p.setAttribute(`color`,new e(r,3)),t===`all`&&p.setAttribute(`birdPart`,new e(i,1)),p.computeVertexNormals(),p.computeBoundingBox(),p.computeBoundingSphere(),p}function Vt(){let e=new x({color:16777215,vertexColors:!0,flatShading:!0,transparent:!0,depthTest:!0,depthWrite:!1,alphaTest:.012,toneMapped:!1});return e.name=`courtyard-birds`,e.customProgramCacheKey=()=>`courtyard-birds-hinge-v2`,e.color.multiplyScalar(1.5),e.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
attribute float birdAlpha; attribute float birdWing; attribute float birdPart; varying float vBirdAlpha;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vBirdAlpha = birdAlpha;
if (abs(birdPart) > 0.5) {
  float angle = -birdPart * birdWing;
  float c = cos(angle), s = sin(angle);
  transformed.xy = mat2(c, s, -s, c) * transformed.xy;
  transformed += vec3(birdPart * 0.075, 0.0, 0.015);
}`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
varying float vBirdAlpha;`).replace(`#include <alphatest_fragment>`,`diffuseColor.a *= vBirdAlpha;
#include <alphatest_fragment>`)},e}var Ht=e=>{let t=Math.min(1,Math.max(0,e));return t*t*(3-2*t)};function Ut(e,t,n,r){let i=Ht((Math.min(e-r.bounds.left,r.bounds.right-e,t-r.bounds.top,r.bounds.bottom-t)+n)/Math.max(1,n*2));for(let a of r.avoid){let o=Math.max(a.left-e,e-a.right,a.top-t,t-a.bottom)-n-r.margin;i*=Ht(o/Pt.fadePixels)}return i}function Wt(){let e=new r;e.name=`courtyard-birds`;let t=Bt(`all`),n=Vt(),i=new u(new Float32Array(3),1).setUsage(T),a=new u(new Float32Array(3),1).setUsage(T);t.setAttribute(`birdAlpha`,i),t.setAttribute(`birdWing`,a);let o=new R(t,n,3);o.name=`courtyard-birds-complete`,o.castShadow=!1,o.receiveShadow=!1,o.instanceMatrix.setUsage(T),o.boundingBox=new F(new D(-11,3.8,-10),new D(11,6.2,11)),o.boundingSphere=o.boundingBox.getBoundingSphere(new N),e.add(o);let s=Pt.routes.map(()=>Rt()),c=s.map(()=>({x:0,y:0,radius:0,alpha:0})),l=new D,d=new D,f=new p,m=NaN,h=NaN,g=``,_=!1;return{root:e,metadata:{birds:3,newGeometries:1,newTextures:0,maximumColorDrawCalls:1,extraPasses:0,castsShadows:!1,trianglesPerBird:t.getAttribute(`position`).count/3},update(e){if(!(_||e===m)){m=e;for(let t=0;t<s.length;t++)zt(e,t,s[t])}},present(t,n){if(_||h===m&&g===n.key)return;h=m,g=n.key;let r=n.bounds.right-n.bounds.left,u=n.bounds.bottom-n.bounds.top,p=0;for(let e=0;e<s.length;e++){let m=s[e],h=c[e];l.copy(m.position).project(t),h.x=n.bounds.left+(l.x*.5+.5)*r,h.y=n.bounds.top+(.5-l.y*.5)*u,h.radius=m.scale*Pt.bodyRadius*Math.abs(t.projectionMatrix.elements[5])*u*.5,h.alpha=l.z<-1||l.z>1?0:Ut(h.x,h.y,h.radius,n),h.alpha<Pt.minimumAlpha||(f.compose(m.position,m.rotation,d.setScalar(m.scale)),o.setMatrixAt(p,f),i.setX(p,h.alpha),a.setX(p,m.leftWing),p++)}o.count=p,e.visible=p>0,p&&(o.instanceMatrix.needsUpdate=!0,i.needsUpdate=!0,a.needsUpdate=!0)},snapshot(){return{time:m,visible:o.count,poses:s.map((e,t)=>({id:t,position:e.position.toArray(),rotation:e.rotation.toArray(),leftWing:e.leftWing,rightWing:e.rightWing,flap:e.flap,bank:e.bank,scale:e.scale,speed:e.speed,phase:e.phase,screen:{...c[t]}}))}},dispose(){_||(_=!0,o.dispose(),t.dispose(),n.dispose(),e.removeFromParent(),e.clear())}}}function Gt(e={},t=`legacy`,n=`legacy`,r=!1,i=!1){let a=me(e),o=kt(r&&a.options.enabled,a.time.value),c=Nt(o),l=new O;l.background=new S(z.grassBase);let u=new M;u.position.set(...de.camera.position),u.lookAt(...de.camera.target),u.near=de.camera.near,u.far=de.camera.far;let d=new re(de.ground.size,de.ground.size),p=Se(a),m=new f(d,p);m.name=`courtyard-ground`,m.rotation.x=-Math.PI/2,m.receiveShadow=!0,l.add(m);let h=ke(),g=je(h);l.add(g.root);let _;if(t===`refined`)try{_=Ct(l,h)}catch(e){console.warn(`Pool finish unavailable; original fountain retained.`,e)}let v=yt(h,n);l.add(v.root);let y=new s(z.highlight,z.stoneShade,B.fill.intensity);y.name=`courtyard-fill`;let b=new L(z.highlight,B.sun.intensity);b.name=`courtyard-sun`,b.position.set(...B.sun.position),b.castShadow=B.shadows.enabled;let x=B.shadows;b.shadow.mapSize.setScalar(x.mapSize),b.shadow.camera.left=-x.extent,b.shadow.camera.right=x.extent,b.shadow.camera.top=x.extent,b.shadow.camera.bottom=-x.extent,b.shadow.camera.near=x.near,b.shadow.camera.far=x.far,b.shadow.bias=x.bias,b.shadow.normalBias=x.normalBias,b.shadow.radius=x.radius,l.add(y,b,b.target);let C=de.camera.viewHeight,w=1;function T(e){w=e;let t=C/2;u.left=-t*e,u.right=t*e,u.top=t,u.bottom=-t,u.updateProjectionMatrix()}T(1),u.updateMatrixWorld(!0);let E=ze(u,a);l.add(E.root);let D=a.options.enabled&&a.options.petals?bt():void 0;D&&(D.update(a.time.value),l.add(D.mesh)),c.bind(l);let k;if(i&&a.options.enabled)try{k=Wt(),k.update(a.time.value),l.add(k.root)}catch(e){console.warn(`Birds unavailable; original courtyard retained.`,e)}let A=!1;return{scene:l,camera:u,setAspect:T,setViewHeight(e){if(!Number.isFinite(e)||e<=0)throw RangeError(`Camera view height must be positive.`);e!==C&&(C=e,T(w))},update(e){v.update(e),a.time.value=e,o.update(e),k?.update(e),D?.update(e)},waterState:h,fountainStyle:_?`refined`:t===`refined`?`fallback`:`legacy`,fountainMetadata:_?.metadata,orbStyle:v.root.userData.orbStyle??(n===`legacy`?`legacy`:`fallback`),orbMetadata:v.root.userData.orbMetadata,environmentState:a,cloudShadows:c,birds:k,dispose(){A||(A=!0,c.dispose(),k?.dispose(),d.dispose(),p.dispose(),_?.dispose(),g.dispose(),E.dispose(),v.dispose(),D?.dispose(),b.shadow.dispose(),l.clear())}}}var Kt=[320,384,448],qt={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function Jt(e){let t=Number(e.get(`pixelSize`));return{resolution:Kt.some(e=>e===t)?t:qt.resolution,finish:e.get(`finish`)===`soft`?`soft`:qt.finish,storage:`auto`}}function Yt(t,n){let r=n.storage!==`byte`&&t.extensions.has(`EXT_color_buffer_float`),o=new c(1,1,{type:r?a:v,minFilter:A,magFilter:A,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});o.texture.colorSpace=r?i:ee,o.texture.name=`courtyard-pixel-scene`;let s=new j;s.setAttribute(`position`,new e([-1,-1,0,3,-1,0,-1,3,0],3)),s.setAttribute(`uv`,new e([0,0,2,0,0,2],2));let u=qt.finishes[n.finish],d=new I({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:o.texture},uSampleSize:{value:new l(1,1)},uLevels:{value:u.levels},uDither:{value:u.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),p=new O,m=new M(-1,1,1,-1,0,1),h=new f(s,d);h.frustumCulled=!1,p.add(h);let g=!1,_=0;function y(){o.dispose(),s.dispose(),d.dispose()}return{releaseGpuResources:y,resize(e,t){let r=Math.min(1,n.resolution/Math.max(e,t)),i=Math.max(1,Math.round(e*r)),a=Math.max(1,Math.round(t*r));(i!==o.width||a!==o.height)&&(o.setSize(i,a),d.uniforms.uSampleSize.value.set(i,a),_++)},render(e,n){t.setRenderTarget(o),t.render(e,n),t.setRenderTarget(null),t.render(p,m)},getInfo(){return{sampleWidth:o.width,sampleHeight:o.height,designResolution:n.resolution,finish:n.finish,storage:r?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:u.levels,dither:u.dither,allocations:_}},dispose(){g||(g=!0,y(),p.clear())}}}function Xt(e){let t=new Set,n=new Set,r=new Set;e.traverse(e=>{if(e instanceof f||e instanceof b){t.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])n.add(t)}e instanceof R&&e.dispose(),e instanceof L&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of t)e.dispose();for(let e of n){for(let t of Object.values(e))t instanceof w&&r.add(t);if(e instanceof I)for(let t of Object.values(e.uniforms)){let e=Array.isArray(t.value)?t.value:[t.value];for(let t of e)t instanceof w&&r.add(t)}e.dispose()}for(let e of r)e.dispose()}function Zt(e,t,n,r=Jt(new URLSearchParams),i){let a=new ie({antialias:!1,alpha:!1});a.outputColorSpace=ee,a.toneMapping=0,a.shadowMap.enabled=!0,a.shadowMap.type=1,a.shadowMap.autoUpdate=!1,a.shadowMap.needsUpdate=!0,a.info.autoReset=!1;let o=Yt(a,r),s=new l,c=a.domElement;c.setAttribute(`role`,`img`),c.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(c);let u=t,d=!1,f=!1,p=!1,m=!1,h=!0,g,_,v,y=0,b=0,x=0,S=0;function C(){v!==void 0&&cancelAnimationFrame(v),v=void 0,y=0}function w(){d||f||m||h||!g||v!==void 0||y===0||(v=requestAnimationFrame(e=>{v=void 0,y--,d||f||m||h||(g?.(e),w())}))}function T(){d||f||m||h||!g||(y=Math.max(y,2),w())}function E(){let e=!d&&!f&&!m;(!e||h)&&C(),a.setAnimationLoop(e&&h&&g?g:null),e&&!h&&T()}function D(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||d)return;let r=Math.min(window.devicePixelRatio||1,fe.maxDevicePixelRatio),i=Math.max(1,Math.floor(t.width)),l=Math.max(1,Math.floor(t.height));(i!==b||l!==x||r!==S)&&(b=i,x=l,S=r,a.setPixelRatio(r),a.setSize(i,l,!1),a.getDrawingBufferSize(s),o.resize(s.x,s.y)),c.dataset.renderMode=u;let f=o.getInfo();c.dataset.sampleWidth=String(u===`pixel`?f.sampleWidth:s.x),c.dataset.sampleHeight=String(u===`pixel`?f.sampleHeight:s.y),c.dataset.pixelProfile=String(f.designResolution),c.dataset.finish=f.finish,n(t.width/t.height),T()}function O(t){t.preventDefault(),f=!0,p=!0,e.dataset.renderState=`context-lost`,E(),o.releaseGpuResources(),_&&Xt(_),i?.(`context-lost`)}function k(){f=!1,b=0,a.shadowMap.needsUpdate=!0,i?.(`restored`),D(),E()}c.addEventListener(`webglcontextlost`,O),c.addEventListener(`webglcontextrestored`,k);let A=new ResizeObserver(D);A.observe(e),window.addEventListener(`resize`,D);let j;function M(){j?.removeEventListener(`change`,N),j=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),j.addEventListener(`change`,N)}function N(){M(),D()}return M(),D(),{canvas:c,setMode(e){u=e,D()},setAnimating(e){h=e,E()},setSuspended(e){m!==e&&(m=e,E())},renderOnce(){g?.(performance.now()),T()},getStats(){return{geometries:a.info.memory.geometries,textures:a.info.memory.textures,programs:a.info.programs?.length??0,calls:a.info.render.calls,triangles:a.info.render.triangles,mode:u,outputWidth:a.domElement.width,outputHeight:a.domElement.height,pixel:u===`pixel`?o.getInfo():null}},start(t,n,r){_=t,g=s=>{d||f||m||(r?.(s),a.info.reset(),u===`pixel`?o.render(t,n):(a.setRenderTarget(null),a.render(t,n)),e.dataset.renderState=`ready`,p&&(p=!1,i?.(`ready`),T()))},E()},dispose(){d||(d=!0,C(),A.disconnect(),window.removeEventListener(`resize`,D),j.removeEventListener(`change`,N),c.removeEventListener(`webglcontextlost`,O),c.removeEventListener(`webglcontextrestored`,k),a.setAnimationLoop(null),g=void 0,_=void 0,o.dispose(),a.dispose(),!a.getContext().isContextLost()&&a.extensions.has(`WEBGL_lose_context`)&&a.forceContextLoss(),c.remove())}}}function Qt(e,t=W.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function $t(e,t,n=!1,r={}){let i=window.matchMedia(`(prefers-reduced-motion: reduce)`),a=Qt(t),o=n||r.retainReducedPause&&i.matches?!0:null,s=!1;function c(){return{playing:!document.hidden&&!(o??i.matches),hidden:document.hidden,reducedMotion:i.matches}}function l(){s||(a.resetTimestamp(),e(c()))}function u(){i.matches&&o!==!0&&(o=r.retainReducedPause?!0:null),l()}return document.addEventListener(`visibilitychange`,l),i.addEventListener(`change`,u),{get state(){return c()},get time(){return a.time},advance(e){return a.tick(e,c().playing)},resetTimestamp:a.resetTimestamp,toggle(){o=!(o??i.matches),l()},dispose(){s||(s=!0,document.removeEventListener(`visibilitychange`,l),i.removeEventListener(`change`,u))}}}export{Pt as a,pe as c,ue as d,le as f,ae as g,oe as h,Gt as i,fe as l,se as m,Zt as n,Oe as o,ce as p,Jt as r,W as s,$t as t,de as u};