import{$ as e,A as t,Dn as n,E as r,F as i,G as a,I as o,J as s,L as c,On as l,R as u,T as d,X as f,Y as p,_ as m,a as h,at as g,cn as _,dt as v,f as y,fn as b,hn as x,it as ee,jn as S,k as C,kn as w,ln as T,lt as E,mn as D,o as O,on as k,ot as A,pn as j,r as M,tt as N,u as te,un as ne,ut as re,w as P,yn as F,z as I}from"./three-core-Nz4Rm5ga.js";import{t as L}from"./three-renderer-Bo7ttXUR.js";var R={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},ie={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`};R.grassBase,R.stoneLight,R.stoneShade,R.treeShadow,R.waterBase,R.flower;var ae=new URL(`courtyard-motion-7fR7fsF8.mp4`,import.meta.url).href,oe=new URL(`courtyard-keyframe-00-Dnvt_afN.png`,import.meta.url).href,se=new URL(`courtyard-keyframe-03-BpIvPl5V.png`,import.meta.url).href,ce=new URL(`signal-garden-CbiDrnMk.webp`,import.meta.url).href,le=new URL(`liquid-form-Yl5oqdSL.webp`,import.meta.url).href,z={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},ue={defaultMode:`pixel`,maxDevicePixelRatio:2},B={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},V={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},column:{layerRatios:[1.07,.96,1.03,.94],layerSeeds:[11,29,47],layerChips:[0,.028,.052],baseBevel:.024,capBevel:.038,profiles:[{layers:[0,1,0,2],offsets:[-.012,.012,-.008,0],capCorner:2,capChip:.12},{layers:[1,2,0,1],offsets:[.008,-.01,.01,0],capCorner:1,capChip:.095},{layers:[2,0,1,0],offsets:[-.008,.012,-.008,0],capCorner:3,capChip:.145}]},fountain:{copingHeight:.14,jointWidth:.032,bevel:.024,chippedSegments:[1,5],chipSize:.1},wall:{bodyBlocks:3,capBlocks:2},path:{bevel:.014,cornerCut:.045,chippedSlabs:[1,4,6],chipSize:.065}},H={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25]},grass:{count:240,gapCount:12,minHeight:.065,maxHeight:.14,clearance:.06,gapMinHeight:.105,gapMaxHeight:.13,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},U={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function de(e){return{enabled:e.get(`env`)!==`off`&&U.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||U.petals.enabled}}var W={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function fe(e={}){let t={...de(new URLSearchParams),...e};return{options:t,time:{value:W.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function pe(e,t){let n=Math.sin(e*12.9898+t*78.233+U.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var me=Math.hypot(...U.wind.direction),he=[U.wind.direction[0]/me,U.wind.direction[1]/me],G=e=>e.toFixed(10),ge=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${he.map(G).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,_e=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${G(U.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${G(U.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function ve(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${ge}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${_e}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${G(U.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${G(U.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function ye(t,n,r={}){let i=new e,a=t===`foliage`||t===`flower`;i.name=`courtyard-${t}`,i.userData.artSurface=t;let o=n?.options.enabled&&(a||t===`ground`);return i.customProgramCacheKey=()=>`courtyard-art-${t}-v3${o?`-environment-v1`:``}`,i.onBeforeCompile=e=>{let i=B.treeShadows,s=H.ground,c=H.treeDetail;Object.assign(e.uniforms,{uArtSunAmount:{value:B.sun.intensity},uArtFillAmount:{value:B.fill.intensity},uArtStoneVariation:{value:V.colorVariation},uArtGrass:{value:new y(R.grassBase)},uArtGrassLight:{value:new y(R.grassLight)},uArtGrassDark:{value:new y(R.grassDark)},uArtGrassShadow:{value:new y(R.treeShadow)},uArtStoneTop:{value:new y(r.top??R.stoneLight)},uArtStoneSide:{value:new y(r.side??R.stoneSide)},uArtStoneShade:{value:new y(r.shade??R.stoneShade)},uArtWater:{value:new y(R.waterBase)},uArtWaterShade:{value:new y(R.waterShade)},uArtPlantShade:{value:new y(R.plantShade)},uArtFlowerShade:{value:new y(R.flowerShade)},uArtFlowerCenter:{value:new y(R.flowerCenter)},uArtGroundEnabled:{value:+!!s.enabled},uArtGroundScales:{value:new w(s.macroScale,s.macroStrength,s.detailScale,s.detailStrength)},uArtGroundDensity:{value:s.detailDensity},uArtQuietRegion:{value:new w(s.quietCenter[0],s.quietCenter[1],s.quietRadius[0],s.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!c.enabled},uArtTreeDetail:{value:new w(c.branchScale,c.leafScale,c.edgeBreakup,c.gapStrength)},uArtTreesEnabled:{value:+!!i.enabled},uArtTreeNoiseScale:{value:i.edgeNoiseScale},uArtTreeNoiseAmount:{value:i.edgeNoiseAmount},uArtTreeSoftness:{value:i.edgeSoftness},uArtTreePatches:{value:i.patches.map(e=>new w(e.center[0],e.center[1],e.radius[0],e.radius[1]))},uArtTreeRotations:{value:i.patches.map(e=>e.rotation)}}),e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${t===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${a?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${t===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${a?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let l=`
      varying vec3 vArtWorldPosition;
      ${t===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${a?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${i.patches.length}];
      uniform float uArtTreeRotations[${i.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${i.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${l}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[t]}\n#include <opaque_fragment>`),o&&ve(e,a,n)},i}function be(e){return ye(`ground`,e)}var K={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08,baseHeight:.18,shaftWidth:.72,shaftDepth:.78,shaftHeight:3.05,capWidth:1.02,capDepth:1.04,capHeight:.24},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,columns:4,rows:2,stepX:.74,stepZ:.63,slabWidth:.63,slabDepth:.52,slabHeight:.09}},q=1e-7;function xe(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<q*q)||t.push(n);return t}function Se(e,t,n){let r=[],i=[];for(let a of e){let e=[];for(let r=0;r<a.length;r++){let o=a[r],s=a[(r+1)%a.length],c=t.dot(o)-n,l=t.dot(s)-n;if(c<=q&&e.push(o),c<-1e-7&&l>q||c>q&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),i.push(t)}else Math.abs(c)<=q&&i.push(o)}let o=xe(e);o.length>=3&&r.push(o)}let a=xe(i);if(a.length>=3){let e=a.reduce((e,t)=>e.add(t),new l).divideScalar(a.length),n=Math.abs(t.y)<.9?new l(0,1,0):new l(1,0,0),i=t.clone().cross(n).normalize(),o=t.clone().cross(i).normalize();a.sort((t,n)=>{let r=t.clone().sub(e),a=n.clone().sub(e);return Math.atan2(r.dot(o),r.dot(i))-Math.atan2(a.dot(o),a.dot(i))}),r.push(a)}return r}function Ce(e,n){let r=e.getAttribute(`position`),i=Math.sin(n*12.9898+.73)*.65,a=new Float32Array(r.count);for(let e=0;e<r.count;e++)a[e]=i+Math.sin(r.getX(e)*1.6+r.getZ(e)*2.3+n)*.25;return e.setAttribute(`stoneTint`,new t(a,1)),e}function we(e,n,r){if(e.length<3||n<=0)throw Error(`Stone prism needs a polygon and positive height.`);let i=e.map(([e,t])=>[e,t]);i.reduce((e,t,n)=>{let r=i[(n+1)%i.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(i=i.reverse());let a=n/2,o=i.map(([e,t])=>new l(e,a,t)),s=i.map(([e,t])=>new l(e,-a,t)),c=[o,[...s].reverse()],u=[];for(let e=0;e<i.length;e++){let t=(e+1)%i.length,n=s[e],r=s[t];c.push([n,r,o[t],o[e]]);let a=r.clone().sub(n).cross(new l(0,1,0)).normalize();u.push({normal:a,distance:a.dot(n)})}let d=Math.min(r.bevel,n*.2);for(let e=0;e<u.length;e++){let t=u[e];for(let e of[-1,1]){let n=t.normal.clone().add(new l(0,e,0)),r=(t.distance+a-d)/n.length();c=Se(c,n.normalize(),r)}let n=u[(e+u.length-1)%u.length],i=n.normal.clone().add(t.normal),o=(n.distance+t.distance-r.cornerCut)/i.length();c=Se(c,i.normalize(),o)}if(r.chipSize&&r.chipSize>0){let e=(r.chipCorner??0)%u.length,t=u[(e+u.length-1)%u.length],n=u[e],i=t.normal.clone().add(n.normal).add(new l(0,1,0)),o=(t.distance+n.distance+a-r.chipSize)/i.length();c=Se(c,i.normalize(),o)}let f=[],p=[];for(let e of c){let t=e.reduce((e,t)=>e.add(t),new l).divideScalar(e.length),n=new l;for(let r=0;r<e.length;r++)n.add(e[r].clone().sub(t).cross(e[(r+1)%e.length].clone().sub(t)));if(!(n.lengthSq()<q*q)){n.normalize();for(let r=0;r<e.length;r++){let i=e[r],a=e[(r+1)%e.length];if(!(i.clone().sub(t).cross(a.clone().sub(t)).lengthSq()<q*q))for(let e of[t,i,a])f.push(e.x,e.y,e.z),p.push(n.x,n.y,n.z)}}}let m=new O;return m.setAttribute(`position`,new t(f,3)),m.setAttribute(`normal`,new t(p,3)),Ce(m,r.seed),m.computeBoundingBox(),m.computeBoundingSphere(),m.userData.stoneSolid=!0,m}function Te(e,t,n,r){let i=e/2,a=n/2;return we([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}function Ee(e){return ye(`stone`,void 0,e)}function De(){return{time:{value:W.initialTime},impacts:{value:Array.from({length:W.ripples.capacity},()=>new w(0,0,0,0))}}}function Oe(e=De(),t=`surface`){let n=ye(`water`);n.name=`courtyard-water-${t}`,n.flatShading=t===`jet`,n.userData.waterKind=t,n.customProgramCacheKey=()=>`courtyard-water-${t}-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=K.fountain;Object.assign(n.uniforms,{uWaterTime:e.time,uWaterImpacts:e.impacts,uWaterEnabled:{value:+!!W.enabled},uWaterBase:{value:new y(W.colors.base)},uWaterDeep:{value:new y(W.colors.deep)},uWaterShade:{value:new y(W.colors.shade)},uWaterWhite:{value:new y(W.colors.highlight)},uWaterJet:{value:new y(W.colors.jet)},uWaterOrigin:{value:new w(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uWaterSurface:{value:new w(W.surface.flowSpeed,W.surface.reflectionThreshold,W.surface.waveSpeed,W.surface.waveStrength)},uWaterRipple:{value:new w(W.ripples.lifetime,W.ripples.speed,W.ripples.strength,a.innerRadius*Math.cos(Math.PI/8))}});let o=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${W.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,c=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(c))throw Error(`Water shader extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(c,t===`surface`?s:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},n}function ke(e){let t=new i;t.name=`courtyard-blockout`;let n=new Set;function r(e){return n.add(e),e}let a=new Map,o=Ee(),s=Oe(e);function c(e,t,n,i,s,c,l=0,u=0,d={}){let f={bevel:V.bevel,cornerCut:V.cornerCut,seed:11,...d},m=JSON.stringify([n,i,s,f]),h=a.get(m);h||(h=r(Te(n,i,s,f)),a.set(m,h));let g=new p(h,o);return g.name=t,g.position.set(l,c+i/2,u),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let l=K.fountain,u=new i;u.name=`fountain`,u.position.set(...l.position),u.rotation.y=l.rotationY,t.add(u);let d=new p(r(we(Array.from({length:8},(e,t)=>[Math.cos(t*Math.PI/4)*l.baseRadius,-Math.sin(t*Math.PI/4)*l.baseRadius]),l.baseHeight,{bevel:.018,cornerCut:.025,seed:11})),o);d.name=`fountain-base`,d.position.y=l.baseHeight/2,d.castShadow=!0,d.receiveShadow=!0,u.add(d);let f=new ne,m=new A;for(let e=0;e<8;e++){let t=e*Math.PI/4,n=-t,r=Math.cos(t)*l.outerRadius,i=Math.sin(t)*l.outerRadius,a=Math.cos(n)*l.innerRadius,o=Math.sin(n)*l.innerRadius;e===0?(f.moveTo(r,i),m.moveTo(a,o)):(f.lineTo(r,i),m.lineTo(a,o))}f.closePath(),m.closePath(),f.holes.push(m);let h=new i;h.name=`fountain-rim`,h.position.y=l.baseHeight,u.add(h);let g=V.fountain,_=l.rimHeight-g.copingHeight,v=new p(r(Ce(new C(f,{depth:_,bevelEnabled:!1,steps:1,curveSegments:1}),11)),o);v.name=`fountain-rim-wall`,v.rotation.x=-Math.PI/2,v.castShadow=!0,v.receiveShadow=!0,h.add(v);function y(e){let t=Math.cos(Math.PI/4)*e,n=-Math.sin(Math.PI/4)*e,r=g.jointWidth/(2*Math.hypot(t-e,n));return[[e+(t-e)*r,n*r],[t+(e-t)*r,n*(1-r)]]}let[b,x]=y(l.outerRadius),[ee,S]=y(l.innerRadius),w=new Map;for(let e=0;e<8;e++){let t=g.chippedSegments.some(t=>t===e),n=t?`chip-${e%2}`:`plain-${e%2}`,i=w.get(n);i||(i=r(we([b,x,S,ee],g.copingHeight,{bevel:g.bevel,cornerCut:.025,seed:29+e%2,chipSize:t?g.chipSize:0,chipCorner:e%2})),w.set(n,i));let a=new p(i,o);a.name=`fountain-coping-${e}`,a.position.y=_+g.copingHeight/2,a.rotation.y=e*Math.PI/4,a.castShadow=!0,a.receiveShadow=!0,h.add(a)}let T=new p(r(new te(l.innerRadius-.008,8)),s);T.name=`fountain-water`,T.rotation.x=-Math.PI/2,T.position.y=l.waterHeight,T.receiveShadow=!0,u.add(T),c(u,`fountain-pedestal-foot`,l.pedestalFootSize,l.pedestalFootHeight,l.pedestalFootSize,l.baseHeight);let E=l.baseHeight+l.pedestalFootHeight;c(u,`fountain-pedestal`,l.pedestalSize,l.pedestalHeight,l.pedestalSize,E),c(u,`fountain-pedestal-cap`,l.pedestalCapSize,l.pedestalCapHeight,l.pedestalCapSize,E+l.pedestalHeight,0,0,{bevel:.016,chipSize:.06,chipCorner:2,seed:29});let D=K.columnShape;for(let[e,n]of K.columns.entries()){let r=new i;r.name=n.name;let[a,o,s]=n.position;r.position.set(a,o,s),r.rotation.y=n.rotationY;let l=V.column,u=l.profiles[e];c(r,`${n.name}-base`,D.baseWidth,D.baseHeight,D.baseDepth,0,0,0,{bevel:l.baseBevel,chipSize:.04,chipCorner:e%2,seed:29});let d=new i;d.name=`${n.name}-shaft`,r.add(d);let f=V.joints.width,p=l.layerRatios,m=D.shaftHeight-f*(p.length-1),h=p.reduce((e,t)=>e+t,0),g=D.baseHeight;for(let e=0;e<p.length;e++){let t=m*p[e]/h,r=u.layers[e];c(d,`${n.name}-block-${e}`,D.shaftWidth,t,D.shaftDepth,g,u.offsets[e],0,{seed:l.layerSeeds[r],chipSize:l.layerChips[r],chipCorner:r}),g+=t,e<p.length-1&&(c(d,`${n.name}-joint-${e}`,D.shaftWidth-V.joints.recess*2,f,D.shaftDepth-V.joints.recess*2,g,0,0,{bevel:0,cornerCut:0,seed:47}),g+=f)}c(r,`${n.name}-cap`,D.capWidth,D.capHeight,D.capDepth,D.baseHeight+D.shaftHeight,0,0,{bevel:l.capBevel,chipSize:u.capChip,chipCorner:u.capCorner,seed:47+e}),t.add(r)}let O=K.wall,k=new i;k.name=`wallLeft`,k.position.set(...O.position),k.rotation.y=O.rotationY,c(k,`wallLeft-base`,O.length+O.endSize,O.baseHeight,O.baseDepth,0);let j=new i;j.name=`wallLeft-body`,k.add(j);let M=V.wall.bodyBlocks,N=V.joints.width,re=(O.length-(M-1)*N)/M;for(let e=0;e<M;e++){let t=-O.length/2+re/2+e*(re+N);c(j,`wallLeft-body-${e}`,re,O.height,O.depth,O.baseHeight,t,0,{seed:11+e*18,chipSize:e===M-1?.075:0,chipCorner:2}),e<M-1&&c(j,`wallLeft-body-joint-${e}`,N,O.height,O.depth-V.joints.recess*2,O.baseHeight,t+re/2+N/2,0,{bevel:0,cornerCut:0,seed:47})}let P=new i;P.name=`wallLeft-cap`,k.add(P);let F=V.wall.capBlocks,I=(O.length-(F-1)*N)/F;for(let e=0;e<F;e++){let t=-O.length/2+I/2+e*(I+N);c(P,`wallLeft-cap-${e}`,I,O.capHeight,O.capDepth,O.baseHeight+O.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===F-1?.065:0,chipCorner:2}),e<F-1&&c(P,`wallLeft-cap-joint-${e}`,N,O.capHeight*.65,O.capDepth-V.joints.recess*2,O.baseHeight+O.height,t+I/2+N/2,0,{bevel:0,cornerCut:0,seed:47})}c(k,`wallLeft-end`,O.endSize,O.endHeight,O.endSize,O.baseHeight,O.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(k);let L=K.path,R=new i;R.name=`pathRight`,R.position.set(...L.position),R.rotation.y=L.rotationY;for(let e=0;e<L.rows;e++)for(let t=0;t<L.columns;t++)c(R,`pathRight-slab-${e}-${t}`,L.slabWidth,L.slabHeight,L.slabDepth,0,(t-(L.columns-1)/2)*L.stepX,(e-(L.rows-1)/2)*L.stepZ,{bevel:V.path.bevel,cornerCut:V.path.cornerCut,seed:11+(e*L.columns+t)%3*18,chipSize:V.path.chippedSlabs.some(n=>n===e*L.columns+t)?V.path.chipSize:0,chipCorner:(e*L.columns+t)%4});t.add(R);let ie=!1;return{root:t,dispose(){if(!ie){ie=!0,t.removeFromParent(),t.clear();for(let e of n)e.dispose();o.dispose(),s.dispose()}}}}function Ae(e,n,r){let i=new O;return i.setAttribute(`position`,new t(e,3)),i.setAttribute(`plantPart`,new t(n,1)),i.setAttribute(`plantHeight`,new t(r,1)),i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function je(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>Ae(e,t,n)}}function Me(){let e=je();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function Ne(){let e=je();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function Pe(e){let t=je();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function Fe(e,t){let n=ye(e,t);return n.side=2,n}function Ie(e,t,n,r=.035){let i=K.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=K.columnShape;for(let n of K.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=K.wall;if(f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY))return!1;let h=K.path;for(let n=0;n<h.rows;n++)for(let r=0;r<h.columns;r++){let i=(r-(h.columns-1)/2)*h.stepX,a=(n-(h.rows-1)/2)*h.stepZ;if(f(e,t,h.position[0]+Math.cos(h.rotationY)*i+Math.sin(h.rotationY)*a,h.position[2]-Math.sin(h.rotationY)*i+Math.cos(h.rotationY)*a,h.slabWidth,h.slabDepth,h.rotationY))return!1}return!0}function Le(e,t){let n=new i;n.name=`courtyard-vegetation`;let r=H.seed;function a(){r+=1831565813;let e=Math.imul(r^r>>>15,1|r);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let o=(e,t)=>e+(t-e)*a();function c(t,n){let r=new l(t,0,n).project(e);return Math.abs(r.x)<.98&&Math.abs(r.y)<.98}function d(e,t){let n=H.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let f=[],p=[];if(H.enabled){for(let e=0;f.length<H.grass.count&&e<H.grass.count*120;e++){let e,t;if(a()<.48){let n=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],r=a()*Math.PI*2,i=Math.sqrt(a())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=o(-7.5,7.4),t=o(-8.7,8.4);!c(e,t)||!Ie(e,t,H.grass.clearance)||d(e,t)&&a()<.9||f.push({x:e,z:t,height:o(H.grass.minHeight,H.grass.maxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:H.grass.clearance,gap:!1})}for(let e=0;p.length<H.flowers.count&&e<H.flowers.count*120;e++){let e=H.flowers.clusters[Math.floor(a()*H.flowers.clusters.length)],t=a()*Math.PI*2,n=a()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,s=o(H.flowers.minDiameter,H.flowers.maxDiameter),l=s*.55+.01;c(r,i)&&!d(r,i)&&Ie(r,i,l)&&(p.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+l)*.85)||p.push({x:r,z:i,height:o(H.flowers.minHeight,H.flowers.maxHeight),diameter:s,rotation:a()*Math.PI*2,color:a(),radius:l,gap:!1}))}if(f.length!==H.grass.count||p.length!==H.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=K.path,t=[];for(let n=0;n<e.rows;n++)for(let r=0;r<e.columns-1;r++)t.push([(r-(e.columns-2)/2)*e.stepX,(n-(e.rows-1)/2)*e.stepZ]);for(let n=0;n<e.columns;n++)t.push([(n-(e.columns-1)/2)*e.stepX,0]);t.push([-e.stepX,0],[e.stepX,0]);for(let[n,r]of t.slice(0,H.grass.gapCount)){let t=e.position[0]+Math.cos(e.rotationY)*n+Math.sin(e.rotationY)*r+o(-.006,.006),i=e.position[2]-Math.sin(e.rotationY)*n+Math.cos(e.rotationY)*r+o(-.006,.006);if(!Ie(t,i,.023,.008))throw Error(`Paving gap vegetation intersects stone.`);f.push({x:t,z:i,height:o(H.grass.gapMinHeight,H.grass.gapMaxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:.023,gap:!0})}}let m=[],h=[],g=[];if(H.enabled){let e=Fe(`foliage`,t),r=Fe(`flower`,t);h.push(e,r);let i=Me(),a=Ne(),o=Pe(4),c=Pe(5);m.push(i,a,o,c);function d(e,r,i,a,o){let c=new I(r,i,a.length);c.name=e,c.castShadow=!1,c.receiveShadow=!0;let d=new s,f=new v,p=new l(0,1,0),m=new y(o===`flower`?R.flower:o===`stem`?R.plantStem:R.grassBlade),h=new y(o===`flower`?R.flowerLight:R.grassBladeLight);if(a.forEach((e,t)=>{f.setFromAxisAngle(p,e.rotation);let n=o===`flower`?e.diameter:e.height,r=o===`grass`&&e.gap?H.grass.gapWidthScale:1;d.compose(new l(e.x,H.rootHeight+(o===`flower`?e.height:0),e.z),f,new l(n*r,n,n*r)),c.setMatrixAt(t,d),c.setColorAt(t,m.clone().lerp(h,o===`stem`?e.color*.25:o===`flower`?e.color*.6:e.color*.85))}),c.instanceMatrix.needsUpdate=!0,c.instanceColor&&(c.instanceColor.needsUpdate=!0),t?.options.enabled){let e=new Float32Array(a.length*3),t=new Float32Array(a.length*4);a.forEach((n,r)=>{let i=o===`grass`?n.gap?U.wind.gapAngle:U.wind.grassAngle:U.wind.flowerAngle;e.set([n.x,H.rootHeight,n.z],r*3),t.set([n.height,i,pe(n.x,n.z),+(o===`flower`)],r*4)}),r.setAttribute(`windRoot`,new u(e,3)),r.setAttribute(`windShape`,new u(t,4))}c.computeBoundingBox(),c.computeBoundingSphere(),t?.options.enabled&&(c.boundingBox.expandByScalar(.02),c.boundingSphere.radius+=.02),c.userData.plants=a,c.userData.plantType=o,g.push(c),n.add(c)}d(`grass-clusters`,i,e,f,`grass`),d(`flower-stems`,a,e,p,`stem`),d(`flowers-four-petal`,o,r,p.filter((e,t)=>t%2==0),`flower`),d(`flowers-five-petal`,c,r,p.filter((e,t)=>t%2==1),`flower`)}n.userData.seed=H.seed,n.userData.counts={grass:f.length,flowers:p.length,batches:g.length};let _=!1;return{root:n,dispose(){if(!_){_=!0;for(let e of g)e.dispose();for(let e of m)e.dispose();for(let e of h)e.dispose();n.removeFromParent(),n.clear()}}}}var J={radius:.26,centerY:1.37,floatAmplitude:.03,floatPeriod:6,sphereSegments:[12,8],shape:{first:.025,second:.009,x:.012,y:.015,z:.012,yRatio:.96,envelope:(1.025+.009)*1.012},flow:{mainPeriod:7.2,detailPeriod:4.1,turnPeriod:23,main:[2.2,7.4,.8],bend:[3.2,0,2],bendStrength:.8,detail:[2.1,-3,7]},stemRadius:.04,stemOverlap:.025,releaseLatitude:-.16,releaseMargin:.004,colors:{base:`#80B9D5`,light:`#ADDCE8`,side:`#4D89B2`,shade:`#427192`,white:`#F3FBFF`}},Re=Math.PI*2,Y=J.flow,ze=(e,t)=>(e%t+t)%t/t*Re;function Be(e,t=new w){let n=ze(e,Y.turnPeriod);return t.set(Math.cos(n),Math.sin(n),ze(e,Y.mainPeriod),ze(e,Y.detailPeriod))}function Ve(e,t,n,r){let i=r.x*e-r.y*n,a=r.y*e+r.x*n,o=i*Y.bend[0]+t*Y.bend[1]+a*Y.bend[2]+r.w,s=i*Y.main[0]+t*Y.main[1]+a*Y.main[2]+Y.bendStrength*Math.sin(o)+r.z,c=i*Y.detail[0]+t*Y.detail[1]+a*Y.detail[2]-r.w;return 1+J.shape.first*Math.cos(s)+J.shape.second*Math.sin(c)}function He(e,t,n,r,i=new l){let a=r.x*e-r.y*n,o=r.y*e+r.x*n,s=a*Y.bend[0]+t*Y.bend[1]+o*Y.bend[2]+r.w,c=a*Y.main[0]+t*Y.main[1]+o*Y.main[2]+Y.bendStrength*Math.sin(s)+r.z,u=a*Y.detail[0]+t*Y.detail[1]+o*Y.detail[2]-r.w,d=-J.shape.first*Math.sin(c),f=J.shape.second*Math.cos(u),p=Y.bendStrength*Math.cos(s),m=d*(Y.main[0]+p*Y.bend[0])+f*Y.detail[0],h=d*(Y.main[1]+p*Y.bend[1])+f*Y.detail[1],g=d*(Y.main[2]+p*Y.bend[2])+f*Y.detail[2],_=r.x*m+r.y*g,v=-r.y*m+r.x*g,y=1+J.shape.first*Math.cos(c)+J.shape.second*Math.sin(u),b=e*_+t*h+n*v;return i.set(e-(_-e*b)/y,t-(h-t*b)/y,n-(v-n*b)/y).normalize()}var Ue=Math.PI*2/J.floatPeriod,We=()=>({y:0,sx:1,sy:1,sz:1});function Ge(e,t=We()){let n=e*Ue;return t.y=J.centerY+J.floatAmplitude*Math.sin(n),t.sx=1+J.shape.x*Math.sin(n*.73),t.sy=J.shape.yRatio*(1+J.shape.y*Math.sin(n+.8)),t.sz=1+J.shape.z*Math.cos(n*.81),t}var Ke=()=>({birthTime:NaN,x:0,y:0,z:0,vx:0,vy:0,vz:0,duration:0,impactX:0,impactZ:0}),qe=We(),Je=new w,X=new l;function Ye(e,t,n=Ke()){let r=Ge(t,qe),i=Math.hypot(e.vx,e.vz),a=J.releaseLatitude,o=Math.sqrt(1-a*a),s=e.vx/i*o,c=a,l=e.vz/i*o;Be(t,Je);let u=J.radius*Ve(s,c,l,Je);He(s,c,l,Je,X),X.set(X.x/r.sx,X.y/r.sy,X.z/r.sz).normalize();let d=e.radius+J.releaseMargin;n.birthTime=t,n.x=s*u*r.sx+X.x*d,n.y=r.y+c*u*r.sy+X.y*d,n.z=l*u*r.sz+X.z*d,n.vx=e.vx,n.vz=e.vz,n.vy=e.vy+J.floatAmplitude*Ue*Math.cos(t*Ue);let f=n.y-K.fountain.waterHeight-e.radius;return n.duration=(n.vy+Math.sqrt(n.vy*n.vy+2*W.drops.gravity*f))/W.drops.gravity,n.impactX=n.x+n.vx*n.duration,n.impactZ=n.z+n.vz*n.duration,n}function Xe(e,t,n){return n.set(e.x+e.vx*t,e.y+e.vy*t-.5*W.drops.gravity*t*t,e.z+e.vz*t)}function Ze(e){let t=ye(`water`);t.name=`courtyard-living-orb`,t.flatShading=!0,t.customProgramCacheKey=()=>`courtyard-living-orb-flow-v2`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r),Object.assign(t.uniforms,{uOrbPhases:{value:e},uOrbBase:{value:new y(J.colors.base)},uOrbLight:{value:new y(J.colors.light)},uOrbSide:{value:new y(J.colors.side)},uOrbShade:{value:new y(J.colors.shade)},uOrbWhite:{value:new y(J.colors.white)}});let i=e=>`vec3(${e.map(e=>e.toFixed(6)).join(`, `)})`,a=J.flow,o=`
      // Rest coordinates interpolate across faces; normalize only per fragment.
      // No atan/UV wrapping, screen coordinates or independently running clock.
      vec3 rest = normalize(vOrbRest);
      vec3 q = vec3(uOrbPhases.x * rest.x - uOrbPhases.y * rest.z, rest.y,
                    uOrbPhases.y * rest.x + uOrbPhases.x * rest.z);
      float bend = dot(q, ${i(a.bend)}) + uOrbPhases.w;
      float mainPhase = dot(q, ${i(a.main)}) + ${a.bendStrength.toFixed(6)} * sin(bend) + uOrbPhases.z;
      float detailPhase = dot(q, ${i(a.detail)}) - uOrbPhases.w;
      float wave = cos(mainPhase);
      // Derivative filtering broadens the crest at the original 384px sampling.
      // Unresolvable secondary ripples fade out instead of flashing single pixels.
      float aa = clamp(fwidth(wave) * .65, .035, .38);
      float flowBand = smoothstep(-.45 - aa, .45 + aa, wave);
      float crest = smoothstep(.76 - aa, .96 + aa, wave);
      float detailVisibility = 1.0 - smoothstep(.55, 1.6, fwidth(detailPhase));
      float detailWave = sin(detailPhase);
      float shortCrest = smoothstep(.72 - aa, .98 + aa, detailWave) * detailVisibility;
      vec3 orbNormal = inverseTransformDirection(normal, viewMatrix);
      float sunFace = .5;
      #if NUM_DIR_LIGHTS > 0
        sunFace = max(dot(normal, directionalLights[0].direction), 0.0);
      #endif
      float volume = smoothstep(-.6, .7, orbNormal.y) * .6 + sunFace * .4;
      vec3 orbColor = mix(uOrbSide, uOrbBase, smoothstep(.08, .92, volume));
      orbColor = mix(orbColor, uOrbLight, flowBand * .46);
      orbColor = mix(orbColor, uOrbSide, (1.0 - flowBand) * .20);
      float edge = pow(1.0 - clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0), 2.6);
      float litCrest = mix(.52, 1.0, sunFace) * mix(.65, 1.0, smoothstep(-.7, .55, orbNormal.y));
      float rim = smoothstep(.35, .85, edge) * smoothstep(-.15, .6, orbNormal.y);
      float movingHighlight = crest * litCrest * .85 + shortCrest * flowBand * .12;
      orbColor = mix(orbColor, uOrbWhite, clamp(movingHighlight + rim * .13, 0.0, .86));
      outgoingLight = mix(uOrbShade, orbColor, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Orb shader extension anchor changed.`);if(!t.vertexShader.includes(`#include <begin_vertex>`))throw Error(`Orb rest-position anchor changed.`);t.vertexShader=t.vertexShader.replace(`#include <common>`,`#include <common>
attribute vec3 orbRest; varying vec3 vOrbRest;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vOrbRest = orbRest;`),t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      varying vec3 vOrbRest;
      uniform vec4 uOrbPhases;
      uniform vec3 uOrbBase; uniform vec3 uOrbLight; uniform vec3 uOrbSide; uniform vec3 uOrbShade; uniform vec3 uOrbWhite;
    
void main() {`).replace(s,o)},t}function Qe(e,t){let n=new i;n.name=`fountain-effects`,n.userData.orbStyle=`lively`;let r=K.fountain;n.position.set(...r.position),n.rotation.y=r.rotationY;let a=new w,o=Oe(e,`jet`),c=Ze(a),u=r.baseHeight+r.pedestalFootHeight+r.pedestalHeight+r.pedestalCapHeight,f=new m(J.stemRadius,J.stemRadius,1,8),g=new j(1,...J.sphereSegments),_=g.getAttribute(`position`);_.setUsage(d);let y=new Float32Array(_.array);g.setAttribute(`orbRest`,new h(y,3)),g.boundingSphere=new b(new l,J.shape.envelope),g.boundingBox=new M(new l().setScalar(-J.shape.envelope),new l().setScalar(J.shape.envelope));let x=new ee(1,0),S=new p(f,o);S.name=`fountain-water-column`,S.receiveShadow=!0;let C=new p(g,c);C.name=`fountain-water-crown`,C.receiveShadow=!0,C.scale.setScalar(J.radius);let T=new I(x,o,t.length);T.name=`fountain-water-drops`,T.receiveShadow=!0,T.instanceMatrix.setUsage(d),T.boundingBox=new M(new l(-1.75,.3,-1.75),new l(1.75,1.9,1.75)),T.boundingSphere=T.boundingBox.getBoundingSphere(new b),n.add(S,C,T),n.visible=W.enabled;let E=We(),D=new l,O=new l,k=new v,A=new s,N=new s,te=t.map((e,t)=>({drop:e,index:t,current:Ke(),previous:Ke()})),ne=te.map(e=>({record:e,age:0,flight:e.current}));n.userData.flights=te,n.userData.orbPose=E,n.userData.impactEvents=ne,n.userData.orbPhases=a,n.userData.orbMetadata={radius:J.radius,centerY:J.centerY,amplitude:J.floatAmplitude,period:J.floatPeriod,envelope:J.shape.envelope,replacedGeometries:2,addedGeometries:0,addedTextures:0,addedPasses:0,flow:`curved-rest-sphere-v2`,vertices:_.count,triangles:g.index.count/3,restAttributeBytes:y.byteLength,dropCapacity:t.length,rippleCapacity:e.impacts.value.length};let re,P=!1;function F(r){if(P||r===re)return;re=r,e.time.value=r,Ge(r,E),Be(r,a);let i=1/0;for(let e=0;e<_.count;e++){let t=e*3,n=y[t],r=y[t+1],o=y[t+2],s=Ve(n,r,o,a),c=r*s*E.sy;_.setXYZ(e,n*s*E.sx,c,o*s*E.sz),i=Math.min(i,c)}_.needsUpdate=!0,C.position.y=E.y;let o=E.y+i*J.radius,s=o+J.stemOverlap;S.position.y=(u+s)/2,S.scale.y=s-u;let c=0;for(let e of te){let{drop:t,current:n,previous:i}=e,a=t.phase+Math.floor((r-t.phase)/W.drops.period)*W.drops.period;a!==n.birthTime&&(Ye(t,a,n),Ye(t,a-W.drops.period,i));let o=r-a;if(o>=n.duration)continue;let s=t.radius*Math.min(1,o/.07,(n.duration-o)/.055);s<5e-4||(Xe(n,o,D),O.setScalar(s),A.compose(D,k,O),T.setMatrixAt(c++,A))}T.count=c;for(let e=c;e<t.length;e++)T.setMatrixAt(e,N);T.instanceMatrix.needsUpdate=!0;for(let e of ne){let t=e.record;e.flight=r>=t.current.birthTime+t.current.duration?t.current:t.previous,e.age=r-e.flight.birthTime-e.flight.duration}ne.sort((e,t)=>e.age-t.age||e.record.index-t.record.index);let l=0;for(let t=0;t<e.impacts.value.length;t++){let n=ne[t];n.age>=0&&n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.flight.impactX,n.flight.impactZ,n.age,n.record.drop.strength),l++):e.impacts.value[t].set(0,0,0,0)}n.userData.time=r,n.userData.activeDrops=c,n.userData.activeRipples=l,n.userData.orbBottom=o,n.userData.stemTop=s}return F(W.initialTime),{root:n,update:F,dispose(){P||(P=!0,T.dispose(),f.dispose(),g.dispose(),x.dispose(),o.dispose(),c.dispose(),n.removeFromParent(),n.clear())}}}function $e(){let e=W.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=W.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=W.jet.emitterHeight-K.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function et(e,t,n){return n.set(e.vx*t,W.jet.emitterHeight+e.vy*t-.5*W.drops.gravity*t*t,e.vz*t)}function tt(e,t=`legacy`){if(t===`lively`)try{return Qe(e,$e())}catch(e){console.warn(`Orb detail unavailable; original water effects retained.`,e)}let n=new i;n.name=`fountain-effects`;let r=K.fountain;n.position.set(...r.position),n.rotation.y=r.rotationY;let a=$e();n.userData.dropParameters=a;let o=Oe(e,`jet`),c=r.baseHeight+r.pedestalFootHeight+r.pedestalHeight+r.pedestalCapHeight,u=W.jet.emitterHeight-c,d=new m(W.jet.stemRadius,W.jet.stemRadius,u,8),f=new j(1,8,5),h=new ee(1,0),g=new p(d,o);g.name=`fountain-water-column`,g.position.y=c+u/2,g.receiveShadow=!0;let _=new p(f,o);_.name=`fountain-water-crown`,_.position.y=W.jet.emitterHeight,_.receiveShadow=!0;let y=new I(h,o,a.length);y.name=`fountain-water-drops`,y.receiveShadow=!0,y.boundingBox=new M(new l(-1.4,.3,-1.4),new l(1.4,1.45,1.4)),y.boundingSphere=y.boundingBox.getBoundingSphere(new b),n.add(g,_,y),n.visible=W.enabled;let x=new l,S=new l,C=new s,w=new v,T=new s,E=a.map(e=>({drop:e,age:0})),D=(e,t)=>e.age-t.age,O=(e,t)=>(e%t+t)%t;function k(t){e.time.value=t;let r=0;for(let e of a){let n=O(t-e.phase,W.drops.period);if(n>=e.impactTime)continue;et(e,n,x);let i=Math.min(1,n/.07),a=Math.min(1,(e.impactTime-n)/.055),o=e.radius*Math.min(i,a);o<5e-4||(S.setScalar(o),C.compose(x,w,S),y.setMatrixAt(r++,C))}y.count=r;for(let e=r;e<a.length;e++)y.setMatrixAt(e,T);y.instanceMatrix.needsUpdate=!0;for(let e of E)e.age=O(t-e.drop.phase-e.drop.impactTime,W.drops.period);E.sort(D);let i=0;for(let t=0;t<e.impacts.value.length;t++){let n=E[t];n.age<W.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),i++):e.impacts.value[t].set(0,0,0,0)}let o=W.jet.pulse,s=W.jet.radius;_.scale.set(s*(1+o*Math.sin(t*2.1)),s*.9*(1+o*Math.sin(t*2.8)),s*(1+o*Math.cos(t*2.1))),g.scale.set(1+o*Math.sin(t*2.1),1,1+o*Math.sin(t*2.1)),n.userData.time=t,n.userData.activeDrops=r,n.userData.activeRipples=i}k(W.initialTime);let A=!1;return{root:n,update:k,dispose(){A||(A=!0,y.dispose(),d.dispose(),f.dispose(),h.dispose(),o.dispose(),n.removeFromParent(),n.clear())}}}function nt(){let e=U.petals,n=U.seed+1;function r(){n+=1831565813;let e=Math.imul(n^n>>>15,1|n);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let i=Array.from({length:e.capacity},(t,n)=>{let i=0,a=0,o=!1;for(let t=0;t<1e3;t++){let t=H.flowers.clusters[Math.floor(r()*H.flowers.clusters.length)],n=r()*Math.PI*2,s=r()*t.radius;if(i=t.center[0]+Math.cos(n)*s,a=t.center[1]+Math.sin(n)*s,Ie(i,a,e.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:i,z:a,phase:n*e.period/e.capacity,rotation:r()*Math.PI*2,size:.055+r()*.02}}),a=new O;a.setAttribute(`position`,new t([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),a.computeVertexNormals();let o=new f({color:R.flowerLight,side:2,toneMapped:!1});o.name=`courtyard-floating-petal`;let c=new I(a,o,e.capacity);c.name=`courtyard-floating-petals`,c.castShadow=!1;let u=new M;for(let t of i)u.expandByPoint(new l(t.x-e.drift,e.minHeight,t.z-e.drift)),u.expandByPoint(new l(t.x+e.drift,e.maxHeight,t.z+e.drift));u.expandByScalar(.05),c.boundingBox=u,c.boundingSphere=u.getBoundingSphere(new b),c.userData.parameters=i;let d=new s,p=new l,m=new l,h=new v,g=new s,_=new l(.25,1,.15).normalize(),y=!1;return{mesh:c,update(t){let n=0;for(let r of i){let i=((t-r.phase)%e.period+e.period)%e.period;if(i>=e.lifetime)continue;let a=i/e.lifetime,o=Math.min(1,i/.6,(e.lifetime-i)/.7);p.set(r.x+Math.sin(i*.6+r.rotation)*e.drift,e.maxHeight+(e.minHeight-e.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*e.drift),h.setFromAxisAngle(_,r.rotation+i*.25),m.setScalar(r.size*o),d.compose(p,h,m),c.setMatrixAt(n++,d)}c.count=n;for(let t=n;t<e.capacity;t++)c.setMatrixAt(t,g);c.instanceMatrix.needsUpdate=!0},dispose(){y||(y=!0,c.dispose(),a.dispose(),o.dispose(),c.removeFromParent())}}}var Z={flowSpeed:.035,waveSpeed:.36,waveStrength:.15,rippleStrength:.42,foamWidth:[.015,.04],colors:{shallow:`#B4DAD9`,base:`#BED4DF`,middle:`#95BECF`,deep:`#245B80`,shade:`#7FA3BF`,white:`#F2FAFC`,stoneTop:`#F0E5C1`,stoneSide:`#C7CCB6`,stoneShade:`#7095A1`,wetStone:`#557D81`,weathering:`#A3B592`}};function rt(){let e=Ee({top:Z.colors.stoneTop,side:Z.colors.stoneSide,shade:Z.colors.stoneShade});e.name=`courtyard-pool-stone`,e.customProgramCacheKey=()=>`courtyard-pool-stone-v1`;let t=e.onBeforeCompile.bind(e);return e.onBeforeCompile=(e,n)=>{t(e,n);let r=K.fountain;Object.assign(e.uniforms,{uPoolStoneOrigin:{value:new w(r.position[0],r.position[2],Math.cos(r.rotationY),Math.sin(r.rotationY))},uPoolStoneLevels:{value:new w(r.position[1],r.waterHeight,r.baseHeight,r.innerRadius)},uPoolStoneWet:{value:new y(Z.colors.wetStone)},uPoolStoneOld:{value:new y(Z.colors.weathering)}});let i=`outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;`;if(!e.fragmentShader.includes(i))throw Error(`Pool stone extension anchor changed.`);e.fragmentShader=e.fragmentShader.replace(`void main() {`,`
      uniform vec4 uPoolStoneOrigin; uniform vec4 uPoolStoneLevels;
      uniform vec3 uPoolStoneWet; uniform vec3 uPoolStoneOld;
    
void main() {`).replace(i,`${i}\n
      vec2 poolDelta = vArtWorldPosition.xz - uPoolStoneOrigin.xy;
      vec2 poolP = vec2(uPoolStoneOrigin.z * poolDelta.x - uPoolStoneOrigin.w * poolDelta.y,
                       uPoolStoneOrigin.w * poolDelta.x + uPoolStoneOrigin.z * poolDelta.y);
      vec2 poolN = vec2(uPoolStoneOrigin.z * worldNormal.x - uPoolStoneOrigin.w * worldNormal.z,
                       uPoolStoneOrigin.w * worldNormal.x + uPoolStoneOrigin.z * worldNormal.z);
      float poolY = vArtWorldPosition.y - uPoolStoneLevels.x;
      float side = 1.0 - smoothstep(.35, .85, worldNormal.y);
      float innerFace = 1.0 - smoothstep(-.08, .05, dot(poolN, poolP));
      float pedestal = 1.0 - smoothstep(.44, .58, max(abs(poolP.x), abs(poolP.y)));
      float wetNoise = artNoise(poolP * 13.0 + vec2(5.4, 8.1));
      float wetLine = 1.0 - smoothstep(uPoolStoneLevels.y + .018, uPoolStoneLevels.y + .065 + wetNoise * .025, poolY);
      float wet = wetLine * side * max(innerFace, pedestal);
      outgoingLight = mix(outgoingLight, mix(outgoingLight * .73, uPoolStoneWet, .22), wet * .72);
      float contact = (1.0 - smoothstep(.02, .075, poolY)) * side;
      outgoingLight = mix(outgoingLight, uPoolStoneWet * .78, contact * .30);
      float capStep = (1.0 - smoothstep(.004, .018, abs(poolY - .44))) * side;
      outgoingLight *= 1.0 - capStep * .10;
      float chips = max(1.0 - smoothstep(.08, .28, length(poolP - vec2(.935, -2.259))),
                        1.0 - smoothstep(.08, .28, length(poolP + vec2(.935, -2.259))));
      float weather = chips * smoothstep(.48, .72, wetNoise) * smoothstep(.48, .56, poolY);
      outgoingLight = mix(outgoingLight, uPoolStoneOld, weather * .35);
    `)},e}function it(e){let t=ye(`water`);t.name=`courtyard-water-refined-surface`,t.userData.waterKind=`refined-surface`,t.customProgramCacheKey=()=>`courtyard-water-refined-surface-v1`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r);let i=K.fountain;Object.assign(t.uniforms,{uPoolTime:e.time,uPoolImpacts:e.impacts,uPoolOrigin:{value:new w(i.position[0],i.position[2],Math.cos(i.rotationY),Math.sin(i.rotationY))},uPoolMotion:{value:new w(Z.flowSpeed,Z.waveSpeed,Z.waveStrength,Z.rippleStrength)},uPoolBoundary:{value:new w(i.innerRadius*Math.cos(Math.PI/8),...Z.foamWidth,W.ripples.lifetime)},uPoolShallow:{value:new y(Z.colors.shallow)},uPoolBase:{value:new y(Z.colors.base)},uPoolMiddle:{value:new y(Z.colors.middle)},uPoolDeep:{value:new y(Z.colors.deep)},uPoolShade:{value:new y(Z.colors.shade)},uPoolWhite:{value:new y(Z.colors.white)}});let a=`
      uniform float uPoolTime;
      uniform vec4 uPoolImpacts[${W.ripples.capacity}];
      uniform vec4 uPoolOrigin; uniform vec4 uPoolMotion; uniform vec4 uPoolBoundary;
      uniform vec3 uPoolShallow; uniform vec3 uPoolBase; uniform vec3 uPoolMiddle;
      uniform vec3 uPoolDeep; uniform vec3 uPoolShade; uniform vec3 uPoolWhite;
    `,o=`
      vec2 delta = vArtWorldPosition.xz - uPoolOrigin.xy;
      vec2 p = vec2(uPoolOrigin.z * delta.x - uPoolOrigin.w * delta.y,
                    uPoolOrigin.w * delta.x + uPoolOrigin.z * delta.y);
      float t = uPoolTime;
      vec2 drift = vec2(t, -t * .25) * uPoolMotion.x;
      float broad = artNoise(p * vec2(2.2, 1.6) + drift * .5 + vec2(3.7, 6.1));
      float grain = artNoise(p * 18.0 + drift);
      vec2 q = p + vec2((broad - .5) * .20, (artNoise(p * 2.8 + vec2(8.4, 1.7) - drift) - .5) * .18) + drift * .65;
      vec2 leftShape = mat2(.96, -.28, .28, .96) * (q - vec2(-1.3, -.25));
      float leftReflection = length(leftShape / vec2(.36, 1.62));
      vec2 farShape = q - vec2(.30, -1.68);
      farShape.y += sin(farShape.x * 2.0) * .10;
      float farReflection = length(farShape / vec2(1.42, .31));
      vec2 nearShape = mat2(.91, .41, -.41, .91) * (q - vec2(1.12, .95));
      float nearReflection = length(nearShape / vec2(.24, .64));
      float silhouette = min(min(leftReflection, farReflection), nearReflection);
      silhouette += (broad - .5) * .70 + (grain - .5) * .12;
      float aa = clamp(max(fwidth(p.x), fwidth(p.y)), .003, .12);
      float detail = 1.0 - smoothstep(.035, .095, aa);
      float reflection = 1.0 - smoothstep(.93 - aa, 1.04 + aa, silhouette);
      float centerDistance = length(p);
      reflection *= smoothstep(.55, .85, centerDistance);

      float shoreDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + .5) * PI / 4.0;
        shoreDistance = min(shoreDistance, uPoolBoundary.x - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float shelf = smoothstep(.025, .18, shoreDistance);
      float depth = smoothstep(.28, 1.25, shoreDistance) * .26;
      vec3 clearWater = mix(uPoolShallow, uPoolBase, shelf);
      clearWater = mix(clearWater, uPoolMiddle, depth);
      vec3 litWater = mix(clearWater, uPoolDeep, reflection * .96);

      float wave = smoothstep(.955, .995, sin(centerDistance * 12.0 - t * uPoolMotion.y * 12.0 + broad));
      wave *= smoothstep(.65, .9, centerDistance) * (1.0 - smoothstep(1.5, 1.95, centerDistance));
      wave *= smoothstep(.52, .76, artNoise(p * 7.5 + drift)) * uPoolMotion.z;
      float glint = smoothstep(.78, .94, artNoise(p * 7.0 - drift))
        * smoothstep(.90, .99, sin(p.x * 11.0 + p.y * 6.0 - t * .72 + broad * 3.0)) * .64;
      float foam = (1.0 - smoothstep(uPoolBoundary.y, uPoolBoundary.z + aa * .35, shoreDistance))
        * smoothstep(.71, .88, artNoise(p * 12.0 + drift)) * .48;
      float impacts = 0.0;
      for (int i = 0; i < ${W.ripples.capacity}; i++) {
        vec4 event = uPoolImpacts[i];
        float radius = .025 + event.z * ${W.ripples.speed.toFixed(2)};
        float distanceToRing = abs(length(p - event.xy) - radius);
        float ring = 1.0 - smoothstep(.008, .018 + aa * .3, distanceToRing);
        float ageFade = pow(clamp(1.0 - event.z / uPoolBoundary.w, 0.0, 1.0), 2.0);
        float broken = smoothstep(.22, .47, artNoise(p * 9.0 + vec2(float(i) * 3.1, 5.0)));
        impacts = max(impacts, ring * ageFade * event.w * broken * uPoolMotion.w);
      }
      float white = max(max(wave, glint) * mix(.25, 1.0, detail), max(foam, impacts));
      litWater = mix(litWater, uPoolWhite, white);
      vec3 shadedWater = mix(uPoolShade, uPoolDeep * .84, reflection * .78);
      shadedWater = mix(shadedWater, uPoolWhite, white * .13);
      outgoingLight = mix(shadedWater, litWater, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Pool surface extension anchor changed.`);t.fragmentShader=t.fragmentShader.replace(`void main() {`,`${a}\nvoid main() {`).replace(s,o)},t}function at(e,t){let n=e.getObjectByName(`fountain`),r=n?.getObjectByName(`fountain-water`),i=[];if(n?.traverse(e=>{e instanceof p&&/^fountain-(base|rim-wall|coping-\d|pedestal(-foot|-cap)?)$/.test(e.name)&&i.push(e)}),!(r instanceof p)||i.length!==13)throw Error(`Pool finish requires the complete original fountain.`);let a=it(t),o=rt(),s=new Map;for(let e of[...i,r])s.set(e,e.material),e.material=e===r?a:o;let c=!1;return{metadata:{bindings:[...s.keys()].map(e=>({object:e.name,material:e.material.name})),newGeometries:0,newTextures:0,extraPasses:0},dispose(){if(!c){c=!0;for(let[e,t]of s)e.material=t;s.clear(),a.dispose(),o.dispose()}}}}var Q={period:32,speed:.22,softness:[.46,1.3],unionSoftness:.24,patches:[{along:-3,across:-1.4,radius:[4.6,3.3],density:1},{along:12,across:4.6,radius:[5.6,3.7],density:.88}],response:{ground:.18,stone:.14,foliage:.13,flower:.1,water:.075,orb:.05,jet:.045}},ot=B.sun.position,st=[ot[0]/ot[1],ot[2]/ot[1]],ct=he,lt=Q.period/Q.speed;function ut(e){return(e*Q.speed%Q.period+Q.period)%Q.period}function dt(e,t){let n=t,r={enabled:e,active:{value:+!!e},drift:{value:ut(t)},failures:[],update(t){e&&t!==n&&(n=t,r.drift.value=ut(t))},snapshot(){return{enabled:e,active:r.active.value,time:n,drift:r.drift.value,repeatSeconds:lt,failures:[...r.failures]}}};return r}var $=e=>e.toFixed(10),ft=e=>`vec2(${e.map($).join(`,`)})`,pt=`
  uniform float uCloudDrift;
  uniform float uCloudActive;
  float cloudSoftMin(float a, float b) {
    float h = max(${$(Q.unionSoftness)} - abs(a - b), 0.0) / ${$(Q.unionSoftness)};
    return min(a, b) - h * h * ${$(Q.unionSoftness*.25)};
  }
  float cloudPatch(vec2 point, vec2 center, vec2 radius) {
    vec2 q = point - center;
    q.x -= ${$(Q.period)} * floor(q.x / ${$(Q.period)} + .5);
    q /= radius;
    // Evaluate derivatives before the coherent empty-space branch. The cloud
    // is already fully clear outside these bounds, including the wrap seam.
    float aa = min(max(fwidth(q.x), fwidth(q.y)) * .75, .10);
    if (abs(q.x) > 1.8 || abs(q.y) > 1.6) return 0.0;
    vec2 b = (q - vec2(.48, -.16)) * vec2(1.3, 1.18);
    vec2 c = (q + vec2(.44, -.22)) * vec2(1.15, 1.38);
    float d = cloudSoftMin(cloudSoftMin(dot(q, q), dot(b, b)), dot(c, c));
    return 1.0 - smoothstep(${$(Q.softness[0])} - aa, ${$(Q.softness[1])} + aa, d);
  }
  float cloudCoverage(vec3 world) {
    vec2 projected = world.xz - world.y * ${ft(st)};
    const vec2 direction = ${ft(ct)};
    vec2 point = vec2(dot(projected, direction) - uCloudDrift,
                      dot(projected, vec2(-direction.y, direction.x)));
    ${Q.patches.map((e,t)=>`float c${t} = cloudPatch(point, ${ft([e.along,e.across])}, ${ft(e.radius)}) * ${$(e.density)};`).join(`
`)}
    return 1.0 - (1.0 - c0) * (1.0 - c1);
  }
`;function mt(e,t,n,r){let i=`#include <opaque_fragment>`;if(!e.fragmentShader.includes(i)||!e.fragmentShader.includes(`void main() {`)||!e.vertexShader.includes(`vArtWorldPosition`))throw Error(`Cloud receiver shader anchor unavailable`);let a=t===`ground`?`mix(.08, 1.0, 1.0 - occlusion)`:t===`foliage`?`mix(.10, 1.0, 1.0 - plantOcclusion)`:t===`flower`?`mix(.10, 1.0, 1.0 - flowerOcclusion)`:`mix(.12, 1.0, cloudSceneShadow) * mix(.10, 1.0, smoothstep(.015, .32, cloudLuminance))`,o=t===`water`?` * mix(1.0, .30, smoothstep(.50, .90, cloudLuminance))`:``,s=`
    // CLOUD_SHADOW_FINISH: shared world field after the original material finish.
    float cloudLuminance = dot(outgoingLight, vec3(.2126, .7152, .0722));
    float cloudMask = cloudCoverage(vArtWorldPosition);
    float cloudAmount = cloudMask * ${$(n)} * (${a})${o} * uCloudActive;
    outgoingLight *= vec3(1.0) - cloudAmount * vec3(1.0, .96, .85);
    ${i}
  `,c=e.fragmentShader.replaceAll(`getShadowMask()`,`cloudSceneShadow`).replace(`void main() {`,`void main() {
float cloudSceneShadow = getShadowMask();`).replace(`#include <common>`,`#include <common>\n${pt}`).replace(i,s);e.uniforms.uCloudDrift=r.drift,e.uniforms.uCloudActive=r.active,e.fragmentShader=c}function ht(e){let t=new Map,n=!1;return{bind(r){!n&&e.enabled&&r.traverse(n=>{if(n instanceof p)for(let r of Array.isArray(n.material)?n.material:[n.material]){let n=r.userData.artSurface;if(!n||!(n in Q.response)||t.has(r))continue;let i=r.name===`courtyard-living-orb`?Q.response.orb:r.userData.waterKind===`jet`?Q.response.jet:Q.response[n],a=r.onBeforeCompile,o=r.customProgramCacheKey;t.set(r,{compile:a,key:o,data:r.userData.cloudShadow}),r.customProgramCacheKey=()=>`${o.call(r)}-cloud-shadow-v2-${i}`,r.onBeforeCompile=(t,o)=>{if(a.call(r,t,o),e.active.value)try{mt(t,n,i,e)}catch(t){e.active.value=0,e.failures.push(`${r.name}: ${String(t)}`),console.warn(`Cloud shade unavailable; original surface lighting retained.`,t)}},r.userData.cloudShadow={surface:n,strength:i}}})},get metadata(){return{...e.snapshot(),materials:[...t.keys()].map(e=>({name:e.name,...e.userData.cloudShadow})),newGeometries:0,newTextures:0,extraPasses:0,extraDrawCalls:0}},dispose(){if(!n){n=!0;for(let[e,n]of t)e.onBeforeCompile=n.compile,e.customProgramCacheKey=n.key,n.data===void 0?delete e.userData.cloudShadow:e.userData.cloudShadow=n.data;t.clear()}}}}var gt={routes:[{center:[-.6,1.3],radii:[7.2,5.5],height:4.45,rotation:.05,period:48,phase:.14,direction:1,span:.34,flapCycle:5.2,flapDuration:1.4,flapRate:1.7},{center:[.4,.7],radii:[6.1,6.4],height:5.1,rotation:-.65,period:54,phase:.55,direction:-1,span:.32,flapCycle:5.4,flapDuration:1.6,flapRate:1.9},{center:[-.4,1.1],radii:[7.8,4.9],height:5.75,rotation:.35,period:61,phase:.81,direction:1,span:.33,flapCycle:4.9,flapDuration:1.3,flapRate:1.6}],colors:{warm:`#F3EAC4`,light:`#F8FCED`,cool:`#7095A1`,tip:`#405B55`,beak:`#DCCB9D`},bodyRadius:.69,clearance:.25,desktopMargin:20,mobileMargin:14,fadePixels:26,minimumAlpha:.015},_t=Math.PI*2,vt=(e,t)=>(e%t+t)%t,yt=e=>{let t=Math.min(1,Math.max(0,e));return t*t*t*(t*(t*6-15)+10)};function bt(){return{position:new l,tangent:new l,rotation:new v,euler:new r(0,0,0,`YXZ`),leftWing:0,rightWing:0,flap:0,bank:0,speed:0,scale:1,phase:0}}function xt(e,t,n){let r=gt.routes[t],i=vt(e/r.period*r.direction+r.phase,1),a=_t*i,o=_t/r.period*r.direction,s=Math.cos(r.rotation),c=Math.sin(r.rotation),l=r.radii[0]*Math.cos(a)+.35*Math.sin(2*a),u=r.radii[1]*Math.sin(a),d=(-r.radii[0]*Math.sin(a)+.7*Math.cos(2*a))*o,f=r.radii[1]*Math.cos(a)*o,p=vt(e+t*1.37,r.flapCycle),m=yt(p/.22)*(1-yt((p-r.flapDuration+.28)/.28)),h=_t*r.flapRate*e+t*1.9,g=.08+m*(.54*Math.sin(h)-.04);n.position.set(r.center[0]+s*l-c*u,r.height+.055*Math.sin(2*a)+.016*m*Math.sin(h*2),r.center[1]+c*l+s*u),n.tangent.set(s*d-c*f,.11*o*Math.cos(2*a),c*d+s*f),n.speed=n.tangent.length(),n.tangent.normalize();let _=Math.atan2(n.tangent.x,n.tangent.z),v=-Math.atan2(n.tangent.y,Math.hypot(n.tangent.x,n.tangent.z)),y=-.18*r.direction*(.75+.25*Math.cos(2*a));return n.euler.set(v,_,y,`YXZ`),n.rotation.setFromEuler(n.euler),n.leftWing=g,n.rightWing=-g,n.flap=m,n.bank=y,n.scale=r.span,n.phase=i,n}function St(e){let n=[],r=[],i=[],a=0,o=Object.fromEntries(Object.entries(gt.colors).map(([e,t])=>[e,new y(t)])),s=new l,c=new l,u=new l;function d(e,t,l,d){s.set(t[0]-e[0],t[1]-e[1],t[2]-e[2]),c.set(l[0]-e[0],l[1]-e[1],l[2]-e[2]),u.crossVectors(s,c).normalize();let f=o[d??(u.y>.3?`light`:u.y<-.3?`cool`:`warm`)];for(let o of[e,t,l])n.push(...o),r.push(f.r,f.g,f.b),i.push(a)}function f(e,t,n){let r=e.reduce((e,t)=>e.add(new l(...t)),new l).divideScalar(e.length);for(let[i,a,o]of t){let t=e[i],f=e[a],p=e[o];s.set(f[0]-t[0],f[1]-t[1],f[2]-t[2]),c.set(p[0]-t[0],p[1]-t[1],p[2]-t[2]),u.crossVectors(s,c),u.dot(new l(...t).sub(r))<0?d(t,p,f,n):d(t,f,p,n)}}function p(e,t,n,r=!1){let i=0;for(let t=0;t<e.length;t++){let n=e[t],r=e[(t+1)%e.length];i+=n[0]*r[1]-r[0]*n[1]}i>0&&e.reverse();let a=e.map(([e,r])=>[e,t+n/2,r]),o=e.map(([e,r])=>[e,t-n/2,r]);for(let t=1;t<e.length-1;t++)d(a[0],a[t],a[t+1],r&&t===2?`tip`:`warm`),d(o[0],o[t+1],o[t],`cool`);for(let t=0;t<e.length;t++){let n=(t+1)%e.length;d(a[t],o[t],o[n],`cool`),d(a[t],o[n],a[n],`cool`)}}if((e===`body`||e===`all`)&&(f([[0,.02,.245],[0,.02,-.225],[.085,.02,0],[-.085,.02,0],[0,.105,.005],[0,-.065,-.005]],[[4,0,2],[4,2,1],[4,1,3],[4,3,0],[5,2,0],[5,1,2],[5,3,1],[5,0,3]]),f([[0,.115,.28],[-.055,.025,.2],[.055,.025,.2],[0,.035,.37]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`warm`),f([[0,.04,.345],[-.025,.025,.32],[.025,.025,.32],[0,.025,.415]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`beak`),p([[0,-.17],[.075,-.34],[0,-.305],[-.075,-.34]],.015,.014)),e!==`body`)for(let t of e===`all`?[-1,1]:[e===`left`?-1:1])a=t,p([[0,.1],[t*.22,.035],[t*.425,-.095],[t*.3,-.19],[t*.05,-.08]],.025,.018,!0);let m=new O;return m.name=`courtyard-bird-${e}`,m.setAttribute(`position`,new t(n,3)),m.setAttribute(`color`,new t(r,3)),e===`all`&&m.setAttribute(`birdPart`,new t(i,1)),m.computeVertexNormals(),m.computeBoundingBox(),m.computeBoundingSphere(),m}function Ct(){let t=new e({color:16777215,vertexColors:!0,flatShading:!0,transparent:!0,depthTest:!0,depthWrite:!1,alphaTest:.012,toneMapped:!1});return t.name=`courtyard-birds`,t.customProgramCacheKey=()=>`courtyard-birds-hinge-v2`,t.color.multiplyScalar(1.5),t.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
attribute float birdAlpha; attribute float birdWing; attribute float birdPart; varying float vBirdAlpha;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vBirdAlpha = birdAlpha;
if (abs(birdPart) > 0.5) {
  float angle = -birdPart * birdWing;
  float c = cos(angle), s = sin(angle);
  transformed.xy = mat2(c, s, -s, c) * transformed.xy;
  transformed += vec3(birdPart * 0.075, 0.0, 0.015);
}`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
varying float vBirdAlpha;`).replace(`#include <alphatest_fragment>`,`diffuseColor.a *= vBirdAlpha;
#include <alphatest_fragment>`)},t}var wt=e=>{let t=Math.min(1,Math.max(0,e));return t*t*(3-2*t)};function Tt(e,t,n,r){let i=wt((Math.min(e-r.bounds.left,r.bounds.right-e,t-r.bounds.top,r.bounds.bottom-t)+n)/Math.max(1,n*2));for(let a of r.avoid){let o=Math.max(a.left-e,e-a.right,a.top-t,t-a.bottom)-n-r.margin;i*=wt(o/gt.fadePixels)}return i}function Et(){let e=new i;e.name=`courtyard-birds`;let t=St(`all`),n=Ct(),r=new u(new Float32Array(3),1).setUsage(D),a=new u(new Float32Array(3),1).setUsage(D);t.setAttribute(`birdAlpha`,r),t.setAttribute(`birdWing`,a);let o=new I(t,n,3);o.name=`courtyard-birds-complete`,o.castShadow=!1,o.receiveShadow=!1,o.instanceMatrix.setUsage(D),o.boundingBox=new M(new l(-11,3.8,-10),new l(11,6.2,11)),o.boundingSphere=o.boundingBox.getBoundingSphere(new b),e.add(o);let c=gt.routes.map(()=>bt()),d=c.map(()=>({x:0,y:0,radius:0,alpha:0})),f=new l,p=new l,m=new s,h=NaN,g=NaN,_=``,v=!1;return{root:e,metadata:{birds:3,newGeometries:1,newTextures:0,maximumColorDrawCalls:1,extraPasses:0,castsShadows:!1,trianglesPerBird:t.getAttribute(`position`).count/3},update(e){if(!(v||e===h)){h=e;for(let t=0;t<c.length;t++)xt(e,t,c[t])}},present(t,n){if(v||g===h&&_===n.key)return;g=h,_=n.key;let i=n.bounds.right-n.bounds.left,s=n.bounds.bottom-n.bounds.top,l=0;for(let e=0;e<c.length;e++){let u=c[e],h=d[e];f.copy(u.position).project(t),h.x=n.bounds.left+(f.x*.5+.5)*i,h.y=n.bounds.top+(.5-f.y*.5)*s,h.radius=u.scale*gt.bodyRadius*Math.abs(t.projectionMatrix.elements[5])*s*.5,h.alpha=f.z<-1||f.z>1?0:Tt(h.x,h.y,h.radius,n),h.alpha<gt.minimumAlpha||(m.compose(u.position,u.rotation,p.setScalar(u.scale)),o.setMatrixAt(l,m),r.setX(l,h.alpha),a.setX(l,u.leftWing),l++)}o.count=l,e.visible=l>0,l&&(o.instanceMatrix.needsUpdate=!0,r.needsUpdate=!0,a.needsUpdate=!0)},snapshot(){return{time:h,visible:o.count,poses:c.map((e,t)=>({id:t,position:e.position.toArray(),rotation:e.rotation.toArray(),leftWing:e.leftWing,rightWing:e.rightWing,flap:e.flap,bank:e.bank,scale:e.scale,speed:e.speed,phase:e.phase,screen:{...d[t]}}))}},dispose(){v||(v=!0,o.dispose(),t.dispose(),n.dispose(),e.removeFromParent(),e.clear())}}}function Dt(e={},t=`legacy`,n=`legacy`,r=!1,i=!1){let a=fe(e),o=dt(r&&a.options.enabled,a.time.value),s=ht(o),l=new _;l.background=new y(R.grassBase);let u=new g;u.position.set(...z.camera.position),u.lookAt(...z.camera.target),u.near=z.camera.near,u.far=z.camera.far;let d=new E(z.ground.size,z.ground.size),f=be(a),m=new p(d,f);m.name=`courtyard-ground`,m.rotation.x=-Math.PI/2,m.receiveShadow=!0,l.add(m);let h=De(),v=ke(h);l.add(v.root);let b;if(t===`refined`)try{b=at(l,h)}catch(e){console.warn(`Pool finish unavailable; original fountain retained.`,e)}let x=tt(h,n);l.add(x.root);let ee=new c(R.highlight,R.stoneShade,B.fill.intensity);ee.name=`courtyard-fill`;let S=new P(R.highlight,B.sun.intensity);S.name=`courtyard-sun`,S.position.set(...B.sun.position),S.castShadow=B.shadows.enabled;let C=B.shadows;S.shadow.mapSize.setScalar(C.mapSize),S.shadow.camera.left=-C.extent,S.shadow.camera.right=C.extent,S.shadow.camera.top=C.extent,S.shadow.camera.bottom=-C.extent,S.shadow.camera.near=C.near,S.shadow.camera.far=C.far,S.shadow.bias=C.bias,S.shadow.normalBias=C.normalBias,S.shadow.radius=C.radius,l.add(ee,S,S.target);let w=z.camera.viewHeight,T=1;function D(e){T=e;let t=w/2;u.left=-t*e,u.right=t*e,u.top=t,u.bottom=-t,u.updateProjectionMatrix()}D(1),u.updateMatrixWorld(!0);let O=Le(u,a);l.add(O.root);let k=a.options.enabled&&a.options.petals?nt():void 0;k&&(k.update(a.time.value),l.add(k.mesh)),s.bind(l);let A;if(i&&a.options.enabled)try{A=Et(),A.update(a.time.value),l.add(A.root)}catch(e){console.warn(`Birds unavailable; original courtyard retained.`,e)}let j=!1;return{scene:l,camera:u,setAspect:D,setViewHeight(e){if(!Number.isFinite(e)||e<=0)throw RangeError(`Camera view height must be positive.`);e!==w&&(w=e,D(T))},update(e){x.update(e),a.time.value=e,o.update(e),A?.update(e),k?.update(e)},waterState:h,fountainStyle:b?`refined`:t===`refined`?`fallback`:`legacy`,fountainMetadata:b?.metadata,orbStyle:x.root.userData.orbStyle??(n===`lively`?`fallback`:`legacy`),orbMetadata:x.root.userData.orbMetadata,environmentState:a,cloudShadows:s,birds:A,dispose(){j||(j=!0,s.dispose(),A?.dispose(),d.dispose(),f.dispose(),b?.dispose(),v.dispose(),O.dispose(),x.dispose(),k?.dispose(),S.shadow.dispose(),l.clear())}}}var Ot=[320,384,448],kt={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function At(e){let t=Number(e.get(`pixelSize`));return{resolution:Ot.some(e=>e===t)?t:kt.resolution,finish:e.get(`finish`)===`soft`?`soft`:kt.finish,storage:`auto`}}function jt(e,r){let i=r.storage!==`byte`&&e.extensions.has(`EXT_color_buffer_float`),s=new S(1,1,{type:i?o:F,minFilter:N,magFilter:N,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});s.texture.colorSpace=i?a:k,s.texture.name=`courtyard-pixel-scene`;let c=new O;c.setAttribute(`position`,new t([-1,-1,0,3,-1,0,-1,3,0],3)),c.setAttribute(`uv`,new t([0,0,2,0,0,2],2));let l=kt.finishes[r.finish],u=new T({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:s.texture},uSampleSize:{value:new n(1,1)},uLevels:{value:l.levels},uDither:{value:l.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),d=new _,f=new g(-1,1,1,-1,0,1),m=new p(c,u);m.frustumCulled=!1,d.add(m);let h=!1,v=0;function y(){s.dispose(),c.dispose(),u.dispose()}return{releaseGpuResources:y,resize(e,t){let n=Math.min(1,r.resolution/Math.max(e,t)),i=Math.max(1,Math.round(e*n)),a=Math.max(1,Math.round(t*n));(i!==s.width||a!==s.height)&&(s.setSize(i,a),u.uniforms.uSampleSize.value.set(i,a),v++)},render(t,n){e.setRenderTarget(s),e.render(t,n),e.setRenderTarget(null),e.render(d,f)},getInfo(){return{sampleWidth:s.width,sampleHeight:s.height,designResolution:r.resolution,finish:r.finish,storage:i?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:l.levels,dither:l.dither,allocations:v}},dispose(){h||(h=!0,y(),d.clear())}}}function Mt(e){let t=new Set,n=new Set,r=new Set;e.traverse(e=>{if(e instanceof p||e instanceof re){t.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])n.add(t)}e instanceof I&&e.dispose(),e instanceof P&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of t)e.dispose();for(let e of n){for(let t of Object.values(e))t instanceof x&&r.add(t);if(e instanceof T)for(let t of Object.values(e.uniforms)){let e=Array.isArray(t.value)?t.value:[t.value];for(let t of e)t instanceof x&&r.add(t)}e.dispose()}for(let e of r)e.dispose()}function Nt(e,t,r,i=At(new URLSearchParams),a){let o=new L({antialias:!1,alpha:!1});o.outputColorSpace=k,o.toneMapping=0,o.shadowMap.enabled=!0,o.shadowMap.type=1,o.shadowMap.autoUpdate=!1,o.shadowMap.needsUpdate=!0,o.info.autoReset=!1;let s=jt(o,i),c=new n,l=o.domElement;l.setAttribute(`role`,`img`),l.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(l);let u=t,d=!1,f=!1,p=!1,m=!1,h=!0,g,_,v,y=0,b=0,x=0,ee=0;function S(){v!==void 0&&cancelAnimationFrame(v),v=void 0,y=0}function C(){d||f||m||h||!g||v!==void 0||y===0||(v=requestAnimationFrame(e=>{v=void 0,y--,d||f||m||h||(g?.(e),C())}))}function w(){d||f||m||h||!g||(y=Math.max(y,2),C())}function T(){let e=!d&&!f&&!m;(!e||h)&&S(),o.setAnimationLoop(e&&h&&g?g:null),e&&!h&&w()}function E(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||d)return;let n=Math.min(window.devicePixelRatio||1,ue.maxDevicePixelRatio),i=Math.max(1,Math.floor(t.width)),a=Math.max(1,Math.floor(t.height));(i!==b||a!==x||n!==ee)&&(b=i,x=a,ee=n,o.setPixelRatio(n),o.setSize(i,a,!1),o.getDrawingBufferSize(c),s.resize(c.x,c.y)),l.dataset.renderMode=u;let f=s.getInfo();l.dataset.sampleWidth=String(u===`pixel`?f.sampleWidth:c.x),l.dataset.sampleHeight=String(u===`pixel`?f.sampleHeight:c.y),l.dataset.pixelProfile=String(f.designResolution),l.dataset.finish=f.finish,r(t.width/t.height),w()}function D(t){t.preventDefault(),f=!0,p=!0,e.dataset.renderState=`context-lost`,T(),s.releaseGpuResources(),_&&Mt(_),a?.(`context-lost`)}function O(){f=!1,b=0,o.shadowMap.needsUpdate=!0,a?.(`restored`),E(),T()}l.addEventListener(`webglcontextlost`,D),l.addEventListener(`webglcontextrestored`,O);let A=new ResizeObserver(E);A.observe(e),window.addEventListener(`resize`,E);let j;function M(){j?.removeEventListener(`change`,N),j=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),j.addEventListener(`change`,N)}function N(){M(),E()}return M(),E(),{canvas:l,setMode(e){u=e,E()},setAnimating(e){h=e,T()},setSuspended(e){m!==e&&(m=e,T())},renderOnce(){g?.(performance.now()),w()},getStats(){return{geometries:o.info.memory.geometries,textures:o.info.memory.textures,programs:o.info.programs?.length??0,calls:o.info.render.calls,triangles:o.info.render.triangles,mode:u,outputWidth:o.domElement.width,outputHeight:o.domElement.height,pixel:u===`pixel`?s.getInfo():null}},start(t,n,r){_=t,g=i=>{d||f||m||(r?.(i),o.info.reset(),u===`pixel`?s.render(t,n):(o.setRenderTarget(null),o.render(t,n)),e.dataset.renderState=`ready`,p&&(p=!1,a?.(`ready`),w()))},T()},dispose(){d||(d=!0,S(),A.disconnect(),window.removeEventListener(`resize`,E),j.removeEventListener(`change`,N),l.removeEventListener(`webglcontextlost`,D),l.removeEventListener(`webglcontextrestored`,O),o.setAnimationLoop(null),g=void 0,_=void 0,s.dispose(),o.dispose(),!o.getContext().isContextLost()&&o.extensions.has(`WEBGL_lose_context`)&&o.forceContextLoss(),l.remove())}}}function Pt(e,t=W.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function Ft(e,t,n=!1,r={}){let i=window.matchMedia(`(prefers-reduced-motion: reduce)`),a=Pt(t),o=n||r.retainReducedPause&&i.matches?!0:null,s=!1;function c(){return{playing:!document.hidden&&!(o??i.matches),hidden:document.hidden,reducedMotion:i.matches}}function l(){s||(a.resetTimestamp(),e(c()))}function u(){i.matches&&o!==!0&&(o=r.retainReducedPause?!0:null),l()}return document.addEventListener(`visibilitychange`,l),i.addEventListener(`change`,u),{get state(){return c()},get time(){return a.time},advance(e){return a.tick(e,c().playing)},resetTimestamp:a.resetTimestamp,toggle(){o=!(o??i.matches),l()},dispose(){s||(s=!0,document.removeEventListener(`visibilitychange`,l),i.removeEventListener(`change`,u))}}}export{gt as a,de as c,le as d,ce as f,ie as g,ae as h,Dt as i,ue as l,oe as m,Nt as n,Ee as o,se as p,At as r,W as s,Ft as t,z as u};