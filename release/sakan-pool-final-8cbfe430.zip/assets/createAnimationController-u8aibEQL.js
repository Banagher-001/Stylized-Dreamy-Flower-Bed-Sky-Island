import{A as e,An as t,E as n,F as r,G as i,I as a,J as o,L as s,Mn as c,Pn as l,Qt as u,R as d,Sn as f,T as p,X as m,Y as h,Z as g,_,_n as v,a as y,at as b,cn as x,dn as S,dt as C,et as w,f as T,fn as E,ft as D,gn as O,hn as k,jn as A,k as ee,mn as j,nt as te,o as M,ot as ne,q as re,r as ie,st as ae,u as oe,un as se,ut as ce,w as le,z as ue}from"./three-core-DkJsz2fd.js";import{t as de}from"./three-renderer-DxSVbYM0.js";var N={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},fe={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`};N.grassBase,N.stoneLight,N.stoneShade,N.treeShadow,N.waterBase,N.flower;var pe=new URL(`courtyard-motion-7fR7fsF8.mp4`,import.meta.url).href,me=new URL(`courtyard-keyframe-00-Dnvt_afN.png`,import.meta.url).href,he=new URL(`courtyard-keyframe-03-BpIvPl5V.png`,import.meta.url).href,ge=new URL(`signal-garden-CbiDrnMk.webp`,import.meta.url).href,_e=new URL(`liquid-form-Yl5oqdSL.webp`,import.meta.url).href,P={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},ve={defaultMode:`pixel`,maxDevicePixelRatio:2},F={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},I={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},wall:{bodyBlocks:3,capBlocks:2}},L={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25],pavingReserve:{x:[3.905,6.755],z:[.805,1.955]}},grass:{count:240,pavingTufts:[{center:[-.773,-.078],height:.076},{center:[-.745075,.004656],height:.064},{center:[-.375382,.001139],height:.07},{center:[-.002447,-.311354],height:.061},{center:[.734412,-.003957],height:.068}],minHeight:.065,maxHeight:.14,clearance:.06,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},R={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function ye(e){return{enabled:e.get(`env`)!==`off`&&R.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||R.petals.enabled}}var z={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function be(e={}){let t={...ye(new URLSearchParams),...e};return{options:t,time:{value:z.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function xe(e,t){let n=Math.sin(e*12.9898+t*78.233+R.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var Se=Math.hypot(...R.wind.direction),Ce=[R.wind.direction[0]/Se,R.wind.direction[1]/Se],B=e=>e.toFixed(10),we=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${Ce.map(B).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${B(R.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${B(R.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${B(R.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,Te=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${B(R.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${B(R.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${B(R.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function Ee(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${we}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${Te}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${B(R.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${B(R.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function De(e,t,n={}){let r=new w,i=e===`foliage`||e===`flower`;r.name=`courtyard-${e}`,r.userData.artSurface=e;let a=t?.options.enabled&&(i||e===`ground`);return r.customProgramCacheKey=()=>`courtyard-art-${e}-v3${a?`-environment-v1`:``}`,r.onBeforeCompile=r=>{let o=F.treeShadows,s=L.ground,l=L.treeDetail;Object.assign(r.uniforms,{uArtSunAmount:{value:F.sun.intensity},uArtFillAmount:{value:F.fill.intensity},uArtStoneVariation:{value:I.colorVariation},uArtGrass:{value:new T(N.grassBase)},uArtGrassLight:{value:new T(N.grassLight)},uArtGrassDark:{value:new T(N.grassDark)},uArtGrassShadow:{value:new T(N.treeShadow)},uArtStoneTop:{value:new T(n.top??N.stoneLight)},uArtStoneSide:{value:new T(n.side??N.stoneSide)},uArtStoneShade:{value:new T(n.shade??N.stoneShade)},uArtWater:{value:new T(N.waterBase)},uArtWaterShade:{value:new T(N.waterShade)},uArtPlantShade:{value:new T(N.plantShade)},uArtFlowerShade:{value:new T(N.flowerShade)},uArtFlowerCenter:{value:new T(N.flowerCenter)},uArtGroundEnabled:{value:+!!s.enabled},uArtGroundScales:{value:new c(s.macroScale,s.macroStrength,s.detailScale,s.detailStrength)},uArtGroundDensity:{value:s.detailDensity},uArtQuietRegion:{value:new c(s.quietCenter[0],s.quietCenter[1],s.quietRadius[0],s.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!l.enabled},uArtTreeDetail:{value:new c(l.branchScale,l.leafScale,l.edgeBreakup,l.gapStrength)},uArtTreesEnabled:{value:+!!o.enabled},uArtTreeNoiseScale:{value:o.edgeNoiseScale},uArtTreeNoiseAmount:{value:o.edgeNoiseAmount},uArtTreeSoftness:{value:o.edgeSoftness},uArtTreePatches:{value:o.patches.map(e=>new c(e.center[0],e.center[1],e.radius[0],e.radius[1]))},uArtTreeRotations:{value:o.patches.map(e=>e.rotation)}}),r.vertexShader=r.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${e===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${i?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${e===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${i?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let u=`
      varying vec3 vArtWorldPosition;
      ${e===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${i?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${o.patches.length}];
      uniform float uArtTreeRotations[${o.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${o.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;r.fragmentShader=r.fragmentShader.replace(`#include <common>`,`#include <common>\n${u}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
        #ifdef USE_COLOR
          outgoingLight *= diffuseColor.rgb;
        #endif
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[e]}\n#include <opaque_fragment>`),a&&Ee(r,i,t)},r}function Oe(e){return De(`ground`,e)}var V={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,stones:[{id:`A`,center:[-1.055,-.355],width:.34,depth:.33,rotationDegrees:12,cuts:[.073,.019,.053,.025],profile:{exposedHeight:.085,embeddedDepth:.014,bevel:.011,chipVertex:7,chipSize:.062}},{id:`B`,center:[-1.111,.205],width:.66,depth:.44,rotationDegrees:-7,cuts:[.025,.064,.036,.049],profile:{exposedHeight:.093,embeddedDepth:.016,bevel:.014,chipVertex:5,chipSize:.079}},{id:`C`,center:[-.465,-.275],width:.45,depth:.33,rotationDegrees:-9,cuts:[.058,.021,.047,.032],profile:{exposedHeight:.078,embeddedDepth:.017,bevel:.009,chipVertex:0,chipSize:.035}},{id:`D`,center:[-.381,.305],width:.59,depth:.43,rotationDegrees:6,cuts:[.033,.055,.023,.071],profile:{exposedHeight:.096,embeddedDepth:.015,bevel:.013,chipVertex:5,chipSize:.044}},{id:`E`,center:[.207,-.014],width:.31,depth:.69,rotationDegrees:-16,cuts:[.028,.068,.015,.053],profile:{exposedHeight:.088,embeddedDepth:.014,bevel:.01,chipVertex:1,chipSize:.061}},{id:`F`,center:[.765,-.259],width:.51,depth:.32,rotationDegrees:10,cuts:[.066,.022,.055,.031],profile:{exposedHeight:.076,embeddedDepth:.018,bevel:.008,chipVertex:2,chipSize:.027}},{id:`G`,center:[.659,.279],width:.53,depth:.4,rotationDegrees:-9,cuts:[.019,.059,.041,.072],profile:{exposedHeight:.09,embeddedDepth:.015,bevel:.012,chipVertex:4,chipSize:.049}},{id:`H`,center:[1.237,.17],width:.43,depth:.41,rotationDegrees:8,cuts:[.053,.028,.073,.021],profile:{exposedHeight:.084,embeddedDepth:.015,bevel:.011,chipVertex:3,chipSize:.075}}]}},ke={base:`#7C9955`,light:`#9AAE65`,edge:`#5C7746`},Ae={A:{anchor:[-.09,-.09],lobes:[{outline:[[-.041,.015],[-.035,-.009],[-.026,-.024],[-.012,-.021],[-.004,-.034],[.03,-.038],[.052,-.029],[.048,-.014],[.064,-.002],[.056,.015],[.032,.021],[.022,.036],[.002,.032],[-.008,.043],[-.031,.034]],peak:[.012,.005],rise:.016,rim:.0045},{outline:[[.049,.021],[.061,.005],[.076,.008],[.088,.014],[.084,.03],[.069,.033],[.053,.03]],peak:[.068,.019],rise:.011,rim:.004},{outline:[[.028,.04],[.038,.032],[.051,.033],[.054,.042],[.045,.046],[.032,.045]],peak:[.041,.039],rise:.009,rim:.003}]},C:{anchor:[-.09,-.095],lobes:[{outline:[[-.05,-.009],[-.039,-.024],[-.018,-.028],[-.004,-.018],[.015,-.032],[.035,-.025],[.044,-.009],[.039,.002],[.05,.012],[.035,.032],[.012,.027],[-.003,.017],[-.024,.031],[-.041,.023]],peak:[-.006,-.003],rise:.011,rim:.004},{outline:[[.027,-.023],[.039,-.03],[.05,-.024],[.059,-.013],[.057,-.002],[.044,.003],[.031,-.005]],peak:[.043,-.014],rise:.008,rim:.003}]},E:{anchor:[.054,-.26],lobes:[{outline:[[-.04,-.042],[-.022,-.049],[-.012,-.038],[.017,-.045],[.027,-.032],[.021,-.006],[.038,.009],[.029,.032],[.015,.043],[.017,.062],[0,.077],[-.018,.079],[-.03,.06],[-.026,.048],[-.031,.029],[-.049,.008],[-.048,-.013]],peak:[-.006,.014],rise:.015,rim:.0045},{outline:[[-.02,.084],[-.015,.066],[.008,.074],[.026,.089],[.031,.109],[.023,.122],[.004,.126],[-.014,.111],[-.016,.102]],peak:[.006,.101],rise:.01,rim:.0035},{outline:[[-.044,.022],[-.039,.012],[-.029,.011],[-.021,.021],[-.031,.038],[-.042,.035]],peak:[-.033,.024],rise:.009,rim:.003}]},F:{anchor:[.135,-.096],lobes:[{outline:[[-.045,-.013],[-.037,-.024],[-.014,-.027],[.004,-.017],[.022,-.028],[.039,-.016],[.048,-.004],[.039,.006],[.044,.019],[.026,.028],[.007,.021],[-.016,.025],[-.03,.014],[-.043,.008]],peak:[.001,-.001],rise:.0095,rim:.0035}]}},H=1e-7;function je(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<H*H)||t.push(n);return t}function Me(e,t,n){let r=[],i=[];for(let a of e){let e=[];for(let r=0;r<a.length;r++){let o=a[r],s=a[(r+1)%a.length],c=t.dot(o)-n,l=t.dot(s)-n;if(c<=H&&e.push(o),c<-1e-7&&l>H||c>H&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),i.push(t)}else Math.abs(c)<=H&&i.push(o)}let o=je(e);o.length>=3&&r.push(o)}let a=je(i);if(a.length>=3){let e=a.reduce((e,t)=>e.add(t),new A).divideScalar(a.length),n=Math.abs(t.y)<.9?new A(0,1,0):new A(1,0,0),i=t.clone().cross(n).normalize(),o=t.clone().cross(i).normalize();a.sort((t,n)=>{let r=t.clone().sub(e),a=n.clone().sub(e);return Math.atan2(r.dot(o),r.dot(i))-Math.atan2(a.dot(o),a.dot(i))}),r.push(a)}return r}function Ne(t,n,r=1){let i=t.getAttribute(`position`),a=Math.sin(n*12.9898+.73)*.65,o=new Float32Array(i.count);for(let e=0;e<i.count;e++)o[e]=(a+Math.sin(i.getX(e)*1.6+i.getZ(e)*2.3+n)*.25)*r;return t.setAttribute(`stoneTint`,new e(o,1)),t}function U(t,n,r){if(t.length<3||n<=0)throw Error(`Stone prism needs a polygon and positive height.`);let i=t.map(([e,t])=>[e,t]);i.reduce((e,t,n)=>{let r=i[(n+1)%i.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(i=i.reverse());let a=n/2,o=i.map(([e,t])=>new A(e,a,t)),s=i.map(([e,t])=>new A(e,-a,t)),c=[o,[...s].reverse()],l=[];for(let e=0;e<i.length;e++){let t=(e+1)%i.length,n=s[e],r=s[t];c.push([n,r,o[t],o[e]]);let a=r.clone().sub(n).cross(new A(0,1,0)).normalize();l.push({normal:a,distance:a.dot(n)})}let u=Math.min(r.bevel,n*.2);for(let e=0;e<l.length;e++){let t=l[e];for(let e of[-1,1]){let n=t.normal.clone().add(new A(0,e,0)),r=(t.distance+a-u)/n.length();c=Me(c,n.normalize(),r)}let n=l[(e+l.length-1)%l.length],i=n.normal.clone().add(t.normal),o=(n.distance+t.distance-r.cornerCut)/i.length();c=Me(c,i.normalize(),o)}if(r.chipSize&&r.chipSize>0){let e=(r.chipCorner??0)%l.length,t=l[(e+l.length-1)%l.length],n=l[e],i=t.normal.clone().add(n.normal).add(new A(0,1,0)),o=(t.distance+n.distance+a-r.chipSize)/i.length();c=Me(c,i.normalize(),o)}let d=[],f=[];for(let e of c){let t=e.reduce((e,t)=>e.add(t),new A).divideScalar(e.length),n=new A;for(let r=0;r<e.length;r++)n.add(e[r].clone().sub(t).cross(e[(r+1)%e.length].clone().sub(t)));if(!(n.lengthSq()<H*H)){n.normalize();for(let r=0;r<e.length;r++){let i=e[r],a=e[(r+1)%e.length];if(!(i.clone().sub(t).cross(a.clone().sub(t)).lengthSq()<H*H))for(let e of[t,i,a])d.push(e.x,e.y,e.z),f.push(n.x,n.y,n.z)}}}let p=new M;return p.setAttribute(`position`,new e(d,3)),p.setAttribute(`normal`,new e(f,3)),Ne(p,r.seed,r.tintStrength),p.computeBoundingBox(),p.computeBoundingSphere(),p.userData.stoneSolid=!0,p}function Pe(e,t,n,r){let i=e/2,a=n/2;return U([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}var Fe=new T(ke.base),Ie=new T(ke.light),Le=new T(ke.edge);function Re(t,n,r=`top`,i){let a=t.getAttribute(`position`),o=t.getAttribute(`normal`),[s,c]=n.anchor,l=new h;r===`front`&&l.makeRotationX(Math.PI/2),r===`right`&&l.makeRotationZ(-Math.PI/2);let d=new A(0,-1,0).transformDirection(l),f=r===`front`?`z`:r===`right`?`x`:`y`,p=i??(t.boundingBox?.max[f]??0)+1,m=new u(new A,d),g=new A,_=new A,v=new A,y=new A;function b([e,t]){m.origin.set(s+e,p,c+t).applyMatrix4(l);let n,r=0,i=1/0;for(let e=0;e<a.count;e+=3)g.fromBufferAttribute(a,e),_.fromBufferAttribute(a,e+1),v.fromBufferAttribute(a,e+2),m.intersectTriangle(g,_,v,!0,y)&&y.distanceToSquared(m.origin)<i&&(i=y.distanceToSquared(m.origin),(n??=new A).copy(y),r=e);return n?{point:n,normal:new A().fromBufferAttribute(o,r)}:void 0}let x=[],S=[];function C(e,t,n,r,i,a){x.push(e.x,e.y,e.z,t.x,t.y,t.z,n.x,n.y,n.z),S.push(r.r,r.g,r.b,i.r,i.g,i.b,a.r,a.g,a.b)}for(let e of n.lobes){let t=b(e.peak),n=[...e.outline].reverse().map(b);if(!t||n.some(e=>!e))continue;let r=n.map(e=>e.point),{normal:i}=t,a=i.dot(t.point);if(r.some(e=>Math.abs(i.dot(e)-a)>1e-5))continue;let o=t.point.clone().addScaledVector(i,-.002),s=t.point.clone().addScaledVector(i,e.rise),c=r.map(e=>e.clone().addScaledVector(i,-.002)),l=r.map((t,n)=>t.clone().addScaledVector(i,e.rim+n%3*.001)),u=r.map((e,t)=>Fe.clone().lerp(Ie,t%4*.1));for(let e=0;e<r.length;e++){let t=(e+1)%r.length;C(s,l[e],l[t],Ie,u[e],u[t]),C(o,c[t],c[e],Le,Le,Le),C(c[e],c[t],l[t],Le,Le,u[t]),C(c[e],l[t],l[e],Le,u[t],u[e])}}if(!x.length)return;let w=new M;return w.setAttribute(`position`,new e(x,3)),w.setAttribute(`color`,new e(S,3)),w.computeVertexNormals(),w.computeBoundingSphere(),Ne(w,19)}function ze(e){return De(`stone`,void 0,e)}function Be(){return{time:{value:z.initialTime},impacts:{value:Array.from({length:z.ripples.capacity},()=>new c(0,0,0,0))}}}function Ve(e=Be(),t=`surface`){let n=De(`water`);n.name=`courtyard-water-${t}`,n.flatShading=t===`jet`,n.userData.waterKind=t,n.customProgramCacheKey=()=>`courtyard-water-${t}-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=V.fountain;Object.assign(n.uniforms,{uWaterTime:e.time,uWaterImpacts:e.impacts,uWaterEnabled:{value:+!!z.enabled},uWaterBase:{value:new T(z.colors.base)},uWaterDeep:{value:new T(z.colors.deep)},uWaterShade:{value:new T(z.colors.shade)},uWaterWhite:{value:new T(z.colors.highlight)},uWaterJet:{value:new T(z.colors.jet)},uWaterOrigin:{value:new c(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uWaterSurface:{value:new c(z.surface.flowSpeed,z.surface.reflectionThreshold,z.surface.waveSpeed,z.surface.waveStrength)},uWaterRipple:{value:new c(z.ripples.lifetime,z.ripples.speed,z.ripples.strength,a.innerRadius*Math.cos(Math.PI/8))}});let o=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${z.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${z.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,l=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(l))throw Error(`Water shader extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(l,t===`surface`?s:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},n}var He=V.path,Ue=Math.cos(He.rotationY),We=Math.sin(He.rotationY);function Ge(e,t){return[He.position[0]+Ue*e+We*t,He.position[2]-We*e+Ue*t]}var Ke=He.stones.map(e=>{let t=e.width/2,n=e.depth/2,[r,i,a,o]=e.cuts,s=[[-t+r,-n],[t-i,-n],[t,-n+i],[t,n-a],[t-a,n],[-t+o,n],[-t,n-o],[-t,-n+r]],c=e.rotationDegrees*Math.PI/180,l=Math.cos(c),u=Math.sin(c),[d,f]=e.center,p=s.map(([e,t])=>Ge(d+l*e+u*t,f-u*e+l*t)),m=p.map(([e])=>e),h=p.map(([,e])=>e),g={minX:Math.min(...m),maxX:Math.max(...m),minZ:Math.min(...h),maxZ:Math.max(...h)};return{id:e.id,center:e.center,profile:e.profile,rotationY:c,outline:s,worldOutline:p,bounds:g}});function qe(e,t,n){let r=n**2;for(let{worldOutline:i,bounds:a}of Ke){if(e<a.minX-n||e>a.maxX+n||t<a.minZ-n||t>a.maxZ+n)continue;let o=!0;for(let n=0;n<i.length;n++){let[a,s]=i[n],[c,l]=i[(n+1)%i.length],u=c-a,d=l-s,f=e-a,p=t-s;u*p-d*f<0&&(o=!1);let m=(f*u+p*d)/(u*u+d*d),h=Math.max(0,Math.min(1,m));if((f-u*h)**2+(p-d*h)**2<=r)return!1}if(o)return!1}return!0}var Je={columnUpperLeft:{colors:{top:`#A7B8BE`,side:`#7895A2`,shade:`#3B5A6A`},base:[{range:[-.012,.125],size:[1.03,1.07],cuts:[.077,.054,.103,.046],chip:.058},{range:[.117,.227],size:[.91,.92],offset:[-.016,.01],cuts:[.068,.03,.049,.08],seam:[1,.36,-.11,.021]}],shaft:[{range:[.216,.63],size:[.721,.766],offset:[-.014,-.009],cuts:[.061,.045,.073,.061],seam:[-.4,.91,.052,.025],lean:.037},{range:[.663,1.376],size:[.741,.775],offset:[-.012,.008],cuts:[.047,.063,.062,.052],seam:[1,.29,-.126,.032],lean:-.035,chip:.055},{range:[1.41,2.34],size:[.686,.749],offset:[-.041,-.016],cuts:[.058,.047,.104,.087],seam:[-.23,1,.082,.023],lean:.061,chip:.109},{range:[2.363,3.224],size:[.744,.782],offset:[0,.008],cuts:[.086,.039,.066,.051],seam:[1,-.26,.154,.032],lean:-.041,chip:.054}],cap:[{range:[3.205,3.295],size:[.866,.838],offset:[-.036,.017],cuts:[.094,.055,.061,.042],bevel:.014},{range:[3.287,3.485],size:[1.035,.982],offset:[-.024,.018],cuts:[.145,.047,.076,.112],seam:[.28,-1,.085,.026],chip:.114,bevel:.026}],moss:[{band:`cap`,course:1,piece:0,face:`top`,shape:`cluster`,anchor:[-.249,.176],size:[.452,.398],rise:.026,angle:-.51},{band:`cap`,course:1,piece:1,face:`top`,shape:`flecks`,anchor:[.213,-.241],size:[.288,.242],rise:.017,angle:.26},{band:`base`,course:1,piece:0,face:`top`,shape:`strip`,anchor:[-.409,.025],size:[.055,.193],rise:.019,angle:-.12}]},columnRight:{colors:{top:`#BDC2B8`,side:`#81959A`,shade:`#406072`},base:[{range:[-.016,.148],size:[1.015,1.072],offset:[.009,0],cuts:[.053,.111,.062,.034],seam:[1,-.22,.29,.028],chip:.045},{range:[.141,.208],size:[.878,.86],offset:[.03,-.021],cuts:[.075,.048,.054,.09],bevel:.012}],shaft:[{range:[.195,.569],size:[.776,.796],offset:[.011,-.014],cuts:[.071,.043,.093,.048],seam:[1,-.12,-.124,.031],lean:.035,chip:.058},{range:[.606,1.339],size:[.707,.778],offset:[.018,.007],cuts:[.056,.052,.063,.067],seam:[1,-.2,.156,.031],lean:-.021,chip:.055},{range:[1.374,1.989],size:[.756,.794],offset:[.021,-.024],cuts:[.04,.091,.074,.046],seam:[.24,1,-.013,.035],lean:.018,chip:.062},{range:[2.024,2.644],size:[.698,.746],offset:[-.043,-.004],cuts:[.084,.035,.075,.043],seam:[1,.31,-.129,.029],lean:-.037},{range:[2.684,3.215],size:[.831,.817],offset:[.05,-.02],cuts:[.071,.082,.103,.042],seam:[-.17,1,.021,.03],lean:.043,chip:.096}],cap:[{range:[3.199,3.284],size:[.947,.865],offset:[.044,-.008],cuts:[.059,.107,.055,.07],bevel:.013},{range:[3.277,3.475],size:[1.105,1.045],offset:[.028,-.025],cuts:[.067,.203,.054,.106],seam:[.84,-.78,.15,.047],step:-.091,exposedBed:!0,chip:.106,bevel:.026}],moss:[{band:`cap`,course:1,piece:1,face:`top`,shape:`cluster`,anchor:[.271,-.208],size:[.285,.303],rise:.03,angle:.52},{band:`cap`,course:1,piece:0,face:`top`,shape:`strip`,anchor:[-.134,.286],size:[.31,.166],rise:.019,angle:-.63},{band:`shaft`,course:2,piece:1,face:`right`,shape:`strip`,anchor:[.035,.158],size:[.134,.236],rise:.016,angle:-.48}]},columnLower:{colors:{top:`#9DAFB5`,side:`#70909E`,shade:`#355263`},base:[{range:[-.017,.121],size:[1.026,1.073],offset:[-.005,-.002],cuts:[.11,.067,.091,.053],seam:[.76,.65,-.16,.027],chip:.065},{range:[.115,.238],size:[.859,.896],offset:[-.036,.027],cuts:[.102,.05,.068,.084],chip:.086}],shaft:[{range:[.225,.604],size:[.771,.819],offset:[-.018,.014],cuts:[.079,.052,.109,.062],seam:[.89,-.42,.023,.033],lean:-.051},{range:[.642,1.31],size:[.721,.776],offset:[.027,.015],cuts:[.062,.08,.038,.117],seam:[1,.29,-.116,.035],lean:.054,chip:.075},{range:[1.346,1.621],size:[.821,.865],offset:[.034,-.012],cuts:[.082,.065,.131,.101],seam:[.2,1,.001,.034],lean:-.077,chip:.06,bevel:.024},{range:[1.656,2.419],size:[.673,.735],offset:[-.041,.008],cuts:[.05,.089,.091,.043],seam:[1,-.19,.177,.035],lean:.038,chip:.083},{range:[2.453,3.247],size:[.755,.815],offset:[.006,.02],cuts:[.105,.056,.062,.096],seam:[-.4,1,-.039,.034],lean:-.079,chip:.096}],cap:[{range:[3.214,3.295],size:[.89,.878],offset:[-.039,.025],cuts:[.092,.056,.105,.07],bevel:.013},{range:[3.282,3.506],size:[1.092,1.025],offset:[-.058,.035],cuts:[.13,.161,.222,.059],seam:[1,-.55,-.03,.047],step:-.091,chip:.146,bevel:.028}],moss:[{band:`cap`,course:1,piece:0,face:`top`,shape:`strip`,anchor:[-.327,.187],size:[.311,.449],rise:.027,angle:-.4},{band:`cap`,course:1,piece:1,face:`top`,shape:`cluster`,anchor:[.218,-.061],size:[.245,.325],rise:.028,angle:.49},{band:`shaft`,course:0,piece:0,face:`front`,shape:`flecks`,anchor:[-.221,-.015],size:[.135,.122],rise:.018,angle:.3}]}},Ye={cluster:[{outline:[[-.47,-.15],[-.36,-.38],[-.08,-.42],[.08,-.28],[.36,-.24],[.48,.03],[.24,.18],[.12,.42],[-.18,.38],[-.26,.22],[-.46,.2]],peak:[-.035,.018],rise:1,rim:.29},{outline:[[.03,.19],[.19,.16],[.39,.24],[.46,.38],[.28,.49],[.12,.42]],peak:[.23,.31],rise:.62,rim:.19}],strip:[{outline:[[-.43,-.28],[-.15,-.44],[.12,-.38],[.38,-.47],[.47,-.18],[.31,.05],[.42,.28],[.19,.44],[-.08,.37],[-.29,.28],[-.48,.11]],peak:[.03,-.05],rise:1,rim:.23}],flecks:[{outline:[[-.47,-.24],[-.27,-.41],[-.11,-.31],[-.035,-.08],[-.22,.15],[-.42,.04]],peak:[-.25,-.13],rise:1,rim:.26},{outline:[[.015,.085],[.21,-.02],[.42,.07],[.45,.32],[.28,.46],[.075,.34]],peak:[.23,.19],rise:.69,rim:.2}]},Xe={base:61,shaft:0,cap:133};function Ze(e){let t=Math.cos(e.angle??0),n=Math.sin(e.angle??0);function r([r,i]){let a=r*e.size[0],o=i*e.size[1];return[t*a-n*o,n*a+t*o]}return{anchor:e.anchor,lobes:Ye[e.shape].map(t=>({outline:t.outline.map(r),peak:r(t.peak),rise:e.rise*t.rise,rim:e.rise*t.rim}))}}function Qe(e){let t=e.size[0]/2,n=e.size[1]/2,[r,i,a,o]=e.cuts,[s,c]=e.offset??[0,0];return[[-t+r,-n],[t-i,-n],[t,-n+i],[t,n-a],[t-a,n],[-t+o,n],[-t,n-o],[-t,-n+r]].map(([e,t])=>[e+s,t+c])}function $e(e,t,n){let[r,i,a,o]=t,s=Math.hypot(r,i)*o/2,c=([e,t])=>n*(r*e+i*t-a)+s,l=[];for(let t=0;t<e.length;t++){let n=e[t],r=e[(t+1)%e.length],i=c(n),a=c(r);if(i<=0&&l.push(n),i*a<0){let e=i/(i-a);l.push([n[0]+(r[0]-n[0])*e,n[1]+(r[1]-n[1])*e])}}return l}function et(e,t,n,i){let a=Je[e.name],o=new r;o.name=e.name;let[s,c,l]=e.position;o.position.set(s,c,l),o.rotation.y=e.rotationY;let u=new r;u.name=`${o.name}-shaft`,o.add(u);let d=0;function f(e,t,n,r,a=0){let o=new m(i(n),r);return o.name=t,o.position.y=a,o.castShadow=o.receiveShadow=!0,e.add(o),o}let p=a.shaft[0].range[0],g=a.shaft.at(-1).range[1];f(u,`${o.name}-joint-0`,Pe(.43,g-p,.46,{bevel:0,cornerCut:.027,seed:47}),n.stone,(p+g)/2);for(let e of[`base`,`shaft`,`cap`])for(let[r,i]of a[e].entries()){let s=Qe(i),c=i.seam?[$e(s,i.seam,1),$e(s,i.seam,-1)]:[s];for(let[s,l]of c.entries()){let[c,p]=i.range,m=p-c+(s===1?i.step??0:0),g=31+t*79+Xe[e]+r*11+s*17,_=U(l,m,{bevel:i.bevel??(e===`shaft`?.019:.022),cornerCut:0,seed:g,chipCorner:(t+r+s*3)%l.length,chipSize:i.chip});i.lean&&_.applyMatrix4(new h().set(1,i.lean/m,0,0,0,1,0,0,0,0,1,0,0,0,0,1));let v=e===`shaft`?`block-${d++}`:`${e}-${r}-${s}`,y=s===1&&i.exposedBed?n.exposedStone:n.stone,b=f(e===`shaft`?u:o,`${o.name}-${v}`,_,y,c+m/2);for(let[t,i]of a.moss.entries()){if(i.band!==e||i.course!==r||i.piece!==s)continue;let a=Re(_,Ze(i),i.face);a&&f(b,`${o.name}-moss-${t}`,a,n.moss)}}}return o}var W={side:0,origin:[V.fountain.innerRadius,0],tangent:[-Math.sin(Math.PI/8),-Math.cos(Math.PI/8)],edgeLength:V.fountain.innerRadius*2*Math.sin(Math.PI/8),bedInset:.015,thickness:.078,stones:[{span:[.17,.494],reach:.195,bankY:.342,lipY:.3,fall:-.006,cut:[.086,.117,.05,.096]},{span:[.507,.74],reach:.162,bankY:.338,lipY:.299,fall:.006,cut:[.044,.083,.081,.105]}]},G={flowSpeed:.035,waveSpeed:.36,waveStrength:.15,dropFocus:[-.72,.53],impact:{contactDuration:.082,contactRadius:.032,startRadius:.025,primaryHalfWidth:.013,secondaryHalfWidth:.008,secondaryDelay:.15,strength:{contact:.62,primary:.42,secondary:.22}},edgeGlintWidth:[.022,.049],clearWaterRadius:[.96,1.22],colors:{shallow:`#C3E3D8`,base:`#B7D3E2`,middle:`#9DBFD5`,deep:`#2F6481`,shade:`#779CB6`,white:`#F2FAFC`,impactLight:`#E9F9F8`,shelfWater:`#B0C8BA`,shelfTop:`#C5D0B7`,shelfSide:`#9CB2A4`,shelfShade:`#85A5A1`,stoneTop:`#F0E5C1`,stoneSide:`#C7CCB6`,stoneShade:`#7095A1`,wetStone:`#557D81`,weathering:`#A3B592`}},tt=[{side:5,bed:.218,foot:{spread:-.003,joint:.56,rise:.006},lower:{spread:.016,joint:.4,skew:.015,wear:.068},upper:{spread:-.015,joint:.67,skew:-.027},crown:{spread:.008,joint:.27,skew:.025,rise:.004,bevel:.025,smallStone:{end:`start`,name:`repair`,rise:-.019}}},{side:4,bed:.243,foot:{spread:-.009,joint:.68,rise:-.004},lower:{spread:.009,joint:.27},upper:{spread:-.024,joint:.57,skew:.023,wear:.053},crown:{spread:-.012,joint:.77,skew:-.023,rise:-.002,bevel:.023,smallStone:{end:`finish`,name:`step`,rise:-.054}}},{side:3,bed:.232,foot:{spread:-.023,rise:.003},lower:{spread:.005,joint:.28},upper:{spread:-.009,joint:.69},innerJoint:[.49,.642,.79],crown:{spread:-.018,rise:-.009,bevel:.021,chip:.043}},{side:2,bed:.251,foot:{spread:-.028,rise:-.009},lower:{spread:-.006,joint:.58},upper:{spread:-.022,joint:.37,skew:.017},crown:{spread:.011,joint:.81,skew:-.012,rise:.005,bevel:.024,smallStone:{end:`finish`,name:`end`,rise:-.006}}},{side:1,bed:.233,foot:{spread:-.015,rise:.005},lower:{spread:.003},upper:{spread:-.012,joint:.55},crown:{spread:.003,rise:.003,bevel:.024,cut:{corner:0,along:.082,inward:.048}}},{side:0,bed:.241,foot:{spread:-.012,rise:-.006},lower:{spread:.004,joint:.54,skew:-.02},upper:{spread:-.021,joint:.25},crown:{spread:-.006,rise:-.005,bevel:.021}},{side:7,bed:.22,foot:{spread:0,joint:.67,rise:.008},lower:{spread:.012,joint:.47,skew:-.023},upper:{spread:-.017,joint:.29,skew:.018,wear:.047},crown:{spread:.017,rise:.009,bevel:.024,chip:.112,cut:{corner:0,along:.163,inward:.116}}},{side:6,bed:.252,foot:{spread:-.007,joint:.43,rise:-.004},lower:{spread:.016,joint:.3,skew:.018},upper:{spread:-.006,joint:.66,skew:-.021},crown:{spread:.004,rise:-.004,bevel:.025,chip:.042}}],nt=Math.PI/4,K=V.fountain;function rt(e,t){return[e*Math.cos(t*nt),-e*Math.sin(t*nt)]}function it(e,t,n){let r=rt(e,t),i=rt(e,t+1);return[r[0]+(i[0]-r[0])*n,r[1]+(i[1]-r[1])*n]}function at(e){return e===void 0?[[0,1]]:[[0,e],[e,1]]}function ot(e,t,n,[r,i],a,o=0){let s=e=>a/(4*e*Math.sin(nt/2)),c=s(t),l=s(n);return[it(t,e,r+c),it(t,e,i-c),it(n,e,i-l+(i<1?o:0)),it(n,e,r+l+(r>0?o:0))]}function st(e,t){let{corner:n,inward:r,along:i}=t,a=e[n],o=e[(n+e.length-1)%e.length],s=e[(n+1)%e.length];function c(e,t){let n=e[0]-a[0],r=e[1]-a[1],i=t/Math.hypot(n,r);return[a[0]+n*i,a[1]+r*i]}return[...e.slice(0,n),c(o,n===0?r:i),c(s,n===0?i:r),...e.slice(n+1)]}function ct(e,t,n){e.moveTo(t,0);for(let r=1;r<8;r++){let[i,a]=rt(t,r*n);e.lineTo(i,-a)}e.closePath()}function lt(e,t,n){let i=new r;i.name=`fountain-rim`,e.add(i);function a(e,r,i,a){let o=new m(n(i),t);return o.name=r,o.position.y=a,o.castShadow=o.receiveShadow=!0,e.add(o),o}a(e,`fountain-base`,U(Array.from({length:8},(e,t)=>rt(K.baseRadius-.083,t)),K.baseHeight,{bevel:.015,cornerCut:.022,seed:11}),K.baseHeight/2);let o=K.baseHeight+K.rimHeight,s=o-.148,c=K.baseHeight-.006,l=new E,u=new ae;ct(l,K.outerRadius-.131,1),ct(u,K.innerRadius,-1),l.holes.push(u);let d=s+.01-c,f=a(i,`fountain-rim-wall`,Ne(new ee(l,{depth:d,bevelEnabled:!1,steps:1,curveSegments:1}),17),c);f.rotation.x=-Math.PI/2,tt.forEach((e,t)=>{let n=new r;n.name=`fountain-edge-${t+1}`,i.add(n);function c(e,r,i,o){let s=a(n,e,i,o);s.userData.poolEdge=t+1,s.userData.poolBand=r}let l=[{kind:`foot`,profile:e.foot,outer:K.baseRadius,inner:K.innerRadius+.26,bottom:-.016,top:K.baseHeight+e.foot.rise,gap:.025,bevel:.015},{kind:`lower`,profile:e.lower,outer:K.outerRadius,inner:K.innerRadius+.13,bottom:K.baseHeight-.005,top:e.bed,gap:.028,bevel:.017},{kind:`upper`,profile:e.upper,outer:K.outerRadius,inner:K.innerRadius+.13,bottom:e.bed+.011,top:s+.005,gap:.03,bevel:.022}];for(let r of l){let{profile:i,kind:a,bottom:o,top:s}=r;at(i.joint).forEach((l,u)=>{let d=U(ot(e.side,r.outer+i.spread,r.inner,l,r.gap,i.skew),s-o,{bevel:r.bevel,cornerCut:.013,chipSize:u===0?i.wear:void 0,chipCorner:1,seed:37+t*19+u*13+(a===`foot`?1:Math.round(o*100)),tintStrength:a===`foot`?1.5:2.65});c(`${n.name}-${a}-${u+1}`,a,d,(o+s)/2)})}if(e.innerJoint){let[t,r,i]=e.innerJoint,a=[[t,r],[r,i]],o=K.waterHeight+.003,l=s+.004;a.forEach((t,r)=>{let i=U(ot(e.side,K.innerRadius+.025,K.innerRadius-.031,t,.03),l-o,{bevel:.007,cornerCut:.005,seed:79+r*13,tintStrength:1.4});c(`${n.name}-lining-${r+1}`,`lining`,i,(o+l)/2)})}if(e.side===W.side){let{origin:e,tangent:t,edgeLength:r,bedInset:i,thickness:a}=W,o=[t[1],-t[0]];W.stones.forEach(({span:s,reach:l,bankY:u,lipY:d,fall:f,cut:p},m)=>{let g=s[0]*r,_=s[1]*r,[v,y,b,x]=p,S=[[g,-i],[_,-i],[_,l-x],[_-b,l],[g+v,l],[g,l-y]].map(([n,r])=>[e[0]+t[0]*n+o[0]*r,e[1]+t[1]*n+o[1]*r]),C=(d-u)/l,w=f/(_-g),T=C*o[0]+w*t[0],E=C*o[1]+w*t[1],D=new h().set(1,0,0,0,T,1,E,-T*e[0]-E*e[1]-w*(g+_)/2,0,0,1,0,0,0,0,1),O=U(S,a,{bevel:.009,cornerCut:.004,seed:331+m*47,tintStrength:1.4}).applyMatrix4(D);c(`${n.name}-shelf-${m+1}`,`shelf`,O,u-a/2)})}let u=e.crown;at(u.joint).forEach((n,r)=>{let i=u.smallStone,a=i&&r===(i.end===`start`?0:1)?i:void 0,l=o+u.rise+(a?.rise??0)-s,d=ot(e.side,K.outerRadius+u.spread,K.innerRadius,n,.029,u.skew);c(`fountain-coping-${e.side}${a?`-${a.name}`:``}`,`crown`,U(u.cut?st(d,u.cut):d,l,{bevel:u.bevel,cornerCut:.017,chipSize:u.chip,chipCorner:u.cut?1:2,seed:23+t*29+r*17,tintStrength:1.65}),s+l/2)})})}var q=V.fountain,ut=[{name:`fountain-pedestal-foot`,size:q.pedestalFootSize,height:q.pedestalFootHeight,outline:[[-.5,-.406],[-.483,.38],[-.406,.482],[.351,.499],[.494,.381],[.493,-.348],[.406,-.468]],options:{bevel:.019,cornerCut:.016,seed:61,chipSize:.038,chipCorner:6}},{name:`fountain-pedestal`,size:q.pedestalSize,height:q.pedestalHeight,outline:[[-.466,-.43],[-.5,.324],[-.398,.481],[.317,.5],[.498,.341],[.484,-.35],[.38,-.494]],options:{bevel:.022,cornerCut:.012,seed:43,chipSize:.074,chipCorner:4,tintStrength:1.35},taper:.09},{name:`fountain-pedestal-cap`,size:q.pedestalCapSize,height:q.pedestalCapHeight,outline:[[-.471,-.465],[-.5,.343],[-.433,.477],[.348,.5],[.499,.365],[.483,-.393],[.412,-.484]],options:{bevel:.013,cornerCut:.009,seed:29,chipSize:.064,chipCorner:4,tintStrength:1.25}}],dt=[{name:`fountain-moss-inner-2`,support:`fountain-rim-wall`,side:4,along:.87,radius:q.innerRadius,elevation:.388,face:`inside`,lobes:[{outline:[[-.118,-.008],[-.093,-.029],[-.061,-.027],[-.032,-.04],[.023,-.039],[.062,-.03],[.099,-.014],[.088,.006],[.053,.012],[.015,.027],[-.049,.021],[-.083,.025],[-.113,.013]],peak:[-.009,-.024],rise:.024,rim:.012},{outline:[[.06,-.02],[.094,-.039],[.131,-.035],[.15,-.019],[.136,.003],[.102,.008],[.079,-.004]],peak:[.108,-.022],rise:.022,rim:.01},{outline:[[-.129,.016],[-.104,.007],[-.076,.021],[-.076,.032],[-.107,.038],[-.126,.028]],peak:[-.106,.022],rise:.013,rim:.006}]},{name:`fountain-moss-coping-2`,support:`fountain-coping-4-step`,side:4,along:.87,radius:q.innerRadius+.1,elevation:.524,face:`top`,lobes:[{outline:[[-.127,-.023],[-.108,-.052],[-.072,-.061],[-.012,-.051],[.019,-.068],[.065,-.05],[.097,-.031],[.113,-.003],[.081,.018],[.055,.041],[.013,.034],[-.035,.05],[-.092,.025]],peak:[-.023,-.015],rise:.022,rim:.009},{outline:[[.071,.029],[.101,.012],[.125,.021],[.131,.037],[.106,.058],[.083,.052]],peak:[.1,.036],rise:.013,rim:.006}]},{name:`fountain-moss-seam-3`,support:`fountain-edge-3-lining-1`,side:3,along:.571,radius:q.innerRadius-.031,elevation:.384,face:`inside`,lobes:[{outline:[[-.071,-.008],[-.057,-.02],[-.036,-.029],[-.016,-.018],[.003,-.012],[.011,.002],[-.009,.015],[-.041,.016],[-.063,.008]],peak:[-.037,-.01],rise:.019,rim:.008},{outline:[[.026,.01],[.039,-.004],[.054,-.007],[.069,.006],[.061,.019],[.041,.022]],peak:[.047,.008],rise:.012,rim:.005}]},{name:`fountain-moss-foot`,support:`fountain-edge-1-foot-1`,side:5,along:.147,radius:q.baseRadius-.003,elevation:.066,face:`outside`,lobes:[{outline:[[-.137,-.007],[-.115,-.021],[-.071,-.023],[-.031,-.018],[.012,-.029],[.055,-.025],[.084,-.009],[.112,.003],[.088,.018],[.042,.023],[-.001,.018],[-.048,.028],[-.091,.018],[-.126,.012]],peak:[-.02,-.002],rise:.016,rim:.006}]}];function ft(e,t,n){let r=q.baseHeight;for(let i of ut){let a=U(i.outline.map(([e,t])=>[e*i.size,t*i.size]),i.height,i.options);if(`taper`in i){let e=a.getAttribute(`position`);for(let t=0;t<e.count;t++){let n=1-i.taper*(e.getY(t)/i.height+.5);e.setX(t,e.getX(t)*n),e.setZ(t,e.getZ(t)*n)}a.computeVertexNormals(),a.computeBoundingBox(),a.computeBoundingSphere()}let o=new m(n(a),t);o.name=i.name,o.position.y=r+i.height/2,o.castShadow=o.receiveShadow=!0,e.add(o),r+=i.height}}function pt(e,t,n){e.updateWorldMatrix(!0,!0);let r=Math.PI/4;for(let i of dt){let a=e.getObjectByName(i.support);if(!(a instanceof m))continue;let o=i.side*r,s=o+r,c=new A(i.radius*Math.cos(o),i.elevation,-i.radius*Math.sin(o)).lerp(new A(i.radius*Math.cos(s),i.elevation,-i.radius*Math.sin(s)),i.along),l=o+r/2,u=a.matrixWorld.clone().invert().multiply(e.matrixWorld),d=new A(Math.cos(l),0,-Math.sin(l));i.face===`inside`&&d.negate();let f=new A(0,1,0),p=f.clone().cross(d).transformDirection(u),g=(i.face===`top`?f:d).transformDirection(u),_=p.clone().cross(g),v=new h().makeBasis(p,g,_).setPosition(c.applyMatrix4(u)),y=a.geometry.clone().applyMatrix4(v.clone().invert()),b=Re(y,{anchor:[0,0],lobes:i.lobes},`top`,.06);if(y.dispose(),!b)continue;let x=new m(n(b.applyMatrix4(v)),t);x.name=i.name,x.castShadow=x.receiveShadow=!0,a.add(x)}}function mt(e,t,n,r){ft(e,t,r),pt(e,n,r)}function ht(e){let t=new r;t.name=`courtyard-blockout`;let n=new Set;function i(e){return n.add(e),e}let a=new Map,o=ze(),s=ze({top:`#557282`,side:`#637E8B`,shade:`#36546A`}),c=ze({top:`#FFFFFF`,side:`#E5EBDC`,shade:`#88A29A`});c.name=`courtyard-stone-moss`,c.vertexColors=!0;let l=Ve(e);function u(e,t,n,r,s,c,l=0,u=0,d={}){let f={bevel:I.bevel,cornerCut:I.cornerCut,seed:11,...d},p=JSON.stringify([n,r,s,f]),h=a.get(p);h||(h=i(Pe(n,r,s,f)),a.set(p,h));let g=new m(h,o);return g.name=t,g.position.set(l,c+r/2,u),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let d=V.fountain,f=new r;f.name=`fountain`,f.position.set(...d.position),f.rotation.y=d.rotationY,t.add(f),lt(f,o,i);let p=new m(i(new oe(d.innerRadius,8)),l);p.name=`fountain-water`,p.rotation.x=-Math.PI/2,p.position.y=d.waterHeight,p.receiveShadow=!0,f.add(p),mt(f,o,c,i),V.columns.forEach((e,n)=>{t.add(et(e,n,{stone:o,exposedStone:s,moss:c},i))});let h=V.wall,g=new r;g.name=`wallLeft`,g.position.set(...h.position),g.rotation.y=h.rotationY,u(g,`wallLeft-base`,h.length+h.endSize,h.baseHeight,h.baseDepth,0);let _=new r;_.name=`wallLeft-body`,g.add(_);let v=I.wall.bodyBlocks,y=I.joints.width,b=(h.length-(v-1)*y)/v;for(let e=0;e<v;e++){let t=-h.length/2+b/2+e*(b+y);u(_,`wallLeft-body-${e}`,b,h.height,h.depth,h.baseHeight,t,0,{seed:11+e*18,chipSize:e===v-1?.075:0,chipCorner:2}),e<v-1&&u(_,`wallLeft-body-joint-${e}`,y,h.height,h.depth-I.joints.recess*2,h.baseHeight,t+b/2+y/2,0,{bevel:0,cornerCut:0,seed:47})}let x=new r;x.name=`wallLeft-cap`,g.add(x);let S=I.wall.capBlocks,C=(h.length-(S-1)*y)/S;for(let e=0;e<S;e++){let t=-h.length/2+C/2+e*(C+y);u(x,`wallLeft-cap-${e}`,C,h.capHeight,h.capDepth,h.baseHeight+h.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===S-1?.065:0,chipCorner:2}),e<S-1&&u(x,`wallLeft-cap-joint-${e}`,y,h.capHeight*.65,h.capDepth-I.joints.recess*2,h.baseHeight+h.height,t+C/2+y/2,0,{bevel:0,cornerCut:0,seed:47})}u(g,`wallLeft-end`,h.endSize,h.endHeight,h.endSize,h.baseHeight,h.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(g);let w=V.path,T=new r;T.name=`pathRight`,T.position.set(...w.position),T.rotation.y=w.rotationY,Ke.forEach((e,t)=>{let{outline:n,profile:r}=e,{exposedHeight:a,embeddedDepth:s,bevel:l,chipVertex:u,chipSize:d}=r,f=-s,p=i(U(n,a-f,{bevel:l,cornerCut:0,seed:11+9*t,chipCorner:n.length-1-u,chipSize:d})),h=new m(p,o);h.name=`pathRight-slab-${e.id}`,h.position.set(e.center[0],(a+f)/2,e.center[1]),h.rotation.y=e.rotationY,h.castShadow=!0,h.receiveShadow=!0,T.add(h);let g=Ae[e.id],_=g&&Re(p,g);if(_){let t=new m(i(_),c);t.name=`pathRight-moss-${e.id}`,t.castShadow=!0,t.receiveShadow=!0,h.add(t)}}),t.add(T);let E=!1;return{root:t,dispose(){if(!E){E=!0,t.removeFromParent(),t.clear();for(let e of n)e.dispose();o.dispose(),s.dispose(),c.dispose(),l.dispose()}}}}function gt(t,n,r){let i=new M;return i.setAttribute(`position`,new e(t,3)),i.setAttribute(`plantPart`,new e(n,1)),i.setAttribute(`plantHeight`,new e(r,1)),i.computeVertexNormals(),i.computeBoundingBox(),i.computeBoundingSphere(),i}function _t(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>gt(e,t,n)}}function vt(){let e=_t();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function yt(){let e=_t();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function bt(e){let t=_t();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function xt(e,t){let n=De(e,t);return n.side=2,n}var St=.035;function Ct(e,t,n,r){let i=V.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=V.columnShape;for(let n of V.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=V.wall;return!f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY)}function wt(e,t,n,r=St){return Ct(e,t,n,r)&&qe(e,t,n+r)}function Tt(e,t,n){let r=L.ground.pavingReserve,i=n+St;return!(e>r.x[0]-i&&e<r.x[1]+i&&t>r.z[0]-i&&t<r.z[1]+i)&&Ct(e,t,n,St)}function Et(e,t){let n=new r;n.name=`courtyard-vegetation`;let i=L.seed;function a(){i+=1831565813;let e=Math.imul(i^i>>>15,1|i);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let o=(e,t)=>e+(t-e)*a();function s(t,n){let r=new A(t,0,n).project(e);return Math.abs(r.x)<.98&&Math.abs(r.y)<.98}function c(e,t){let n=L.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let l=[],u=[];if(L.enabled){for(let e=0;l.length<L.grass.count&&e<L.grass.count*120;e++){let e,t;if(a()<.48){let n=L.flowers.clusters[Math.floor(a()*L.flowers.clusters.length)],r=a()*Math.PI*2,i=Math.sqrt(a())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=o(-7.5,7.4),t=o(-8.7,8.4);!s(e,t)||!Tt(e,t,L.grass.clearance)||c(e,t)&&a()<.9||l.push({x:e,z:t,height:o(L.grass.minHeight,L.grass.maxHeight),diameter:0,rotation:a()*Math.PI*2,color:a(),radius:L.grass.clearance,gap:!1})}for(let e=0;u.length<L.flowers.count&&e<L.flowers.count*120;e++){let e=L.flowers.clusters[Math.floor(a()*L.flowers.clusters.length)],t=a()*Math.PI*2,n=a()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,l=o(L.flowers.minDiameter,L.flowers.maxDiameter),d=l*.55+.01;s(r,i)&&!c(r,i)&&Tt(r,i,d)&&(u.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+d)*.85)||u.push({x:r,z:i,height:o(L.flowers.minHeight,L.flowers.maxHeight),diameter:l,rotation:a()*Math.PI*2,color:a(),radius:d,gap:!1}))}if(l.length!==L.grass.count||u.length!==L.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=.023;for(let{center:t,height:n}of L.grass.pavingTufts){let[r,i]=Ge(t[0],t[1]);wt(r,i,e,.037)&&l.push({x:r,z:i,height:n,diameter:0,rotation:a()*Math.PI*2,color:a(),radius:e,gap:!0})}}let f=e=>qe(e.x,e.z,e.radius+St),p=l.filter(e=>e.gap||f(e)),m=u.filter(f),g=[],_=[],v=[];if(L.enabled){let e=xt(`foliage`,t),r=xt(`flower`,t);_.push(e,r);let i=vt(),a=yt(),o=bt(4),s=bt(5);g.push(i,a,o,s);function c(e,r,i,a,o){let s=new ue(r,i,a.length);s.name=e,s.castShadow=!1,s.receiveShadow=!0;let c=new h,l=new D,u=new A(0,1,0),f=new T(o===`flower`?N.flower:o===`stem`?N.plantStem:N.grassBlade),p=new T(o===`flower`?N.flowerLight:N.grassBladeLight);if(a.forEach((e,t)=>{l.setFromAxisAngle(u,e.rotation);let n=o===`flower`?e.diameter:e.height,r=o===`grass`&&e.gap?L.grass.gapWidthScale:1;c.compose(new A(e.x,L.rootHeight+(o===`flower`?e.height:0),e.z),l,new A(n*r,n,n*r)),s.setMatrixAt(t,c),s.setColorAt(t,f.clone().lerp(p,o===`stem`?e.color*.25:o===`flower`?e.color*.6:e.color*.85))}),s.instanceMatrix.needsUpdate=!0,s.instanceColor&&(s.instanceColor.needsUpdate=!0),t?.options.enabled){let e=new Float32Array(a.length*3),t=new Float32Array(a.length*4);a.forEach((n,r)=>{let i=o===`grass`?n.gap?R.wind.gapAngle:R.wind.grassAngle:R.wind.flowerAngle;e.set([n.x,L.rootHeight,n.z],r*3),t.set([n.height,i,xe(n.x,n.z),+(o===`flower`)],r*4)}),r.setAttribute(`windRoot`,new d(e,3)),r.setAttribute(`windShape`,new d(t,4))}s.computeBoundingBox(),s.computeBoundingSphere(),t?.options.enabled&&(s.boundingBox.expandByScalar(.02),s.boundingSphere.radius+=.02),s.userData.plants=a,s.userData.plantType=o,v.push(s),n.add(s)}c(`grass-clusters`,i,e,p,`grass`),c(`flower-stems`,a,e,m,`stem`),c(`flowers-four-petal`,o,r,u.filter((e,t)=>t%2==0&&f(e)),`flower`),c(`flowers-five-petal`,s,r,u.filter((e,t)=>t%2==1&&f(e)),`flower`)}n.userData.seed=L.seed,n.userData.counts={grass:p.length,flowers:m.length,batches:v.length};let y=!1;return{root:n,dispose(){if(!y){y=!0;for(let e of v)e.dispose();for(let e of g)e.dispose();for(let e of _)e.dispose();n.removeFromParent(),n.clear()}}}}var Dt={primary:{amplitude:.032,period:4,direction:[2.5,2,-1.55]},secondary:{amplitude:.008,period:2.6,direction:[-3.1,1.2,4.4]},stemFade:[-.84,-.48],interiorFollow:.25},J={axis:[.766434,-.575767,.28473],front:[.330778,.733779,.593426],offset:-.306825,frontTime:3.5,crestWidth:[.056,.167],backWeight:.3,colors:{crest:`#E2F5FB`,shade:`#4C8BAE`}},Ot={clearance:.02,beads:[{direction:[-.82,-.26,.51],phase:.36,formationTime:.16,radius:.024,speed:.84,vy:-.06,strength:1.6},{direction:[-.74,-.25,.62],phase:.88,formationTime:.14,radius:.019,speed:.81,vy:-.06,strength:1.12}]},Y={radius:.26,centerY:1.37,floatAmplitude:.03,floatPeriod:6,sphereSegments:[12,8],shape:{first:.025,second:.009,x:.012,y:.015,z:.012,yRatio:.96,envelope:(1.025+.009)*1.012},flow:{mainPeriod:7.2,detailPeriod:4.1,turnPeriod:23,main:[2.2,7.4,.8],bend:[3.2,0,2],bendStrength:.8,detail:[2.1,-3,7]},stemRadius:.04,stemOverlap:.025,releaseLatitude:-.16,releaseMargin:.004,colors:{base:`#80B9D5`,light:`#ADDCE8`,side:`#4D89B2`,shade:`#427192`,white:`#F3FBFF`}},kt=Math.PI*2,X=Y.flow,Z=(e,t)=>(e%t+t)%t/t*kt;function At(e,t=new c){let n=Z(e,X.turnPeriod);return t.set(Math.cos(n),Math.sin(n),Z(e,X.mainPeriod),Z(e,X.detailPeriod))}function jt(e,t,n,r){let i=r.x*e-r.y*n,a=r.y*e+r.x*n,o=i*X.bend[0]+t*X.bend[1]+a*X.bend[2]+r.w,s=i*X.main[0]+t*X.main[1]+a*X.main[2]+X.bendStrength*Math.sin(o)+r.z,c=i*X.detail[0]+t*X.detail[1]+a*X.detail[2]-r.w;return 1+Y.shape.first*Math.cos(s)+Y.shape.second*Math.sin(c)}function Mt(e,t,n,r,i=new A){let a=r.x*e-r.y*n,o=r.y*e+r.x*n,s=a*X.bend[0]+t*X.bend[1]+o*X.bend[2]+r.w,c=a*X.main[0]+t*X.main[1]+o*X.main[2]+X.bendStrength*Math.sin(s)+r.z,l=a*X.detail[0]+t*X.detail[1]+o*X.detail[2]-r.w,u=-Y.shape.first*Math.sin(c),d=Y.shape.second*Math.cos(l),f=X.bendStrength*Math.cos(s),p=u*(X.main[0]+f*X.bend[0])+d*X.detail[0],m=u*(X.main[1]+f*X.bend[1])+d*X.detail[1],h=u*(X.main[2]+f*X.bend[2])+d*X.detail[2],g=r.x*p+r.y*h,_=-r.y*p+r.x*h,v=1+Y.shape.first*Math.cos(c)+Y.shape.second*Math.sin(l),y=e*g+t*m+n*_;return i.set(e-(g-e*y)/v,t-(m-t*y)/v,n-(_-n*y)/v).normalize()}var Nt=Math.PI*2/Y.floatPeriod,Pt=()=>({y:0,sx:1,sy:1,sz:1});function Ft(e,t=Pt()){let n=e*Nt;return t.y=Y.centerY+Y.floatAmplitude*Math.sin(n),t.sx=1+Y.shape.x*Math.sin(n*.73),t.sy=Y.shape.yRatio*(1+Y.shape.y*Math.sin(n+.8)),t.sz=1+Y.shape.z*Math.cos(n*.81),t}var It=()=>({birthTime:NaN,x:0,y:0,z:0,vx:0,vy:0,vz:0,duration:0,impactX:0,impactZ:0});function Lt(e,t){let n=z.drops.gravity;return(t+Math.sqrt(t*t+2*n*e))/n}function Rt(e,t){return e.duration=Lt(e.y-V.fountain.waterHeight-t,e.vy),e.impactX=e.x+e.vx*e.duration,e.impactZ=e.z+e.vz*e.duration,e}var zt=Pt(),Bt=new c,Vt=new A;function Ht(e,t,n=It()){let r=Ft(t,zt),i=Math.hypot(e.vx,e.vz),a=Y.releaseLatitude,o=Math.sqrt(1-a*a),s=e.vx/i*o,c=a,l=e.vz/i*o;At(t,Bt);let u=Y.radius*jt(s,c,l,Bt);Mt(s,c,l,Bt,Vt),Vt.set(Vt.x/r.sx,Vt.y/r.sy,Vt.z/r.sz).normalize();let d=e.radius+Y.releaseMargin;return n.birthTime=t,n.x=s*u*r.sx+Vt.x*d,n.y=r.y+c*u*r.sy+Vt.y*d,n.z=l*u*r.sz+Vt.z*d,n.vx=e.vx,n.vz=e.vz,n.vy=e.vy+Y.floatAmplitude*Nt*Math.cos(t*Nt),Rt(n,e.radius)}function Ut(e,t,n){return n.set(e.x+e.vx*t,e.y+e.vy*t-.5*z.drops.gravity*t*t,e.z+e.vz*t)}function Wt(e){let t=e.geometry.getAttribute(`position`),n=e.geometry.getAttribute(`orbDirection`),r=e.geometry.getAttribute(`orbLayer`),i=V.fountain,a=i.baseHeight+i.pedestalFootHeight+i.pedestalHeight+i.pedestalCapHeight,{primary:o,secondary:s,stemFade:c}=Dt,{yRatio:l}=Y.shape,u=new A(...o.direction),d=new A(...s.direction);return Ot.beads.map(f=>{let p=new A(...f.direction),m=new A,h=0,g=-1/0;for(let e=0;e<t.count;e++){if(r.getX(e)!==0)continue;let t=m.fromBufferAttribute(n,e).dot(p);t>g&&(g=t,h=e)}m.fromBufferAttribute(n,h);let _=new A().fromBufferAttribute(t,h),v=new A(m.x,m.y*l,m.z),y=new A(m.x,m.y/l,m.z).normalize(),b=new A(y.x,0,y.z).normalize(),x=m.dot(u),S=m.dot(d),C=re.smoothstep(m.y,...c),w=new A;function T(t,n,r){let i=o.amplitude*Math.cos(x+Z(t,o.period))+s.amplitude*Math.sin(S+Z(t,s.period));return r.copy(_).addScaledVector(v,i*C).add(e.position).addScaledVector(y,f.radius*n)}function E(e,t){T(e,1,w);let n=Lt(w.y-a-f.radius,f.vy),r=i.pedestalCapSize/2+f.radius+Ot.clearance,o=Math.min((r-Math.sign(b.x)*w.x)/Math.abs(b.x),(r-Math.sign(b.z)*w.z)/Math.abs(b.z)),s=Math.max(f.speed,o/n);return t.birthTime=e,t.x=w.x,t.y=w.y,t.z=w.z,t.vx=b.x*s,t.vy=f.vy,t.vz=b.z*s,Rt(t,f.radius)}return{...f,anchorIndex:h,sampleAttached:T,sampleFlight:E}})}function Gt(e){let t=De(`water`);t.name=`courtyard-living-orb`,t.flatShading=!0,t.customProgramCacheKey=()=>`courtyard-living-orb-flow-v2`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r),Object.assign(t.uniforms,{uOrbPhases:{value:e},uOrbBase:{value:new T(Y.colors.base)},uOrbLight:{value:new T(Y.colors.light)},uOrbSide:{value:new T(Y.colors.side)},uOrbShade:{value:new T(Y.colors.shade)},uOrbWhite:{value:new T(Y.colors.white)}});let i=e=>`vec3(${e.map(e=>e.toFixed(6)).join(`, `)})`,a=Y.flow,o=`
      // Rest coordinates interpolate across faces; normalize only per fragment.
      // No atan/UV wrapping, screen coordinates or independently running clock.
      vec3 rest = normalize(vOrbRest);
      vec3 q = vec3(uOrbPhases.x * rest.x - uOrbPhases.y * rest.z, rest.y,
                    uOrbPhases.y * rest.x + uOrbPhases.x * rest.z);
      float bend = dot(q, ${i(a.bend)}) + uOrbPhases.w;
      float mainPhase = dot(q, ${i(a.main)}) + ${a.bendStrength.toFixed(6)} * sin(bend) + uOrbPhases.z;
      float detailPhase = dot(q, ${i(a.detail)}) - uOrbPhases.w;
      float wave = cos(mainPhase);
      // Derivative filtering broadens the crest at the original 384px sampling.
      // Unresolvable secondary ripples fade out instead of flashing single pixels.
      float aa = clamp(fwidth(wave) * .65, .035, .38);
      float flowBand = smoothstep(-.45 - aa, .45 + aa, wave);
      float crest = smoothstep(.76 - aa, .96 + aa, wave);
      float detailVisibility = 1.0 - smoothstep(.55, 1.6, fwidth(detailPhase));
      float detailWave = sin(detailPhase);
      float shortCrest = smoothstep(.72 - aa, .98 + aa, detailWave) * detailVisibility;
      vec3 orbNormal = inverseTransformDirection(normal, viewMatrix);
      float sunFace = .5;
      #if NUM_DIR_LIGHTS > 0
        sunFace = max(dot(normal, directionalLights[0].direction), 0.0);
      #endif
      float volume = smoothstep(-.6, .7, orbNormal.y) * .6 + sunFace * .4;
      vec3 orbColor = mix(uOrbSide, uOrbBase, smoothstep(.08, .92, volume));
      orbColor = mix(orbColor, uOrbLight, flowBand * .46);
      orbColor = mix(orbColor, uOrbSide, (1.0 - flowBand) * .20);
      float edge = pow(1.0 - clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0), 2.6);
      float litCrest = mix(.52, 1.0, sunFace) * mix(.65, 1.0, smoothstep(-.7, .55, orbNormal.y));
      float rim = smoothstep(.35, .85, edge) * smoothstep(-.15, .6, orbNormal.y);
      float movingHighlight = crest * litCrest * .85 + shortCrest * flowBand * .12;
      orbColor = mix(orbColor, uOrbWhite, clamp(movingHighlight + rim * .13, 0.0, .86));
      outgoingLight = mix(uOrbShade, orbColor, getShadowMask());
    `,s=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(s))throw Error(`Orb shader extension anchor changed.`);if(!t.vertexShader.includes(`#include <begin_vertex>`))throw Error(`Orb rest-position anchor changed.`);t.vertexShader=t.vertexShader.replace(`#include <common>`,`#include <common>
attribute vec3 orbRest; varying vec3 vOrbRest;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vOrbRest = orbRest;`),t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      varying vec3 vOrbRest;
      uniform vec4 uOrbPhases;
      uniform vec3 uOrbBase; uniform vec3 uOrbLight; uniform vec3 uOrbSide; uniform vec3 uOrbShade; uniform vec3 uOrbWhite;
    
void main() {`).replace(s,o)},t}var Kt=600,qt=Math.round(Kt*.18),Jt=2.6001,Yt=Math.PI*(3-Math.sqrt(5)),Xt=Y.radius-.013,Zt=1.3,Qt=[.034,.049],$t={body:`#7DB2CD`,shade:`#659CBE`,light:`#CEE4EE`};function en(n){let r=n!==`particles`,i=n===`particle-flow`||n===`particle-drops`,a=new Float32Array(2124),s=new Float32Array(2124),l=new Float32Array(708),u=new Float32Array(708);function d(e,t,n){for(let r=0;r<t;r++){let i=e+r,o=i*3,c=2*(r+.5)/t-1,d=r*Yt+(n?.7:0),f=Math.sqrt(1-c*c),p=f*Math.cos(d),m=f*Math.sin(d),h=n?.202*Math.cbrt((.27+r*.754877666)%1):Xt+.0028*Math.sin(r*2.17);a[o]=p*h,a[o+1]=c*h*Y.shape.yRatio,a[o+2]=m*h,s[o]=p,s[o+1]=c,s[o+2]=m,l[i]=Number(n),u[i]=(Qt[0]+(Qt[1]-Qt[0])*((.31+r*.618033989)%1))*(n?.86:1)}}d(0,Kt,!1),d(Kt,qt,!0);let f=new M;f.setAttribute(`position`,new e(a,3)),f.setAttribute(`orbDirection`,new e(s,3)),f.setAttribute(`orbLayer`,new e(l,1)),f.setAttribute(`orbDiameter`,new e(u,1)),f.computeBoundingBox(),f.computeBoundingSphere();let{primary:p,secondary:m,stemFade:h,interiorFollow:g}=Dt,_=Ft(Jt).y,v=_+f.boundingBox.min.y,y=r?p.amplitude+m.amplitude:0;f.boundingSphere.radius+=Qt[1]/2+y,f.boundingBox.expandByScalar(y);let b=r?new t:void 0,x;if(i){let e=new A(...J.axis).normalize(),t=new A(...J.front).projectOnPlane(e).normalize(),n=new A().crossVectors(e,t);x=new o().set(t.x,t.y,t.z,n.x,n.y,n.z,e.x,e.y,e.z)}let w=new S({name:`courtyard-particle-orb`,transparent:!0,depthTest:!0,depthWrite:!1,toneMapped:!1,defines:{...r&&{ORB_WAVE:1},...i&&{ORB_FLOW:1}},uniforms:{uSampleHeight:{value:1},uMinimumPointSize:{value:Zt},uSunDirection:{value:new A(...F.sun.position).normalize()},uBody:{value:new T($t.body)},uShade:{value:new T($t.shade)},uLight:{value:new T($t.light)},...b&&{uWavePhase:{value:b},uPrimaryWave:{value:new c(...p.direction,p.amplitude)},uSecondaryWave:{value:new c(...m.direction,m.amplitude)},uStemFade:{value:new t(...h)},uInteriorFollow:{value:g},uOrbYRatio:{value:Y.shape.yRatio}},...x&&{uFlowBasis:{value:x},uFlowOffset:{value:J.offset},uFlowFrontPhase:{value:Z(J.frontTime,p.period)},uFlowCrestWidth:{value:new t(...J.crestWidth)},uFlowBackWeight:{value:J.backWeight},uFlowLight:{value:new T(J.colors.crest)},uFlowShade:{value:new T(J.colors.shade)}}},vertexShader:`
      attribute vec3 orbDirection;
      attribute float orbLayer;
      attribute float orbDiameter;
      uniform float uSampleHeight;
      uniform float uMinimumPointSize;
      uniform vec3 uSunDirection;
      uniform vec3 uBody;
      uniform vec3 uShade;
      uniform vec3 uLight;
      varying vec3 vColor;
      varying float vOpacity;

      #ifdef ORB_WAVE
        uniform vec2 uWavePhase;
        uniform vec4 uPrimaryWave;
        uniform vec4 uSecondaryWave;
        uniform vec2 uStemFade;
        uniform float uInteriorFollow;
        uniform float uOrbYRatio;

        vec3 displaceOrbPoint(vec3 rest, vec3 direction, float layer) {
          float primary = uPrimaryWave.w * cos(dot(direction, uPrimaryWave.xyz) + uWavePhase.x);
          float secondary = uSecondaryWave.w * sin(dot(direction, uSecondaryWave.xyz) + uWavePhase.y);
          // Keep the lower cap attached to the pedestal's water column.
          float weight = smoothstep(uStemFade.x, uStemFade.y, direction.y) * mix(1.0, uInteriorFollow, layer);
          vec3 ellipticalDirection = direction * vec3(1.0, uOrbYRatio, 1.0);
          return rest + ellipticalDirection * ((primary + secondary) * weight);
        }
      #endif

      #ifdef ORB_FLOW
        uniform mat3 uFlowBasis;
        uniform float uFlowOffset;
        uniform float uFlowFrontPhase;
        uniform vec2 uFlowCrestWidth;
        uniform float uFlowBackWeight;
        uniform vec3 uFlowLight;
        uniform vec3 uFlowShade;

        vec3 colorOrbFlow(vec3 water, vec3 direction, float facing, float lift, float layer) {
          vec3 orbit = uFlowBasis * direction;
          vec2 around = orbit.xy * inversesqrt(max(dot(orbit.xy, orbit.xy), 0.000001));
          float across = orbit.z - uFlowOffset;
          // The highlight slows through the front arc, then continues around the back.
          float phase = uWavePhase.x - uFlowFrontPhase;
          float travel = phase - .26 * sin(phase) + .24 * (1.0 - cos(phase));
          vec2 heading = vec2(cos(travel - .04), sin(travel - .04));
          float lengthMask = smoothstep(.63, .928, dot(around, heading));
          float taper = mix(.64, 1.0, lengthMask);
          float crest = 1.0 - smoothstep(uFlowCrestWidth.x * taper, uFlowCrestWidth.y * taper, abs(across));
          float trough = 1.0 - smoothstep(.024, .104, abs(across - .172));
          float visibility = mix(uFlowBackWeight, 1.0, smoothstep(-.29, .66, facing));
          float surface = mix(1.0, .14, layer);
          float strength = lengthMask * visibility * surface;
          float liftLight = mix(.58, 1.0, smoothstep(-.028, .030, lift));
          return mix(mix(water, uFlowShade, .36 * strength * trough),
                     uFlowLight, .97 * strength * crest * liftLight);
        }
      #endif

      void main() {
        vec3 direction = normalize(mat3(modelMatrix) * orbDirection);
        vec3 viewDirection = normalize(normalMatrix * orbDirection);
        float facing = viewDirection.z;
        float front = smoothstep(-.52, .76, facing);
        float sun = max(dot(direction, uSunDirection), 0.0);
        float rim = pow(1.0 - abs(facing), 2.0);
        vec3 blue = mix(uShade, uBody, .18 + .64 * front + .16 * sun);
        vec3 viewLight = mat3(viewMatrix) * uSunDirection;
        vec3 halfDirection = normalize(viewLight + vec3(0.0, 0.0, 1.0));
        float directGleam = smoothstep(.86, .992, dot(viewDirection, halfDirection));
        float rimGleam = rim * pow(sun, 3.0);
        float gleam = min(.94 * directGleam + .28 * rimGleam, 1.0);
        #ifdef ORB_FLOW
          gleam *= .62;
        #endif
        vColor = mix(blue, uLight, gleam * mix(1.0, .35, orbLayer));
        vOpacity = (.33 + .49 * front + .09 * rim) * mix(1.0, .42, orbLayer);
        vec3 localPosition = position;
        #ifdef ORB_WAVE
          localPosition = displaceOrbPoint(position, orbDirection, orbLayer);
        #endif
        #ifdef ORB_FLOW
          float lift = dot(localPosition - position, orbDirection);
          vColor = colorOrbFlow(vColor, orbDirection, facing, lift, orbLayer);
        #endif
        gl_Position = projectionMatrix * modelViewMatrix * vec4(localPosition, 1.0);
        gl_PointSize = max(uMinimumPointSize, .5 * abs(projectionMatrix[1][1]) * uSampleHeight * orbDiameter);
      }
    `,fragmentShader:`
      varying vec3 vColor;
      varying float vOpacity;
      void main() {
        float distanceToCenter = length(2.0 * gl_PointCoord - 1.0);
        float coverage = 1.0 - smoothstep(.60, 1.0, distanceToCenter);
        if (coverage < .015) discard;
        gl_FragColor = vec4(vColor, vOpacity * coverage);
        #include <colorspace_fragment>
      }
    `}),E=new C(f,w);return E.name=`fountain-water-crown`,E.position.y=_,E.onBeforeRender=e=>{w.uniforms.uSampleHeight.value=e.getRenderTarget()?.height??e.domElement.height},{object:E,metadata:{radius:Y.radius,centerY:_,amplitude:0,period:0,referenceTime:Jt,shellCount:Kt,interiorCount:qt,vertices:708,triangles:0,shellRadius:Xt,minimumPointSize:Zt,diameter:Qt,colors:$t,addedTextures:0,addedPasses:0,...r&&{wave:Dt,maximumDisplacement:y},...i&&{surfaceFlow:J}},update(e){return b?.set(Z(e,p.period),Z(e,m.period)),v},dispose(){f.dispose(),w.dispose()}}}function tn(){let e=new c,t=Pt(),n=Gt(e),r=new k(1,...Y.sphereSegments),i=r.getAttribute(`position`);i.setUsage(p);let a=new Float32Array(i.array);r.setAttribute(`orbRest`,new y(a,3)),r.boundingSphere=new j(new A,Y.shape.envelope),r.boundingBox=new ie(new A().setScalar(-Y.shape.envelope),new A().setScalar(Y.shape.envelope));let o=new m(r,n);return o.name=`fountain-water-crown`,o.receiveShadow=!0,o.scale.setScalar(Y.radius),{object:o,phases:e,pose:t,metadata:{radius:Y.radius,centerY:Y.centerY,amplitude:Y.floatAmplitude,period:Y.floatPeriod,envelope:Y.shape.envelope,replacedGeometries:2,addedGeometries:0,addedTextures:0,addedPasses:0,flow:`curved-rest-sphere-v2`,vertices:i.count,triangles:r.index.count/3,restAttributeBytes:a.byteLength},update(n){Ft(n,t),At(n,e);let r=1/0;for(let n=0;n<i.count;n++){let o=n*3,s=a[o],c=a[o+1],l=a[o+2],u=jt(s,c,l,e),d=c*u*t.sy;i.setXYZ(n,s*u*t.sx,d,l*u*t.sz),r=Math.min(r,d)}return i.needsUpdate=!0,o.position.y=t.y,t.y+r*Y.radius},dispose(){r.dispose(),n.dispose()}}}function nn(e,t,n=`lively`){let i=new r;i.name=`fountain-effects`,i.userData.orbStyle=n;let a=V.fountain;i.position.set(...a.position),i.rotation.y=a.rotationY;let o=n===`lively`?void 0:en(n),s=o??tn(),c=n===`particle-drops`&&o?Wt(o.object):void 0,l=c?Dt.primary.period:z.drops.period,u=Ve(e,`jet`),d=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,f=new _(Y.stemRadius,Y.stemRadius,1,8),g=new b(1,+!!c),v=new m(f,u);v.name=`fountain-water-column`,v.receiveShadow=!0;let y=new ue(g,u,t.length);y.name=`fountain-water-drops`,y.receiveShadow=!0,y.instanceMatrix.setUsage(p),y.boundingBox=new ie(new A(-1.75,.3,-1.75),new A(1.75,1.9,1.75)),y.boundingSphere=y.boundingBox.getBoundingSphere(new j),i.add(v,s.object,y),i.visible=z.enabled;let x=new A,S=new A,C=new D,w=new h,T=new h,E=(c??t).map((e,t)=>({drop:e,index:t,current:It(),previous:It()})),O=E.map(e=>({record:e,age:0,flight:e.current}));i.userData.flights=E,i.userData.impactEvents=O,`pose`in s&&(i.userData.orbPose=s.pose,i.userData.orbPhases=s.phases),i.userData.orbMetadata={...s.metadata,dropCapacity:t.length,rippleCapacity:e.impacts.value.length,...c&&{releasePeriod:l,beads:c.map(({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i})=>({anchorIndex:e,phase:t,formationTime:n,radius:r,strength:i}))}};let k,ee=!1;function te(n){if(ee||n===k)return;k=n,e.time.value=n;let r=s.update(n),o=r+Y.stemOverlap;v.position.y=(d+o)/2,v.scale.y=o-d;let c=0;for(let e of E){let{drop:t,current:r,previous:i}=e,o=`sampleAttached`in t?t:void 0,s=o?.formationTime??0,u=t.phase+Math.floor((n-t.phase+s)/l)*l;u!==r.birthTime&&(`sampleFlight`in t?(t.sampleFlight(u,r),t.sampleFlight(u-l,i)):(Ht(t,u,r),Ht(t,u-l,i)));let d=n-u,f=t.radius;if(o&&d<0){let e=re.smoothstep(d,-s,0);o.sampleAttached(n,e,x),f*=e}else{if(!o&&d>=r.duration)continue;if(Ut(r,d,x),o){if(x.y+f<=a.waterHeight)continue}else f*=Math.min(1,d/.07,(r.duration-d)/.055)}f<5e-4||(S.setScalar(f),w.compose(x,C,S),y.setMatrixAt(c++,w))}y.count=c;for(let e=c;e<t.length;e++)y.setMatrixAt(e,T);y.instanceMatrix.needsUpdate=!0;for(let e of O){let t=e.record;e.flight=n>=t.current.birthTime+t.current.duration?t.current:t.previous,e.age=n-(e.flight.birthTime+e.flight.duration)}O.sort((e,t)=>e.age-t.age||e.record.index-t.record.index);let u=0;for(let t=0;t<e.impacts.value.length;t++){let n=O[t];n&&n.age>=0&&n.age<z.ripples.lifetime?(e.impacts.value[t].set(n.flight.impactX,n.flight.impactZ,n.age,n.record.drop.strength),u++):e.impacts.value[t].set(0,0,0,0)}i.userData.time=n,i.userData.activeDrops=c,i.userData.activeRipples=u,i.userData.orbBottom=r,i.userData.stemTop=o}return te(z.initialTime),{root:i,update:te,dispose(){ee||(ee=!0,y.dispose(),f.dispose(),s.dispose(),g.dispose(),u.dispose(),i.removeFromParent(),i.clear())}}}function rn(){let e=z.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=z.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=z.jet.emitterHeight-V.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function an(e,t,n){return n.set(e.vx*t,z.jet.emitterHeight+e.vy*t-.5*z.drops.gravity*t*t,e.vz*t)}function on(e,t=`legacy`){if(t!==`legacy`)try{return nn(e,rn(),t)}catch(e){console.warn(`Orb detail unavailable; original water effects retained.`,e)}let n=new r;n.name=`fountain-effects`;let i=V.fountain;n.position.set(...i.position),n.rotation.y=i.rotationY;let a=rn();n.userData.dropParameters=a;let o=Ve(e,`jet`),s=i.baseHeight+i.pedestalFootHeight+i.pedestalHeight+i.pedestalCapHeight,c=z.jet.emitterHeight-s,l=new _(z.jet.stemRadius,z.jet.stemRadius,c,8),u=new k(1,8,5),d=new b(1,0),f=new m(l,o);f.name=`fountain-water-column`,f.position.y=s+c/2,f.receiveShadow=!0;let p=new m(u,o);p.name=`fountain-water-crown`,p.position.y=z.jet.emitterHeight,p.receiveShadow=!0;let g=new ue(d,o,a.length);g.name=`fountain-water-drops`,g.receiveShadow=!0,g.boundingBox=new ie(new A(-1.4,.3,-1.4),new A(1.4,1.45,1.4)),g.boundingSphere=g.boundingBox.getBoundingSphere(new j),n.add(f,p,g),n.visible=z.enabled;let v=new A,y=new A,x=new h,S=new D,C=new h,w=a.map(e=>({drop:e,age:0})),T=(e,t)=>e.age-t.age,E=(e,t)=>(e%t+t)%t;function O(t){e.time.value=t;let r=0;for(let e of a){let n=E(t-e.phase,z.drops.period);if(n>=e.impactTime)continue;an(e,n,v);let i=Math.min(1,n/.07),a=Math.min(1,(e.impactTime-n)/.055),o=e.radius*Math.min(i,a);o<5e-4||(y.setScalar(o),x.compose(v,S,y),g.setMatrixAt(r++,x))}g.count=r;for(let e=r;e<a.length;e++)g.setMatrixAt(e,C);g.instanceMatrix.needsUpdate=!0;for(let e of w)e.age=E(t-e.drop.phase-e.drop.impactTime,z.drops.period);w.sort(T);let i=0;for(let t=0;t<e.impacts.value.length;t++){let n=w[t];n.age<z.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),i++):e.impacts.value[t].set(0,0,0,0)}let o=z.jet.pulse,s=z.jet.radius;p.scale.set(s*(1+o*Math.sin(t*2.1)),s*.9*(1+o*Math.sin(t*2.8)),s*(1+o*Math.cos(t*2.1))),f.scale.set(1+o*Math.sin(t*2.1),1,1+o*Math.sin(t*2.1)),n.userData.time=t,n.userData.activeDrops=r,n.userData.activeRipples=i}O(z.initialTime);let ee=!1;return{root:n,update:O,dispose(){ee||(ee=!0,g.dispose(),l.dispose(),u.dispose(),d.dispose(),o.dispose(),n.removeFromParent(),n.clear())}}}function sn(){let t=R.petals,n=R.seed+1;function r(){n+=1831565813;let e=Math.imul(n^n>>>15,1|n);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let i=Array.from({length:t.capacity},(e,n)=>{let i=0,a=0,o=!1;for(let e=0;e<1e3;e++){let e=L.flowers.clusters[Math.floor(r()*L.flowers.clusters.length)],n=r()*Math.PI*2,s=r()*e.radius;if(i=e.center[0]+Math.cos(n)*s,a=e.center[1]+Math.sin(n)*s,wt(i,a,t.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:i,z:a,phase:n*t.period/t.capacity,rotation:r()*Math.PI*2,size:.055+r()*.02}}),a=new M;a.setAttribute(`position`,new e([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),a.computeVertexNormals();let o=new g({color:N.flowerLight,side:2,toneMapped:!1});o.name=`courtyard-floating-petal`;let s=new ue(a,o,t.capacity);s.name=`courtyard-floating-petals`,s.castShadow=!1;let c=new ie;for(let e of i)c.expandByPoint(new A(e.x-t.drift,t.minHeight,e.z-t.drift)),c.expandByPoint(new A(e.x+t.drift,t.maxHeight,e.z+t.drift));c.expandByScalar(.05),s.boundingBox=c,s.boundingSphere=c.getBoundingSphere(new j),s.userData.parameters=i;let l=new h,u=new A,d=new A,f=new D,p=new h,m=new A(.25,1,.15).normalize(),_=!1;return{mesh:s,update(e){let n=0;for(let r of i){let i=((e-r.phase)%t.period+t.period)%t.period;if(i>=t.lifetime)continue;let a=i/t.lifetime,o=Math.min(1,i/.6,(t.lifetime-i)/.7);u.set(r.x+Math.sin(i*.6+r.rotation)*t.drift,t.maxHeight+(t.minHeight-t.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*t.drift),f.setFromAxisAngle(m,r.rotation+i*.25),d.setScalar(r.size*o),l.compose(u,f,d),s.setMatrixAt(n++,l)}s.count=n;for(let e=n;e<t.capacity;e++)s.setMatrixAt(e,p);s.instanceMatrix.needsUpdate=!0},dispose(){_||(_=!0,s.dispose(),a.dispose(),o.dispose(),s.removeFromParent())}}}function cn(e=`rim`){let t=e===`damp`,n=e===`shelf`,r=ze(n?{top:G.colors.shelfTop,side:G.colors.shelfSide,shade:G.colors.shelfShade}:{top:G.colors.stoneTop,side:G.colors.stoneSide,shade:G.colors.stoneShade});r.name=n?`courtyard-pool-shelf-stone`:t?`courtyard-pool-damp-stone`:`courtyard-pool-stone`,r.customProgramCacheKey=()=>`${r.name}-v3`;let i=r.onBeforeCompile.bind(r);return r.onBeforeCompile=(e,r)=>{i(e,r);let a=V.fountain;Object.assign(e.uniforms,{uPoolStoneOrigin:{value:new c(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uPoolStoneLevels:{value:new c(a.position[1],a.waterHeight,a.baseHeight,a.innerRadius)},uPoolStoneWet:{value:new T(G.colors.wetStone)},uPoolStoneOld:{value:new T(G.colors.weathering)}});let o=`
      vec2 poolDelta = vArtWorldPosition.xz - uPoolStoneOrigin.xy;
      vec2 poolP = vec2(uPoolStoneOrigin.z * poolDelta.x - uPoolStoneOrigin.w * poolDelta.y,
                       uPoolStoneOrigin.w * poolDelta.x + uPoolStoneOrigin.z * poolDelta.y);
      vec2 poolN = vec2(uPoolStoneOrigin.z * worldNormal.x - uPoolStoneOrigin.w * worldNormal.z,
                       uPoolStoneOrigin.w * worldNormal.x + uPoolStoneOrigin.z * worldNormal.z);
      float poolY = vArtWorldPosition.y - uPoolStoneLevels.x;
      float side = 1.0 - smoothstep(.35, .85, worldNormal.y);
      float innerFace = 1.0 - smoothstep(-.08, .05, dot(poolN, poolP));
      float pedestal = 1.0 - smoothstep(.44, .58, max(abs(poolP.x), abs(poolP.y)));
      float wetNoise = artNoise(poolP * 13.0 + vec2(5.4, 8.1));
      float wetLine = 1.0 - smoothstep(uPoolStoneLevels.y + .018, uPoolStoneLevels.y + .065 + wetNoise * .025, poolY);
      float wet = wetLine * side * max(innerFace, pedestal);
      outgoingLight = mix(outgoingLight, mix(outgoingLight * .73, uPoolStoneWet, .22), wet * .72);
      ${t?`
      float aboveWater = poolY - uPoolStoneLevels.y;
      float tideEdge = .045 + .025 * wetNoise;
      float dampBand = (1.0 - smoothstep(.013, tideEdge + .033, aboveWater)) * side;
      vec3 soakedStone = mix(outgoingLight * .60, uPoolStoneWet * vec3(.73, .86, 1.02), .21);
      outgoingLight = mix(outgoingLight, soakedStone, dampBand * .82);
      float dryStone = smoothstep(.05, .14, aboveWater) * pedestal * side;
      outgoingLight = mix(outgoingLight, outgoingLight * vec3(1.14, 1.04, .90), dryStone * .81);
      float seamContact = (1.0 - smoothstep(.006, .032, aboveWater)) * (1.0 - pedestal) * innerFace * side;
      outgoingLight = mix(outgoingLight, uPoolStoneWet * .62, seamContact * .26);
    `:``}
      ${n?`
      float atWater = 1.0 - smoothstep(.004, .027, abs(poolY - uPoolStoneLevels.y));
      outgoingLight = mix(outgoingLight, uPoolStoneWet, .09 + .23 * atWater);
    `:``}
      float contact = (1.0 - smoothstep(.005, .062 + .012 * wetNoise, poolY)) * side;
      outgoingLight *= mix(vec3(1.0), vec3(.76, .82, .68), contact);
      float capStep = (1.0 - smoothstep(.004, .018, abs(poolY - .44))) * side;
      outgoingLight *= 1.0 - capStep * .10;
      float chips = max(1.0 - smoothstep(.08, .28, length(poolP - vec2(.935, -2.259))),
                        1.0 - smoothstep(.08, .28, length(poolP + vec2(.935, -2.259))));
      float weather = chips * smoothstep(.48, .72, wetNoise) * smoothstep(.48, .56, poolY);
      outgoingLight = mix(outgoingLight, uPoolStoneOld, weather * .35);
    `,s=`outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;`;if(!e.fragmentShader.includes(s))throw Error(`Pool stone extension anchor changed.`);e.fragmentShader=e.fragmentShader.replace(`void main() {`,`
      uniform vec4 uPoolStoneOrigin; uniform vec4 uPoolStoneLevels;
      uniform vec3 uPoolStoneWet; uniform vec3 uPoolStoneOld;
    
void main() {`).replace(s,`${s}\n${o}`)},r}function ln(e){let n=De(`water`);n.name=`courtyard-water-refined-surface`,n.userData.waterKind=`refined-surface`,n.customProgramCacheKey=()=>`courtyard-water-refined-surface-v3`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=V.fountain,o=G.impact;Object.assign(n.uniforms,{uPoolTime:e.time,uPoolImpacts:e.impacts,uPoolOrigin:{value:new c(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uPoolMotion:{value:new A(G.flowSpeed,G.waveSpeed,G.waveStrength)},uPoolBoundary:{value:new c(a.innerRadius*Math.cos(Math.PI/8),...G.edgeGlintWidth,z.ripples.lifetime)},uPoolClearRadius:{value:new t(...G.clearWaterRadius)},uPoolDropFocus:{value:new t(...G.dropFocus)},uPoolRippleTiming:{value:new t(o.contactDuration,o.secondaryDelay)},uPoolRippleShape:{value:new c(o.startRadius,o.contactRadius,o.primaryHalfWidth,o.secondaryHalfWidth)},uPoolRippleGain:{value:new A(o.strength.contact,o.strength.primary,o.strength.secondary)},uPoolImpactLight:{value:new T(G.colors.impactLight)},uPoolShelfFrame:{value:new c(...W.origin,...W.tangent)},uPoolShelfPieces:{value:W.stones.map(({span:e,reach:t,bankY:n,lipY:r})=>new c(e[0]*W.edgeLength,e[1]*W.edgeLength,t,t*(n-a.waterHeight)/(n-r)))},uPoolShelfCuts:{value:W.stones.map(({cut:e})=>new c(...e))},uPoolShelfRake:{value:W.stones.map(({span:e,reach:t,bankY:n,lipY:r,fall:i})=>t*i/((n-r)*(e[1]-e[0])*W.edgeLength))},uPoolShelfWater:{value:new T(G.colors.shelfWater)},uPoolShallow:{value:new T(G.colors.shallow)},uPoolBase:{value:new T(G.colors.base)},uPoolMiddle:{value:new T(G.colors.middle)},uPoolDeep:{value:new T(G.colors.deep)},uPoolShade:{value:new T(G.colors.shade)},uPoolWhite:{value:new T(G.colors.white)}});let s=`
      uniform float uPoolTime;
      uniform vec4 uPoolImpacts[${z.ripples.capacity}];
      uniform vec4 uPoolOrigin; uniform vec3 uPoolMotion; uniform vec4 uPoolBoundary;
      uniform vec2 uPoolClearRadius;
      uniform vec2 uPoolDropFocus;
      // Contact duration and secondary delay.
      uniform vec2 uPoolRippleTiming;
      // Start radius, contact radius, and the two ring half-widths.
      uniform vec4 uPoolRippleShape;
      uniform vec3 uPoolRippleGain;
      uniform vec3 uPoolImpactLight;
      uniform vec4 uPoolShelfFrame;
      uniform vec4 uPoolShelfPieces[${W.stones.length}];
      uniform vec4 uPoolShelfCuts[${W.stones.length}];
      uniform float uPoolShelfRake[${W.stones.length}];
      uniform vec3 uPoolShelfWater;
      uniform vec3 uPoolShallow; uniform vec3 uPoolBase; uniform vec3 uPoolMiddle;
      uniform vec3 uPoolDeep; uniform vec3 uPoolShade; uniform vec3 uPoolWhite;

      vec3 shelfWaterBands(vec2 bank, vec4 piece, vec4 cut, float rake, float aa) {
        float spanFade = smoothstep(piece.x - .13, piece.x + .047, bank.x)
          * (1.0 - smoothstep(piece.y - .047, piece.y + .13, bank.x));
        float startCut = cut.y * (1.0 - clamp((bank.x - piece.x) / cut.x, 0.0, 1.0));
        float endCut = cut.w * (1.0 - clamp((piece.y - bank.x) / cut.z, 0.0, 1.0));
        float lip = piece.z - startCut - endCut;
        float stoneSpan = smoothstep(piece.x - aa * .3, piece.x + aa * .3, bank.x)
          * (1.0 - smoothstep(piece.y - aa * .3, piece.y + aa * .3, bank.x));
        float shallows = (1.0 - smoothstep(lip + .014, lip + .29, bank.y)) * spanFade;
        float entry = piece.w + rake * (bank.x - (piece.x + piece.y) * .5);
        float submergedStone = smoothstep(entry - aa * .25, entry + .026, bank.y)
          * (1.0 - smoothstep(lip - .012, lip + .041, bank.y)) * stoneSpan;
        float fromEntry = bank.y - entry;
        float entrySpan = smoothstep(piece.x, piece.x + cut.x * .67, bank.x)
          * (1.0 - smoothstep(piece.y - cut.z * .67, piece.y, bank.x));
        float contact = smoothstep(-aa * .24, .007, fromEntry)
          * (1.0 - smoothstep(.009, .029 + aa * .28, fromEntry))
          * smoothstep(-aa * .25, .013, lip - entry) * entrySpan;
        return vec3(shallows, submergedStone, contact);
      }

      float reflectedBank(vec2 p, vec2 normal, vec4 profile, float lean, float aa) {
        float along = dot(p, vec2(normal.y, -normal.x));
        float across = uPoolBoundary.x - dot(p, normal);
        float branches = artNoise(vec2(along * 5.1, across * 4.2) + vec2(profile.w, 7.4));
        float endShape = along - across * lean + (branches - .5) * .14;
        float taper = smoothstep(profile.x - .05, profile.x + .29, endShape)
          * (1.0 - smoothstep(profile.y - .35, profile.y + .078, endShape));
        float disturbance = sin(along * 8.7 + uPoolTime * .52 + profile.w) * .029;
        float reach = (profile.z * pow(taper, .64) + (branches - .5) * .29 + disturbance) * smoothstep(.03, .36, taper);
        float edge = 1.0 - smoothstep(reach - .026 - aa * .4, reach + .058 + aa * .45, across);
        float sky = artNoise(vec2(along * 6.7 + profile.w, across * 17.0 - disturbance * 2.0));
        float gaps = smoothstep(.69, .89, sky) * .38;
        return edge * taper * smoothstep(.036, .15, across) * (1.0 - gaps);
      }

      float bankGlint(vec2 p, vec2 normal, vec2 segment, float offset, float phase, float aa) {
        float along = dot(p, vec2(normal.y, -normal.x));
        float across = uPoolBoundary.x - dot(p, normal);
        float lengthMask = smoothstep(segment.x - .036, segment.x + .06, along)
          * (1.0 - smoothstep(segment.y - .05, segment.y + .037, along));
        float widthMask = smoothstep(offset, offset + .013, across)
          * (1.0 - smoothstep(offset + uPoolBoundary.y, offset + uPoolBoundary.z + aa * .21, across));
        float brokenEdge = smoothstep(.29, .71, artNoise(vec2(along * 14.6, across * 3.7 + 4.1)));
        float shimmer = .78 + .22 * sin(uPoolTime * .87 + along * 14.5 + phase);
        return lengthMask * widthMask * brokenEdge * shimmer;
      }

      float rippleBand(float distanceToCenter, float radius, float halfWidth, float aa) {
        float distanceToRing = abs(distanceToCenter - radius);
        return 1.0 - smoothstep(max(halfWidth - aa * .22, halfWidth * .5), halfWidth + aa * .55, distanceToRing);
      }

      float impactLightAt(vec2 p, vec4 event, float aa) {
        float age = event.z;
        float lifetime = uPoolBoundary.w;
        if (event.w <= 0.0 || age < 0.0 || age >= lifetime) return 0.0;

        vec2 offset = p - event.xy;
        float distanceToCenter = length(offset);
        float speed = ${z.ripples.speed.toFixed(2)};
        float radius = uPoolRippleShape.x + age * speed;
        float contactReach = uPoolRippleShape.y + aa * .35;
        float ringReach = radius + .004 + max(uPoolRippleShape.z, uPoolRippleShape.w) + aa * .55;
        if (distanceToCenter > max(contactReach, ringReach)) return 0.0;

        float contact = 1.0 - smoothstep(uPoolRippleShape.y * .27, contactReach, distanceToCenter);
        contact *= mix(.45, 1.0, smoothstep(0.0, .016, age))
          * (1.0 - smoothstep(.027, uPoolRippleTiming.x, age)) * uPoolRippleGain.x;

        // Anchor the broken arcs to the landing point, even when the event changes slots.
        vec2 heading = offset / max(distanceToCenter, .002);
        vec2 seed = event.xy * 18.0 + vec2(7.1, 3.3);
        float arcShape = artNoise(heading * vec2(3.1, 4.5) + seed);
        float arcs = mix(.23, 1.0, smoothstep(.31, .63, arcShape));
        float primaryRadius = radius + (arcShape - .5) * .008;
        float primary = rippleBand(distanceToCenter, primaryRadius, uPoolRippleShape.z, aa);
        primary *= smoothstep(.006, .042, age) * (1.0 - smoothstep(.132, lifetime, age))
          * (1.0 - age * .58) * arcs * uPoolRippleGain.y;

        float ageAfterDelay = max(age - uPoolRippleTiming.y, 0.0);
        float trailingRadius = uPoolRippleShape.x + ageAfterDelay * speed * .94;
        float trailingArcs = smoothstep(.28, .65, artNoise(heading * vec2(3.8, 3.0) + seed + vec2(8.3, 2.2)));
        float trailing = rippleBand(distanceToCenter, trailingRadius, uPoolRippleShape.w, aa);
        trailing *= smoothstep(0.0, .041, ageAfterDelay) * (1.0 - smoothstep(.257, .575, age))
          * trailingArcs * uPoolRippleGain.z;
        return min(.92, max(contact, max(primary, trailing)) * event.w);
      }
    `,l=`
      vec2 delta = vArtWorldPosition.xz - uPoolOrigin.xy;
      vec2 p = vec2(uPoolOrigin.z * delta.x - uPoolOrigin.w * delta.y,
                    uPoolOrigin.w * delta.x + uPoolOrigin.z * delta.y);
      float t = uPoolTime;
      vec2 drift = vec2(t, -t * .25) * uPoolMotion.x;
      float broad = artNoise(p * vec2(2.2, 1.6) + drift * .5 + vec2(3.7, 6.1));
      float aa = clamp(max(fwidth(p.x), fwidth(p.y)), .003, .12);
      float detail = 1.0 - smoothstep(.035, .095, aa);
      float centerDistance = length(p);
      float leftReflection = reflectedBank(p, vec2(-.923880, -.382683), vec4(-.93, 1.01, .58, 4.6), -.27, aa);
      float backReflection = reflectedBank(p, vec2(-.382683, -.923880), vec4(-1.03, .99, .75, 12.3), .51, aa);
      float reflection = max(leftReflection, backReflection)
        * smoothstep(uPoolClearRadius.x, uPoolClearRadius.y, centerDistance);

      float shoreDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + .5) * PI / 4.0;
        shoreDistance = min(shoreDistance, uPoolBoundary.x - dot(p, vec2(cos(angle), -sin(angle))));
      }
      vec2 shelfDelta = p - uPoolShelfFrame.xy;
      vec2 shelfTangent = uPoolShelfFrame.zw;
      vec2 bank = vec2(dot(shelfDelta, shelfTangent), dot(shelfDelta, vec2(shelfTangent.y, -shelfTangent.x)));
      vec3 shelf = vec3(0.0);
      for (int i = 0; i < ${W.stones.length}; i++) {
        shelf = max(shelf, shelfWaterBands(bank, uPoolShelfPieces[i], uPoolShelfCuts[i], uPoolShelfRake[i], aa));
      }
      float nearBank = 1.0 - smoothstep(.025, .27, shoreDistance + (broad - .5) * .047);
      float depth = smoothstep(.24, 1.43, shoreDistance) * .32;
      vec3 clearWater = mix(uPoolBase, uPoolMiddle, depth);
      clearWater = mix(clearWater, uPoolShallow, nearBank * .67);
      vec3 shelfTone = mix(uPoolShallow, uPoolShelfWater, shelf.y * .38);
      clearWater = mix(clearWater, shelfTone, shelf.x * .87);
      vec3 litWater = mix(clearWater, uPoolDeep, reflection * .93);

      float wave = smoothstep(.955, .995, sin(centerDistance * 12.0 - t * uPoolMotion.y * 12.0 + broad));
      wave *= smoothstep(.65, .9, centerDistance) * (1.0 - smoothstep(1.5, 1.95, centerDistance));
      wave *= smoothstep(.52, .76, artNoise(p * 7.5 + drift)) * uPoolMotion.z;
      float glint = smoothstep(.78, .94, artNoise(p * 7.0 - drift))
        * smoothstep(.90, .99, sin(p.x * 11.0 + p.y * 6.0 - t * .72 + broad * 3.0)) * .64;
      float dropZone = 1.0 - smoothstep(.19, .45, length(p - uPoolDropFocus));
      float ambientLight = max(wave * mix(1.0, .26, dropZone), glint * mix(1.0, .32, dropZone));
      ambientLight *= mix(.25, 1.0, detail) * mix(1.0, .67, reflection);

      float litBack = bankGlint(p, vec2(.382683, -.923880), vec2(-.19, .41), .075, .48, aa);
      float litCorner = bankGlint(p, vec2(.923880, .382683), vec2(-.39, .06), .174, 2.94, aa);
      float shelfArc = smoothstep(.29, .54, artNoise(vec2(bank.x * 14.5, 3.7)));
      float shelfPulse = .74 + .26 * sin(t * .79 - bank.x * 7.1);
      float shelfLight = shelf.z * shelfArc * shelfPulse;
      float shoreLight = max(max(litBack, litCorner) * .60, shelfLight * .34);

      float impacts = 0.0;
      for (int i = 0; i < ${z.ripples.capacity}; i++) {
        impacts = max(impacts, impactLightAt(p, uPoolImpacts[i], aa));
      }
      impacts *= smoothstep(.012, .095, shoreDistance) * mix(1.0, .48, reflection);
      float white = max(ambientLight, shoreLight);
      litWater = mix(litWater, uPoolWhite, white);
      litWater = mix(litWater, uPoolImpactLight, impacts);
      vec3 shadedBank = mix(uPoolShade, uPoolShallow * .64, shelf.x * .44);
      vec3 shadedWater = mix(shadedBank, clearWater, .12 + shelf.x * .37 + nearBank * .10);
      shadedWater = mix(shadedWater, uPoolDeep * .84, reflection * .79);
      shadedWater = mix(shadedWater, uPoolWhite, white * .13 + shelfLight * .08);
      shadedWater = mix(shadedWater, uPoolImpactLight, impacts * .45);
      outgoingLight = mix(shadedWater, litWater, getShadowMask());
    `,u=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(u))throw Error(`Pool surface extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${s}\nvoid main() {`).replace(u,l)},n}function un(e,t){let n=e.getObjectByName(`fountain`),r=n?.getObjectByName(`fountain-water`),i=n?.getObjectByName(`fountain-rim`);if(!n||!i||!(r instanceof m))throw Error(`Pool finish requires a complete fountain.`);let a=[];for(let e of[`base`,`rim-wall`,`pedestal-foot`,`pedestal`,`pedestal-cap`]){let t=n.getObjectByName(`fountain-${e}`);if(!(t instanceof m))throw Error(`Missing fountain ${e}.`);a.push(t)}i.traverse(e=>{e instanceof m&&typeof e.userData.poolEdge==`number`&&a.push(e)});let o=ln(t),s=cn(),c=cn(`damp`),l=cn(`shelf`),u=new Map;for(let e of[...a,r]){u.set(e,e.material);let t=e.name.startsWith(`fountain-pedestal`)||e.userData.poolBand===`lining`;e.material=e===r?o:e.userData.poolBand===`shelf`?l:t?c:s}let d=!1;return{metadata:{bindings:[...u.keys()].map(e=>({object:e.name,material:e.material.name})),newGeometries:0,newTextures:0,extraPasses:0},dispose(){if(!d){d=!0;for(let[e,t]of u)e.material=t;u.clear(),o.dispose(),s.dispose(),c.dispose(),l.dispose()}}}}var Q={period:32,speed:.22,softness:[.46,1.3],unionSoftness:.24,patches:[{along:-3,across:-1.4,radius:[4.6,3.3],density:1},{along:12,across:4.6,radius:[5.6,3.7],density:.88}],response:{ground:.18,stone:.14,foliage:.13,flower:.1,water:.075,orb:.05,jet:.045}},dn=F.sun.position,fn=[dn[0]/dn[1],dn[2]/dn[1]],pn=Ce,mn=Q.period/Q.speed;function hn(e){return(e*Q.speed%Q.period+Q.period)%Q.period}function gn(e,t){let n=t,r={enabled:e,active:{value:+!!e},drift:{value:hn(t)},failures:[],update(t){e&&t!==n&&(n=t,r.drift.value=hn(t))},snapshot(){return{enabled:e,active:r.active.value,time:n,drift:r.drift.value,repeatSeconds:mn,failures:[...r.failures]}}};return r}var $=e=>e.toFixed(10),_n=e=>`vec2(${e.map($).join(`,`)})`,vn=`
  uniform float uCloudDrift;
  uniform float uCloudActive;
  float cloudSoftMin(float a, float b) {
    float h = max(${$(Q.unionSoftness)} - abs(a - b), 0.0) / ${$(Q.unionSoftness)};
    return min(a, b) - h * h * ${$(Q.unionSoftness*.25)};
  }
  float cloudPatch(vec2 point, vec2 center, vec2 radius) {
    vec2 q = point - center;
    q.x -= ${$(Q.period)} * floor(q.x / ${$(Q.period)} + .5);
    q /= radius;
    // Evaluate derivatives before the coherent empty-space branch. The cloud
    // is already fully clear outside these bounds, including the wrap seam.
    float aa = min(max(fwidth(q.x), fwidth(q.y)) * .75, .10);
    if (abs(q.x) > 1.8 || abs(q.y) > 1.6) return 0.0;
    vec2 b = (q - vec2(.48, -.16)) * vec2(1.3, 1.18);
    vec2 c = (q + vec2(.44, -.22)) * vec2(1.15, 1.38);
    float d = cloudSoftMin(cloudSoftMin(dot(q, q), dot(b, b)), dot(c, c));
    return 1.0 - smoothstep(${$(Q.softness[0])} - aa, ${$(Q.softness[1])} + aa, d);
  }
  float cloudCoverage(vec3 world) {
    vec2 projected = world.xz - world.y * ${_n(fn)};
    const vec2 direction = ${_n(pn)};
    vec2 point = vec2(dot(projected, direction) - uCloudDrift,
                      dot(projected, vec2(-direction.y, direction.x)));
    ${Q.patches.map((e,t)=>`float c${t} = cloudPatch(point, ${_n([e.along,e.across])}, ${_n(e.radius)}) * ${$(e.density)};`).join(`
`)}
    return 1.0 - (1.0 - c0) * (1.0 - c1);
  }
`;function yn(e,t,n,r){let i=`#include <opaque_fragment>`;if(!e.fragmentShader.includes(i)||!e.fragmentShader.includes(`void main() {`)||!e.vertexShader.includes(`vArtWorldPosition`))throw Error(`Cloud receiver shader anchor unavailable`);let a=t===`ground`?`mix(.08, 1.0, 1.0 - occlusion)`:t===`foliage`?`mix(.10, 1.0, 1.0 - plantOcclusion)`:t===`flower`?`mix(.10, 1.0, 1.0 - flowerOcclusion)`:`mix(.12, 1.0, cloudSceneShadow) * mix(.10, 1.0, smoothstep(.015, .32, cloudLuminance))`,o=t===`water`?` * mix(1.0, .30, smoothstep(.50, .90, cloudLuminance))`:``,s=`
    // CLOUD_SHADOW_FINISH: shared world field after the original material finish.
    float cloudLuminance = dot(outgoingLight, vec3(.2126, .7152, .0722));
    float cloudMask = cloudCoverage(vArtWorldPosition);
    float cloudAmount = cloudMask * ${$(n)} * (${a})${o} * uCloudActive;
    outgoingLight *= vec3(1.0) - cloudAmount * vec3(1.0, .96, .85);
    ${i}
  `,c=e.fragmentShader.replaceAll(`getShadowMask()`,`cloudSceneShadow`).replace(`void main() {`,`void main() {
float cloudSceneShadow = getShadowMask();`).replace(`#include <common>`,`#include <common>\n${vn}`).replace(i,s);e.uniforms.uCloudDrift=r.drift,e.uniforms.uCloudActive=r.active,e.fragmentShader=c}function bn(e){let t=new Map,n=!1;return{bind(r){!n&&e.enabled&&r.traverse(n=>{if(n instanceof m)for(let r of Array.isArray(n.material)?n.material:[n.material]){let n=r.userData.artSurface;if(!n||!(n in Q.response)||t.has(r))continue;let i=r.name===`courtyard-living-orb`?Q.response.orb:r.userData.waterKind===`jet`?Q.response.jet:Q.response[n],a=r.onBeforeCompile,o=r.customProgramCacheKey;t.set(r,{compile:a,key:o,data:r.userData.cloudShadow}),r.customProgramCacheKey=()=>`${o.call(r)}-cloud-shadow-v2-${i}`,r.onBeforeCompile=(t,o)=>{if(a.call(r,t,o),e.active.value)try{yn(t,n,i,e)}catch(t){e.active.value=0,e.failures.push(`${r.name}: ${String(t)}`),console.warn(`Cloud shade unavailable; original surface lighting retained.`,t)}},r.userData.cloudShadow={surface:n,strength:i}}})},get metadata(){return{...e.snapshot(),materials:[...t.keys()].map(e=>({name:e.name,...e.userData.cloudShadow})),newGeometries:0,newTextures:0,extraPasses:0,extraDrawCalls:0}},dispose(){if(!n){n=!0;for(let[e,n]of t)e.onBeforeCompile=n.compile,e.customProgramCacheKey=n.key,n.data===void 0?delete e.userData.cloudShadow:e.userData.cloudShadow=n.data;t.clear()}}}}var xn={routes:[{center:[-.6,1.3],radii:[7.2,5.5],height:4.45,rotation:.05,period:48,phase:.14,direction:1,span:.34,flapCycle:5.2,flapDuration:1.4,flapRate:1.7},{center:[.4,.7],radii:[6.1,6.4],height:5.1,rotation:-.65,period:54,phase:.55,direction:-1,span:.32,flapCycle:5.4,flapDuration:1.6,flapRate:1.9},{center:[-.4,1.1],radii:[7.8,4.9],height:5.75,rotation:.35,period:61,phase:.81,direction:1,span:.33,flapCycle:4.9,flapDuration:1.3,flapRate:1.6}],colors:{warm:`#F3EAC4`,light:`#F8FCED`,cool:`#7095A1`,tip:`#405B55`,beak:`#DCCB9D`},bodyRadius:.69,clearance:.25,desktopMargin:20,mobileMargin:14,fadePixels:26,minimumAlpha:.015},Sn=Math.PI*2,Cn=(e,t)=>(e%t+t)%t,wn=e=>{let t=Math.min(1,Math.max(0,e));return t*t*t*(t*(t*6-15)+10)};function Tn(){return{position:new A,tangent:new A,rotation:new D,euler:new n(0,0,0,`YXZ`),leftWing:0,rightWing:0,flap:0,bank:0,speed:0,scale:1,phase:0}}function En(e,t,n){let r=xn.routes[t],i=Cn(e/r.period*r.direction+r.phase,1),a=Sn*i,o=Sn/r.period*r.direction,s=Math.cos(r.rotation),c=Math.sin(r.rotation),l=r.radii[0]*Math.cos(a)+.35*Math.sin(2*a),u=r.radii[1]*Math.sin(a),d=(-r.radii[0]*Math.sin(a)+.7*Math.cos(2*a))*o,f=r.radii[1]*Math.cos(a)*o,p=Cn(e+t*1.37,r.flapCycle),m=wn(p/.22)*(1-wn((p-r.flapDuration+.28)/.28)),h=Sn*r.flapRate*e+t*1.9,g=.08+m*(.54*Math.sin(h)-.04);n.position.set(r.center[0]+s*l-c*u,r.height+.055*Math.sin(2*a)+.016*m*Math.sin(h*2),r.center[1]+c*l+s*u),n.tangent.set(s*d-c*f,.11*o*Math.cos(2*a),c*d+s*f),n.speed=n.tangent.length(),n.tangent.normalize();let _=Math.atan2(n.tangent.x,n.tangent.z),v=-Math.atan2(n.tangent.y,Math.hypot(n.tangent.x,n.tangent.z)),y=-.18*r.direction*(.75+.25*Math.cos(2*a));return n.euler.set(v,_,y,`YXZ`),n.rotation.setFromEuler(n.euler),n.leftWing=g,n.rightWing=-g,n.flap=m,n.bank=y,n.scale=r.span,n.phase=i,n}function Dn(t){let n=[],r=[],i=[],a=0,o=Object.fromEntries(Object.entries(xn.colors).map(([e,t])=>[e,new T(t)])),s=new A,c=new A,l=new A;function u(e,t,u,d){s.set(t[0]-e[0],t[1]-e[1],t[2]-e[2]),c.set(u[0]-e[0],u[1]-e[1],u[2]-e[2]),l.crossVectors(s,c).normalize();let f=o[d??(l.y>.3?`light`:l.y<-.3?`cool`:`warm`)];for(let o of[e,t,u])n.push(...o),r.push(f.r,f.g,f.b),i.push(a)}function d(e,t,n){let r=e.reduce((e,t)=>e.add(new A(...t)),new A).divideScalar(e.length);for(let[i,a,o]of t){let t=e[i],d=e[a],f=e[o];s.set(d[0]-t[0],d[1]-t[1],d[2]-t[2]),c.set(f[0]-t[0],f[1]-t[1],f[2]-t[2]),l.crossVectors(s,c),l.dot(new A(...t).sub(r))<0?u(t,f,d,n):u(t,d,f,n)}}function f(e,t,n,r=!1){let i=0;for(let t=0;t<e.length;t++){let n=e[t],r=e[(t+1)%e.length];i+=n[0]*r[1]-r[0]*n[1]}i>0&&e.reverse();let a=e.map(([e,r])=>[e,t+n/2,r]),o=e.map(([e,r])=>[e,t-n/2,r]);for(let t=1;t<e.length-1;t++)u(a[0],a[t],a[t+1],r&&t===2?`tip`:`warm`),u(o[0],o[t+1],o[t],`cool`);for(let t=0;t<e.length;t++){let n=(t+1)%e.length;u(a[t],o[t],o[n],`cool`),u(a[t],o[n],a[n],`cool`)}}if((t===`body`||t===`all`)&&(d([[0,.02,.245],[0,.02,-.225],[.085,.02,0],[-.085,.02,0],[0,.105,.005],[0,-.065,-.005]],[[4,0,2],[4,2,1],[4,1,3],[4,3,0],[5,2,0],[5,1,2],[5,3,1],[5,0,3]]),d([[0,.115,.28],[-.055,.025,.2],[.055,.025,.2],[0,.035,.37]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`warm`),d([[0,.04,.345],[-.025,.025,.32],[.025,.025,.32],[0,.025,.415]],[[0,1,2],[0,3,1],[0,2,3],[1,3,2]],`beak`),f([[0,-.17],[.075,-.34],[0,-.305],[-.075,-.34]],.015,.014)),t!==`body`)for(let e of t===`all`?[-1,1]:[t===`left`?-1:1])a=e,f([[0,.1],[e*.22,.035],[e*.425,-.095],[e*.3,-.19],[e*.05,-.08]],.025,.018,!0);let p=new M;return p.name=`courtyard-bird-${t}`,p.setAttribute(`position`,new e(n,3)),p.setAttribute(`color`,new e(r,3)),t===`all`&&p.setAttribute(`birdPart`,new e(i,1)),p.computeVertexNormals(),p.computeBoundingBox(),p.computeBoundingSphere(),p}function On(){let e=new w({color:16777215,vertexColors:!0,flatShading:!0,transparent:!0,depthTest:!0,depthWrite:!1,alphaTest:.012,toneMapped:!1});return e.name=`courtyard-birds`,e.customProgramCacheKey=()=>`courtyard-birds-hinge-v2`,e.color.multiplyScalar(1.5),e.onBeforeCompile=e=>{e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>
attribute float birdAlpha; attribute float birdWing; attribute float birdPart; varying float vBirdAlpha;`).replace(`#include <begin_vertex>`,`#include <begin_vertex>
vBirdAlpha = birdAlpha;
if (abs(birdPart) > 0.5) {
  float angle = -birdPart * birdWing;
  float c = cos(angle), s = sin(angle);
  transformed.xy = mat2(c, s, -s, c) * transformed.xy;
  transformed += vec3(birdPart * 0.075, 0.0, 0.015);
}`),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>
varying float vBirdAlpha;`).replace(`#include <alphatest_fragment>`,`diffuseColor.a *= vBirdAlpha;
#include <alphatest_fragment>`)},e}var kn=e=>{let t=Math.min(1,Math.max(0,e));return t*t*(3-2*t)};function An(e,t,n,r){let i=kn((Math.min(e-r.bounds.left,r.bounds.right-e,t-r.bounds.top,r.bounds.bottom-t)+n)/Math.max(1,n*2));for(let a of r.avoid){let o=Math.max(a.left-e,e-a.right,a.top-t,t-a.bottom)-n-r.margin;i*=kn(o/xn.fadePixels)}return i}function jn(){let e=new r;e.name=`courtyard-birds`;let t=Dn(`all`),n=On(),i=new d(new Float32Array(3),1).setUsage(O),a=new d(new Float32Array(3),1).setUsage(O);t.setAttribute(`birdAlpha`,i),t.setAttribute(`birdWing`,a);let o=new ue(t,n,3);o.name=`courtyard-birds-complete`,o.castShadow=!1,o.receiveShadow=!1,o.instanceMatrix.setUsage(O),o.boundingBox=new ie(new A(-11,3.8,-10),new A(11,6.2,11)),o.boundingSphere=o.boundingBox.getBoundingSphere(new j),e.add(o);let s=xn.routes.map(()=>Tn()),c=s.map(()=>({x:0,y:0,radius:0,alpha:0})),l=new A,u=new A,f=new h,p=NaN,m=NaN,g=``,_=!1;return{root:e,metadata:{birds:3,newGeometries:1,newTextures:0,maximumColorDrawCalls:1,extraPasses:0,castsShadows:!1,trianglesPerBird:t.getAttribute(`position`).count/3},update(e){if(!(_||e===p)){p=e;for(let t=0;t<s.length;t++)En(e,t,s[t])}},present(t,n){if(_||m===p&&g===n.key)return;m=p,g=n.key;let r=n.bounds.right-n.bounds.left,d=n.bounds.bottom-n.bounds.top,h=0;for(let e=0;e<s.length;e++){let p=s[e],m=c[e];l.copy(p.position).project(t),m.x=n.bounds.left+(l.x*.5+.5)*r,m.y=n.bounds.top+(.5-l.y*.5)*d,m.radius=p.scale*xn.bodyRadius*Math.abs(t.projectionMatrix.elements[5])*d*.5,m.alpha=l.z<-1||l.z>1?0:An(m.x,m.y,m.radius,n),m.alpha<xn.minimumAlpha||(f.compose(p.position,p.rotation,u.setScalar(p.scale)),o.setMatrixAt(h,f),i.setX(h,m.alpha),a.setX(h,p.leftWing),h++)}o.count=h,e.visible=h>0,h&&(o.instanceMatrix.needsUpdate=!0,i.needsUpdate=!0,a.needsUpdate=!0)},snapshot(){return{time:p,visible:o.count,poses:s.map((e,t)=>({id:t,position:e.position.toArray(),rotation:e.rotation.toArray(),leftWing:e.leftWing,rightWing:e.rightWing,flap:e.flap,bank:e.bank,scale:e.scale,speed:e.speed,phase:e.phase,screen:{...c[t]}}))}},dispose(){_||(_=!0,o.dispose(),t.dispose(),n.dispose(),e.removeFromParent(),e.clear())}}}function Mn(e={},t=`legacy`,n=`legacy`,r=!1,i=!1){let a=be(e),o=gn(r&&a.options.enabled,a.time.value),c=bn(o),l=new se;l.background=new T(N.grassBase);let u=new ne;u.position.set(...P.camera.position),u.lookAt(...P.camera.target),u.near=P.camera.near,u.far=P.camera.far;let d=new ce(P.ground.size,P.ground.size),f=Oe(a),p=new m(d,f);p.name=`courtyard-ground`,p.rotation.x=-Math.PI/2,p.receiveShadow=!0,l.add(p);let h=Be(),g=ht(h);l.add(g.root);let _;if(t===`refined`)try{_=un(l,h)}catch(e){console.warn(`Pool finish unavailable; original fountain retained.`,e)}let v=on(h,n);l.add(v.root);let y=new s(N.highlight,N.stoneShade,F.fill.intensity);y.name=`courtyard-fill`;let b=new le(N.highlight,F.sun.intensity);b.name=`courtyard-sun`,b.position.set(...F.sun.position),b.castShadow=F.shadows.enabled;let x=F.shadows;b.shadow.mapSize.setScalar(x.mapSize),b.shadow.camera.left=-x.extent,b.shadow.camera.right=x.extent,b.shadow.camera.top=x.extent,b.shadow.camera.bottom=-x.extent,b.shadow.camera.near=x.near,b.shadow.camera.far=x.far,b.shadow.bias=x.bias,b.shadow.normalBias=x.normalBias,b.shadow.radius=x.radius,l.add(y,b,b.target);let S=P.camera.viewHeight,C=1;function w(e){C=e;let t=S/2;u.left=-t*e,u.right=t*e,u.top=t,u.bottom=-t,u.updateProjectionMatrix()}w(1),u.updateMatrixWorld(!0);let E=Et(u,a);l.add(E.root);let D=a.options.enabled&&a.options.petals?sn():void 0;D&&(D.update(a.time.value),l.add(D.mesh)),c.bind(l);let O;if(i&&a.options.enabled)try{O=jn(),O.update(a.time.value),l.add(O.root)}catch(e){console.warn(`Birds unavailable; original courtyard retained.`,e)}let k=!1;return{scene:l,camera:u,setAspect:w,setViewHeight(e){if(!Number.isFinite(e)||e<=0)throw RangeError(`Camera view height must be positive.`);e!==S&&(S=e,w(C))},update(e){v.update(e),a.time.value=e,o.update(e),O?.update(e),D?.update(e)},waterState:h,fountainStyle:_?`refined`:t===`refined`?`fallback`:`legacy`,fountainMetadata:_?.metadata,orbStyle:v.root.userData.orbStyle??(n===`legacy`?`legacy`:`fallback`),orbMetadata:v.root.userData.orbMetadata,environmentState:a,cloudShadows:c,birds:O,dispose(){k||(k=!0,c.dispose(),O?.dispose(),d.dispose(),f.dispose(),_?.dispose(),g.dispose(),E.dispose(),v.dispose(),D?.dispose(),b.shadow.dispose(),l.clear())}}}var Nn=[320,384,448],Pn={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function Fn(e){let t=Number(e.get(`pixelSize`));return{resolution:Nn.some(e=>e===t)?t:Pn.resolution,finish:e.get(`finish`)===`soft`?`soft`:Pn.finish,storage:`auto`}}function In(n,r){let o=r.storage!==`byte`&&n.extensions.has(`EXT_color_buffer_float`),s=new l(1,1,{type:o?a:f,minFilter:te,magFilter:te,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});s.texture.colorSpace=o?i:x,s.texture.name=`courtyard-pixel-scene`;let c=new M;c.setAttribute(`position`,new e([-1,-1,0,3,-1,0,-1,3,0],3)),c.setAttribute(`uv`,new e([0,0,2,0,0,2],2));let u=Pn.finishes[r.finish],d=new S({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:s.texture},uSampleSize:{value:new t(1,1)},uLevels:{value:u.levels},uDither:{value:u.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),p=new se,h=new ne(-1,1,1,-1,0,1),g=new m(c,d);g.frustumCulled=!1,p.add(g);let _=!1,v=0;function y(){s.dispose(),c.dispose(),d.dispose()}return{releaseGpuResources:y,resize(e,t){let n=Math.min(1,r.resolution/Math.max(e,t)),i=Math.max(1,Math.round(e*n)),a=Math.max(1,Math.round(t*n));(i!==s.width||a!==s.height)&&(s.setSize(i,a),d.uniforms.uSampleSize.value.set(i,a),v++)},render(e,t){n.setRenderTarget(s),n.render(e,t),n.setRenderTarget(null),n.render(p,h)},getInfo(){return{sampleWidth:s.width,sampleHeight:s.height,designResolution:r.resolution,finish:r.finish,storage:o?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:u.levels,dither:u.dither,allocations:v}},dispose(){_||(_=!0,y(),p.clear())}}}function Ln(e){let t=new Set,n=new Set,r=new Set;e.traverse(e=>{if(e instanceof m||e instanceof C){t.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])n.add(t)}e instanceof ue&&e.dispose(),e instanceof le&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of t)e.dispose();for(let e of n){for(let t of Object.values(e))t instanceof v&&r.add(t);if(e instanceof S)for(let t of Object.values(e.uniforms)){let e=Array.isArray(t.value)?t.value:[t.value];for(let t of e)t instanceof v&&r.add(t)}e.dispose()}for(let e of r)e.dispose()}function Rn(e,n,r,i=Fn(new URLSearchParams),a){let o=new de({antialias:!1,alpha:!1});o.outputColorSpace=x,o.toneMapping=0,o.shadowMap.enabled=!0,o.shadowMap.type=1,o.shadowMap.autoUpdate=!1,o.shadowMap.needsUpdate=!0,o.info.autoReset=!1;let s=In(o,i),c=new t,l=o.domElement;l.setAttribute(`role`,`img`),l.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(l);let u=n,d=!1,f=!1,p=!1,m=!1,h=!0,g,_,v,y=0,b=0,S=0,C=0;function w(){v!==void 0&&cancelAnimationFrame(v),v=void 0,y=0}function T(){d||f||m||h||!g||v!==void 0||y===0||(v=requestAnimationFrame(e=>{v=void 0,y--,d||f||m||h||(g?.(e),T())}))}function E(){d||f||m||h||!g||(y=Math.max(y,2),T())}function D(){let e=!d&&!f&&!m;(!e||h)&&w(),o.setAnimationLoop(e&&h&&g?g:null),e&&!h&&E()}function O(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||d)return;let n=Math.min(window.devicePixelRatio||1,ve.maxDevicePixelRatio),i=Math.max(1,Math.floor(t.width)),a=Math.max(1,Math.floor(t.height));(i!==b||a!==S||n!==C)&&(b=i,S=a,C=n,o.setPixelRatio(n),o.setSize(i,a,!1),o.getDrawingBufferSize(c),s.resize(c.x,c.y)),l.dataset.renderMode=u;let f=s.getInfo();l.dataset.sampleWidth=String(u===`pixel`?f.sampleWidth:c.x),l.dataset.sampleHeight=String(u===`pixel`?f.sampleHeight:c.y),l.dataset.pixelProfile=String(f.designResolution),l.dataset.finish=f.finish,r(t.width/t.height),E()}function k(t){t.preventDefault(),f=!0,p=!0,e.dataset.renderState=`context-lost`,D(),s.releaseGpuResources(),_&&Ln(_),a?.(`context-lost`)}function A(){f=!1,b=0,o.shadowMap.needsUpdate=!0,a?.(`restored`),O(),D()}l.addEventListener(`webglcontextlost`,k),l.addEventListener(`webglcontextrestored`,A);let ee=new ResizeObserver(O);ee.observe(e),window.addEventListener(`resize`,O);let j;function te(){j?.removeEventListener(`change`,M),j=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),j.addEventListener(`change`,M)}function M(){te(),O()}return te(),O(),{canvas:l,setMode(e){u=e,O()},setAnimating(e){h=e,D()},setSuspended(e){m!==e&&(m=e,D())},renderOnce(){g?.(performance.now()),E()},getStats(){return{geometries:o.info.memory.geometries,textures:o.info.memory.textures,programs:o.info.programs?.length??0,calls:o.info.render.calls,triangles:o.info.render.triangles,mode:u,outputWidth:o.domElement.width,outputHeight:o.domElement.height,pixel:u===`pixel`?s.getInfo():null}},start(t,n,r){_=t,g=i=>{d||f||m||(r?.(i),o.info.reset(),u===`pixel`?s.render(t,n):(o.setRenderTarget(null),o.render(t,n)),e.dataset.renderState=`ready`,p&&(p=!1,a?.(`ready`),E()))},D()},dispose(){d||(d=!0,w(),ee.disconnect(),window.removeEventListener(`resize`,O),j.removeEventListener(`change`,M),l.removeEventListener(`webglcontextlost`,k),l.removeEventListener(`webglcontextrestored`,A),o.setAnimationLoop(null),g=void 0,_=void 0,s.dispose(),o.dispose(),!o.getContext().isContextLost()&&o.extensions.has(`WEBGL_lose_context`)&&o.forceContextLoss(),l.remove())}}}function zn(e,t=z.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function Bn(e,t,n=!1,r={}){let i=window.matchMedia(`(prefers-reduced-motion: reduce)`),a=zn(t),o=n||r.retainReducedPause&&i.matches?!0:null,s=!1;function c(){return{playing:!document.hidden&&!(o??i.matches),hidden:document.hidden,reducedMotion:i.matches}}function l(){s||(a.resetTimestamp(),e(c()))}function u(){i.matches&&o!==!0&&(o=r.retainReducedPause?!0:null),l()}return document.addEventListener(`visibilitychange`,l),i.addEventListener(`change`,u),{get state(){return c()},get time(){return a.time},advance(e){return a.tick(e,c().playing)},resetTimestamp:a.resetTimestamp,toggle(){o=!(o??i.matches),l()},dispose(){s||(s=!0,document.removeEventListener(`visibilitychange`,l),i.removeEventListener(`change`,u))}}}export{fe as _,xn as a,z as c,P as d,_e as f,pe as g,me as h,Mn as i,ye as l,he as m,Rn as n,Je as o,ge as p,Fn as r,ze as s,Bn as t,ve as u};