# sakan · 创作庭院

成品版本 sakan-pool-final-8cbfe430。

1. 完整解压 ZIP。
2. 安装 Node.js 22.12 或更高版本。
3. Windows 双击 START-PREVIEW.cmd。也可在解压目录的终端运行下列命令。

    node scripts/preview-site.mjs --port 0

打开终端显示的本机 HTTP 地址。首页展示三根砌石柱、实体青苔和细化后的水潭。窄屏从「水潭」章节可以进入庭院现场。

安装 Node.js 后即可预览成品。将终端窗口留在运行状态，按 Ctrl+C 可停止服务。
