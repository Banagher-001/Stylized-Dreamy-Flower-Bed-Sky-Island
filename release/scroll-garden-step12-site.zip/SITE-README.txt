sakan / Step12 static courtyard candidate
Serve this directory over HTTP, at / or a real subdirectory ending in /.
Default: courtyard; ?tour=prototype: compatibility; ?tour=reference: old portfolio.
No Node application server, API keys or CDN required at runtime. Do not use file://.
Missing assets must return 404, never an index.html fallback.
Real personal films remain pending; design samples and early courtyard clip are labelled.
This archive has not been deployed or published.
