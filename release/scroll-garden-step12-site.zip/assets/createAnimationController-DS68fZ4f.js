import{Dn as e,En as t,F as n,I as r,J as i,L as a,O as o,P as s,Q as c,R as l,T as u,Tn as d,W as f,Y as p,_ as m,_n as h,an as g,at as _,cn as v,ct as y,dn as b,et as x,f as S,fn as C,it as w,k as T,kn as E,ln as D,lt as O,o as k,pn as A,q as j,r as M,rt as N,sn as P,u as ee,ut as F,w as I}from"./three-core-BKN-L1uq.js";import{t as L}from"./three-renderer-Dl1vNdEY.js";var R={grassBase:`#BEDB68`,grassLight:`#D1E581`,grassDark:`#9EBF56`,stoneLight:`#F3EAC4`,stoneSide:`#D5D5B8`,stoneShade:`#7095A1`,treeShadow:`#117958`,waterBase:`#B8D7E5`,waterShade:`#86AFC8`,waterDeep:`#356A91`,highlight:`#F8FCED`,flower:`#DBAAE9`,flowerLight:`#EDC7F0`,flowerShade:`#A67FB9`,flowerCenter:`#F2E4B0`,grassBlade:`#92B65B`,grassBladeLight:`#B9D473`,plantStem:`#7DA35B`,plantShade:`#266E53`},z={paper:`#F7F7EF`,ink:`#2E4336`,muted:`#58664F`,rule:`#DDE2D1`,surface:`#FFFFFF`};R.grassBase,R.stoneLight,R.stoneShade,R.treeShadow,R.waterBase,R.flower;var B=new URL(`courtyard-motion-7fR7fsF8.mp4`,import.meta.url).href,V=new URL(`courtyard-keyframe-00-Dnvt_afN.png`,import.meta.url).href,te=new URL(`courtyard-keyframe-03-BpIvPl5V.png`,import.meta.url).href,ne=new URL(`signal-garden-CbiDrnMk.webp`,import.meta.url).href,re=new URL(`liquid-form-Yl5oqdSL.webp`,import.meta.url).href,H={camera:{position:[4.5,23,16],target:[0,.45,0],viewHeight:11.3,near:.1,far:100},ground:{size:40}},ie={defaultMode:`pixel`,maxDevicePixelRatio:2},U={sun:{position:[8.5,11,-1],intensity:1},fill:{intensity:.75},shadows:{enabled:!0,mapSize:2048,extent:8,near:.5,far:32,bias:-1e-4,normalBias:.012,radius:1},treeShadows:{enabled:!0,edgeNoiseScale:3.2,edgeNoiseAmount:.22,edgeSoftness:.008,patches:[{center:[-6.1,-3.2],radius:[2.8,1.55],rotation:.08},{center:[-3.4,6],radius:[3.1,1.5],rotation:-.15},{center:[-4.6,4.4],radius:[1.2,1.4],rotation:.2}]}},W={bevel:.028,cornerCut:.042,colorVariation:.045,joints:{width:.038,recess:.045},column:{layerRatios:[1.07,.96,1.03,.94],layerSeeds:[11,29,47],layerChips:[0,.028,.052],baseBevel:.024,capBevel:.038,profiles:[{layers:[0,1,0,2],offsets:[-.012,.012,-.008,0],capCorner:2,capChip:.12},{layers:[1,2,0,1],offsets:[.008,-.01,.01,0],capCorner:1,capChip:.095},{layers:[2,0,1,0],offsets:[-.008,.012,-.008,0],capCorner:3,capChip:.145}]},fountain:{copingHeight:.14,jointWidth:.032,bevel:.024,chippedSegments:[1,5],chipSize:.1},wall:{bodyBlocks:3,capBlocks:2},path:{bevel:.014,cornerCut:.045,chippedSlabs:[1,4,6],chipSize:.065}},G={seed:52026,enabled:!0,rootHeight:.003,ground:{enabled:!0,macroScale:.48,macroStrength:.24,detailScale:17,detailStrength:.018,detailDensity:.16,quietCenter:[0,-5.4],quietRadius:[1.8,1.25]},grass:{count:240,gapCount:12,minHeight:.065,maxHeight:.14,clearance:.06,gapMinHeight:.105,gapMaxHeight:.13,gapWidthScale:.6},flowers:{count:144,minHeight:.085,maxHeight:.15,minDiameter:.085,maxDiameter:.125,clusters:[{center:[-4.2,-1.2],radius:.62},{center:[-.9,-4],radius:.58},{center:[3.3,-3.2],radius:.55},{center:[4.6,.9],radius:.58},{center:[-.5,3.5],radius:.6},{center:[-2.9,3.4],radius:.62},{center:[0,4.8],radius:.58},{center:[-3.1,.2],radius:.48},{center:[-4.1,-4.1],radius:.55},{center:[1.6,-5.2],radius:.52},{center:[-3.4,1.3],radius:.48},{center:[3.6,2.7],radius:.5}]},treeDetail:{enabled:!0,branchScale:2.2,leafScale:18,edgeBreakup:.12,gapStrength:1}},K={seed:82026,enabled:!0,wind:{direction:[1,.32],grassAngle:8*Math.PI/180,flowerAngle:6*Math.PI/180,gapAngle:2.5*Math.PI/180,periods:[5.8,4.4],gustPeriod:16},canopy:{period:10.5,secondaryPeriod:12,displacement:.045,holeShade:.025},petals:{enabled:!1,capacity:8,period:11,lifetime:6,drift:.16,minHeight:.07,maxHeight:.65}};function ae(e){return{enabled:e.get(`env`)!==`off`&&K.enabled,wind:e.get(`wind`)!==`off`,canopy:e.get(`canopy`)!==`off`,petals:e.get(`petals`)===`on`||K.petals.enabled}}var q={enabled:!0,seed:62026,initialTime:2,maxFrameDelta:.05,colors:{base:`#BED4DF`,deep:`#245B80`,shade:`#7FA3BF`,highlight:`#F2FAFC`,jet:`#82B0D1`},surface:{flowSpeed:.055,reflectionThreshold:.65,waveSpeed:.45,waveStrength:.24},jet:{emitterHeight:1.18,radius:.18,stemRadius:.055,pulse:.025},drops:{capacity:32,period:2,gravity:3,minVerticalSpeed:.7,maxVerticalSpeed:.9,minHorizontalSpeed:.95,maxHorizontalSpeed:1.1,minRadius:.014,maxRadius:.024},ripples:{capacity:8,lifetime:.65,speed:.3,strength:.58}};function oe(e={}){let t={...ae(new URLSearchParams),...e};return{options:t,time:{value:q.initialTime},wind:{value:t.enabled&&t.wind?1:0},canopy:{value:t.enabled&&t.canopy?1:0}}}function se(e,t){let n=Math.sin(e*12.9898+t*78.233+K.seed)*43758.5453;return e*.42+t*.29+(n-Math.floor(n)-.5)*.42}var ce=Math.hypot(...K.wind.direction),le=[K.wind.direction[0]/ce,K.wind.direction[1]/ce],J=e=>e.toFixed(10),ue=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentWind;
  attribute vec3 windRoot;
  attribute vec4 windShape; // height, maximum angle, position phase, rigid head
  const vec2 windDirection = vec2(${le.map(J).join(`,`)});
  float plantWindAngle(vec4 shape) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${J(K.wind.gustPeriod)} + shape.z * 0.23);
    return shape.y * gust * (0.78 * sin(6.28318530718 * uEnvironmentTime / ${J(K.wind.periods[0])} + shape.z)
      + 0.22 * sin(6.28318530718 * uEnvironmentTime / ${J(K.wind.periods[1])} + shape.z * 1.3));
  }
  vec3 rotatePlantWind(vec3 v, float angle) {
    float along = dot(v.xz, windDirection);
    float a2 = angle * angle;
    float c = 1.0 - a2 * (0.5 - a2 / 24.0 + a2 * a2 / 720.0);
    float s = angle * (1.0 - a2 / 6.0 + a2 * a2 / 120.0);
    vec2 horizontal = v.xz + windDirection * (along * (c - 1.0) + v.y * s);
    return vec3(horizontal.x, v.y * c - along * s, horizontal.y);
  }
  vec3 bendPlantWind(vec3 rest, vec3 root, vec4 shape) {
    float height = shape.x;
    float y = shape.w > 0.5 ? height : clamp(rest.y - root.y, 0.0, height);
    float turn = plantWindAngle(shape) * y / height;
    float t2 = turn * turn;
    // Angles are bounded to 8 degrees. These forms remain precise near still poses.
    float sinc = 1.0 - t2 / 6.0 + t2 * t2 / 120.0;
    float cosc = turn * (0.5 - t2 / 24.0 + t2 * t2 / 720.0);
    vec3 center = root + vec3(windDirection.x * y * cosc, y * sinc, windDirection.y * y * cosc);
    return center + rotatePlantWind(rest - root - vec3(0.0, y, 0.0), turn);
  }
  vec3 bendPlantWindNormal(vec3 rest, vec3 root, vec4 shape, vec3 normal) {
    float angle = plantWindAngle(shape);
    float y = shape.w > 0.5 ? shape.x : clamp(rest.y - root.y, 0.0, shape.x);
    // Inverse-transpose of the arc deformation, then rotate into its tangent.
    if (shape.w < 0.5) normal.y /= 1.0 - angle / shape.x * dot((rest - root).xz, windDirection);
    return rotatePlantWind(normal, angle * y / shape.x);
  }
`,de=`
  uniform float uEnvironmentTime;
  uniform float uEnvironmentCanopy;
  float environmentCanopyWave(vec2 p) {
    float gust = 0.68 + 0.32 * sin(6.28318530718 * uEnvironmentTime / ${J(K.wind.gustPeriod)} + dot(p, vec2(0.06, 0.04)));
    return uEnvironmentCanopy * gust * (
      0.76 * sin(6.28318530718 * uEnvironmentTime / ${J(K.canopy.period)} + dot(p, vec2(0.35, 0.11)))
      + 0.24 * sin(6.28318530718 * uEnvironmentTime / ${J(K.canopy.secondaryPeriod)} + dot(p, vec2(-0.12, 0.42))));
  }
`;function fe(e,t,n){e.uniforms.uEnvironmentTime=n.time,e.uniforms.uEnvironmentWind=n.wind,e.uniforms.uEnvironmentCanopy=n.canopy,t&&(e.vertexShader=e.vertexShader.replace(`#include <common>`,`#include <common>\n${ue}`).replace(`#include <beginnormal_vertex>`,`#include <beginnormal_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windNormal = windMatrix * (objectNormal / vec3(dot(windMatrix[0], windMatrix[0]), dot(windMatrix[1], windMatrix[1]), dot(windMatrix[2], windMatrix[2])));
            windNormal = bendPlantWindNormal((instanceMatrix * vec4(position, 1.0)).xyz, windRoot, windShape, windNormal);
            objectNormal = vec3(dot(windMatrix[0], windNormal), dot(windMatrix[1], windNormal), dot(windMatrix[2], windNormal));
          }
        #endif
      `).replace(`#include <begin_vertex>`,`#include <begin_vertex>
        #ifdef USE_INSTANCING
          if (uEnvironmentWind > 0.5) {
            mat3 windMatrix = mat3(instanceMatrix);
            vec3 windRest = (instanceMatrix * vec4(transformed, 1.0)).xyz;
            vec3 windDelta = bendPlantWind(windRest, windRoot, windShape) - windRest;
            transformed += vec3(dot(windMatrix[0], windDelta) / dot(windMatrix[0], windMatrix[0]),
              dot(windMatrix[1], windDelta) / dot(windMatrix[1], windMatrix[1]),
              dot(windMatrix[2], windDelta) / dot(windMatrix[2], windMatrix[2]));
          }
        #endif
      `)),e.fragmentShader=e.fragmentShader.replace(`#include <common>`,`#include <common>\n${de}`).replace(`float artCanopy(vec2 position) {`,`float artCanopy(vec2 position) {
      float environmentWave = environmentCanopyWave(position);`).replace(`distanceToCanopy = min(distanceToCanopy, d);`,`
      float edgeBand = smoothstep(0.84, 0.94, d) * (1.0 - smoothstep(1.14, 1.24, d));
      float distanceGradient = length(local / (canopyBounds.zw * canopyBounds.zw)) / max(length(local / canopyBounds.zw), 0.001);
      d += environmentWave * ${J(K.canopy.displacement)} * distanceGradient * edgeBand;
      distanceToCanopy = min(distanceToCanopy, d);`).replace(`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));`,`float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
       holes *= 1.0 - uEnvironmentCanopy * ${J(K.canopy.holeShade)} * (0.5 + 0.5 * environmentWave);`)}function Y(t,n,r={}){let i=new c,a=t===`foliage`||t===`flower`;i.name=`courtyard-${t}`,i.userData.artSurface=t;let o=n?.options.enabled&&(a||t===`ground`);return i.customProgramCacheKey=()=>`courtyard-art-${t}-v3${o?`-environment-v1`:``}`,i.onBeforeCompile=i=>{let s=U.treeShadows,c=G.ground,l=G.treeDetail;Object.assign(i.uniforms,{uArtSunAmount:{value:U.sun.intensity},uArtFillAmount:{value:U.fill.intensity},uArtStoneVariation:{value:W.colorVariation},uArtGrass:{value:new S(R.grassBase)},uArtGrassLight:{value:new S(R.grassLight)},uArtGrassDark:{value:new S(R.grassDark)},uArtGrassShadow:{value:new S(R.treeShadow)},uArtStoneTop:{value:new S(r.top??R.stoneLight)},uArtStoneSide:{value:new S(r.side??R.stoneSide)},uArtStoneShade:{value:new S(r.shade??R.stoneShade)},uArtWater:{value:new S(R.waterBase)},uArtWaterShade:{value:new S(R.waterShade)},uArtPlantShade:{value:new S(R.plantShade)},uArtFlowerShade:{value:new S(R.flowerShade)},uArtFlowerCenter:{value:new S(R.flowerCenter)},uArtGroundEnabled:{value:+!!c.enabled},uArtGroundScales:{value:new e(c.macroScale,c.macroStrength,c.detailScale,c.detailStrength)},uArtGroundDensity:{value:c.detailDensity},uArtQuietRegion:{value:new e(c.quietCenter[0],c.quietCenter[1],c.quietRadius[0],c.quietRadius[1])},uArtTreeDetailEnabled:{value:+!!l.enabled},uArtTreeDetail:{value:new e(l.branchScale,l.leafScale,l.edgeBreakup,l.gapStrength)},uArtTreesEnabled:{value:+!!s.enabled},uArtTreeNoiseScale:{value:s.edgeNoiseScale},uArtTreeNoiseAmount:{value:s.edgeNoiseAmount},uArtTreeSoftness:{value:s.edgeSoftness},uArtTreePatches:{value:s.patches.map(t=>new e(t.center[0],t.center[1],t.radius[0],t.radius[1]))},uArtTreeRotations:{value:s.patches.map(e=>e.rotation)}}),i.vertexShader=i.vertexShader.replace(`#include <common>`,`#include <common>\nvarying vec3 vArtWorldPosition;
        ${t===`stone`?`attribute float stoneTint; varying float vArtStoneTint;`:``}
        ${a?`attribute float plantPart; attribute float plantHeight; varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      `).replace(`#include <worldpos_vertex>`,`#include <worldpos_vertex>
        vec4 artPosition = vec4(transformed, 1.0);
        #ifdef USE_BATCHING
          artPosition = batchingMatrix * artPosition;
        #endif
        #ifdef USE_INSTANCING
          artPosition = instanceMatrix * artPosition;
        #endif
        vArtWorldPosition = (modelMatrix * artPosition).xyz;
        ${t===`stone`?`vArtStoneTint = stoneTint;`:``}
        ${a?`vArtPlantPart = plantPart; vArtPlantHeight = plantHeight;`:``}
      `);let u=`
      varying vec3 vArtWorldPosition;
      ${t===`stone`?`varying float vArtStoneTint; uniform float uArtStoneVariation;`:``}
      ${a?`varying float vArtPlantPart; varying float vArtPlantHeight;`:``}
      uniform float uArtSunAmount;
      uniform float uArtFillAmount;
      uniform vec3 uArtGrass;
      uniform vec3 uArtGrassLight;
      uniform vec3 uArtGrassDark;
      uniform vec3 uArtGrassShadow;
      uniform vec3 uArtStoneTop;
      uniform vec3 uArtStoneSide;
      uniform vec3 uArtStoneShade;
      uniform vec3 uArtWater;
      uniform vec3 uArtWaterShade;
      uniform vec3 uArtPlantShade;
      uniform vec3 uArtFlowerShade;
      uniform vec3 uArtFlowerCenter;
      uniform float uArtGroundEnabled;
      uniform vec4 uArtGroundScales;
      uniform float uArtGroundDensity;
      uniform vec4 uArtQuietRegion;
      uniform float uArtTreeDetailEnabled;
      uniform vec4 uArtTreeDetail;
      uniform float uArtTreesEnabled;
      uniform float uArtTreeNoiseScale;
      uniform float uArtTreeNoiseAmount;
      uniform float uArtTreeSoftness;
      uniform vec4 uArtTreePatches[${s.patches.length}];
      uniform float uArtTreeRotations[${s.patches.length}];

      float artHash(vec2 p) {
        return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
      }
      float artNoise(vec2 p) {
        vec2 cell = floor(p);
        vec2 f = fract(p);
        vec2 t = f * f * (3.0 - 2.0 * f);
        return mix(mix(artHash(cell), artHash(cell + vec2(1.0, 0.0)), t.x),
                   mix(artHash(cell + vec2(0.0, 1.0)), artHash(cell + vec2(1.0)), t.x), t.y);
      }
      float artCanopy(vec2 position) {
        float distanceToCanopy = 10.0;
        for (int i = 0; i < ${s.patches.length}; i++) {
          vec4 canopyBounds = uArtTreePatches[i];
          float c = cos(uArtTreeRotations[i]);
          float s = sin(uArtTreeRotations[i]);
          vec2 local = mat2(c, -s, s, c) * (position - canopyBounds.xy);
          float d = length(local / canopyBounds.zw);
          d += (artNoise(position * uArtTreeNoiseScale) - 0.5) * uArtTreeNoiseAmount;
          distanceToCanopy = min(distanceToCanopy, d);
        }
        float silhouette = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, distanceToCanopy);
        if (uArtTreeDetailEnabled < 0.5) return silhouette * uArtTreesEnabled;
        float branches = artNoise(position * uArtTreeDetail.x + vec2(8.3, 3.7));
        float leaves = artHash(floor(position * uArtTreeDetail.y));
        float brokenDistance = distanceToCanopy + (branches - 0.5) * uArtTreeDetail.z + (leaves - 0.5) * 0.06;
        float body = 1.0 - smoothstep(1.0 - uArtTreeSoftness, 1.0 + uArtTreeSoftness, brokenDistance);
        float holes = step(0.74, branches) * step(0.68, artNoise(position * 8.5));
        float edge = step(0.68, distanceToCanopy);
        float gaps = max(holes, edge * step(0.78, leaves) * step(0.44, branches)) * uArtTreeDetail.w;
        float fragments = (1.0 - body) * step(distanceToCanopy, 1.12)
          * step(0.76, leaves) * step(0.56, branches);
        return max(body * (1.0 - gaps), fragments) * uArtTreesEnabled;
      }
    `;i.fragmentShader=i.fragmentShader.replace(`#include <common>`,`#include <common>\n${u}`).replace(`#include <shadowmap_pars_fragment>`,`#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>`).replace(`#include <opaque_fragment>`,`${{ground:`
        float daylight = clamp(uArtSunAmount * 0.8 + uArtFillAmount * 0.2, 0.0, 1.0);
        vec3 sunlitGrass = mix(uArtGrassDark, uArtGrass, daylight);
        vec2 groundPosition = vArtWorldPosition.xz;
        float quiet = 1.0 - smoothstep(0.7, 1.2, length((groundPosition - uArtQuietRegion.xy) / uArtQuietRegion.zw));
        float macro = artNoise(groundPosition * uArtGroundScales.x + vec2(4.2, 7.3));
        vec3 groundVariation = mix(uArtGrassDark, uArtGrassLight, smoothstep(0.18, 0.86, macro));
        sunlitGrass = mix(sunlitGrass, groundVariation, uArtGroundScales.y * (1.0 - quiet * 0.65) * uArtGroundEnabled);
        vec2 detailCell = floor(groundPosition * uArtGroundScales.z);
        float speckle = step(1.0 - uArtGroundDensity, artHash(detailCell)) * (artHash(detailCell + vec2(3.2, 9.1)) * 2.0 - 1.0);
        sunlitGrass *= 1.0 + speckle * uArtGroundScales.w * (1.0 - quiet * 0.85) * uArtGroundEnabled;
        float occlusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        outgoingLight = mix(sunlitGrass, uArtGrassShadow, occlusion);
      `,stone:`
        vec3 worldNormal = inverseTransformDirection(normal, viewMatrix);
        float sunFacing = 0.0;
        #if NUM_DIR_LIGHTS > 0
          sunFacing = max(dot(normal, directionalLights[0].direction), 0.0);
        #endif
        float sunAmount = clamp(uArtSunAmount, 0.0, 1.0);
        float fillAmount = clamp(uArtFillAmount, 0.0, 1.0);
        vec3 coolFace = uArtStoneShade * mix(0.72, 1.0, fillAmount);
        vec3 sideFace = mix(coolFace, uArtStoneSide, smoothstep(0.02, 0.56, sunFacing) * sunAmount);
        vec3 topFace = mix(uArtStoneSide, uArtStoneTop, sunAmount);
        vec3 litStone = mix(sideFace, topFace, smoothstep(0.65, 0.95, worldNormal.y));
        vec3 shadedStone = mix(coolFace, litStone, 0.12 * fillAmount);
        outgoingLight = mix(shadedStone, litStone, getShadowMask());
        outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;
      `,water:`
        outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());
      `,foliage:`
        float plantOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litPlant = diffuseColor.rgb * mix(0.93, 1.0, clamp(vArtPlantHeight, 0.0, 1.0));
        outgoingLight = mix(litPlant, uArtPlantShade, plantOcclusion);
      `,flower:`
        float flowerOcclusion = max(1.0 - getShadowMask(), artCanopy(vArtWorldPosition.xz));
        vec3 litFlower = mix(diffuseColor.rgb, uArtFlowerCenter, vArtPlantPart);
        vec3 shadedFlower = mix(uArtFlowerShade, uArtFlowerCenter * 0.65, vArtPlantPart);
        outgoingLight = mix(litFlower, shadedFlower, flowerOcclusion);
      `}[t]}\n#include <opaque_fragment>`),o&&fe(i,a,n)},i}function pe(e){return Y(`ground`,e)}var X={fountain:{position:[.12,0,0],rotationY:.12,baseRadius:2.76,baseHeight:.12,outerRadius:2.65,innerRadius:2.28,rimHeight:.46,waterHeight:.32,pedestalFootSize:.9,pedestalFootHeight:.12,pedestalSize:.64,pedestalHeight:.62,pedestalCapSize:.82,pedestalCapHeight:.1},columnShape:{baseWidth:1.04,baseDepth:1.08,baseHeight:.18,shaftWidth:.72,shaftDepth:.78,shaftHeight:3.05,capWidth:1.02,capDepth:1.04,capHeight:.24},columns:[{name:`columnUpperLeft`,position:[-2.34,0,-2.9],rotationY:0},{name:`columnRight`,position:[4.41,0,-1],rotationY:0},{name:`columnLower`,position:[2.96,0,5.09],rotationY:0}],wall:{position:[-4.25,0,2.25],rotationY:-.5,length:4.1,depth:.38,height:.55,baseHeight:.12,baseDepth:.62,capHeight:.1,capDepth:.48,endSize:.64,endHeight:.25},path:{position:[5.33,0,1.38],rotationY:0,columns:4,rows:2,stepX:.74,stepZ:.63,slabWidth:.63,slabDepth:.52,slabHeight:.09}},Z=1e-7;function me(e){let t=[];for(let n of e)t.some(e=>e.distanceToSquared(n)<Z*Z)||t.push(n);return t}function he(e,n,r){let i=[],a=[];for(let t of e){let e=[];for(let i=0;i<t.length;i++){let o=t[i],s=t[(i+1)%t.length],c=n.dot(o)-r,l=n.dot(s)-r;if(c<=Z&&e.push(o),c<-1e-7&&l>Z||c>Z&&l<-1e-7){let t=o.clone().lerp(s,c/(c-l));e.push(t),a.push(t)}else Math.abs(c)<=Z&&a.push(o)}let o=me(e);o.length>=3&&i.push(o)}let o=me(a);if(o.length>=3){let e=o.reduce((e,t)=>e.add(t),new t).divideScalar(o.length),r=Math.abs(n.y)<.9?new t(0,1,0):new t(1,0,0),a=n.clone().cross(r).normalize(),s=n.clone().cross(a).normalize();o.sort((t,n)=>{let r=t.clone().sub(e),i=n.clone().sub(e);return Math.atan2(r.dot(s),r.dot(a))-Math.atan2(i.dot(s),i.dot(a))}),i.push(o)}return i}function ge(e,t){let n=e.getAttribute(`position`),r=Math.sin(t*12.9898+.73)*.65,i=new Float32Array(n.count);for(let e=0;e<n.count;e++)i[e]=r+Math.sin(n.getX(e)*1.6+n.getZ(e)*2.3+t)*.25;return e.setAttribute(`stoneTint`,new T(i,1)),e}function _e(e,n,r){if(e.length<3||n<=0)throw Error(`Stone prism needs a polygon and positive height.`);let i=e.map(([e,t])=>[e,t]);i.reduce((e,t,n)=>{let r=i[(n+1)%i.length];return e+t[0]*r[1]-r[0]*t[1]},0)>0&&(i=i.reverse());let a=n/2,o=i.map(([e,n])=>new t(e,a,n)),s=i.map(([e,n])=>new t(e,-a,n)),c=[o,[...s].reverse()],l=[];for(let e=0;e<i.length;e++){let n=(e+1)%i.length,r=s[e],a=s[n];c.push([r,a,o[n],o[e]]);let u=a.clone().sub(r).cross(new t(0,1,0)).normalize();l.push({normal:u,distance:u.dot(r)})}let u=Math.min(r.bevel,n*.2);for(let e=0;e<l.length;e++){let n=l[e];for(let e of[-1,1]){let r=n.normal.clone().add(new t(0,e,0)),i=(n.distance+a-u)/r.length();c=he(c,r.normalize(),i)}let i=l[(e+l.length-1)%l.length],o=i.normal.clone().add(n.normal),s=(i.distance+n.distance-r.cornerCut)/o.length();c=he(c,o.normalize(),s)}if(r.chipSize&&r.chipSize>0){let e=(r.chipCorner??0)%l.length,n=l[(e+l.length-1)%l.length],i=l[e],o=n.normal.clone().add(i.normal).add(new t(0,1,0)),s=(n.distance+i.distance+a-r.chipSize)/o.length();c=he(c,o.normalize(),s)}let d=[],f=[];for(let e of c){let n=e.reduce((e,t)=>e.add(t),new t).divideScalar(e.length),r=new t;for(let t=0;t<e.length;t++)r.add(e[t].clone().sub(n).cross(e[(t+1)%e.length].clone().sub(n)));if(!(r.lengthSq()<Z*Z)){r.normalize();for(let t=0;t<e.length;t++){let i=e[t],a=e[(t+1)%e.length];if(!(i.clone().sub(n).cross(a.clone().sub(n)).lengthSq()<Z*Z))for(let e of[n,i,a])d.push(e.x,e.y,e.z),f.push(r.x,r.y,r.z)}}}let p=new k;return p.setAttribute(`position`,new T(d,3)),p.setAttribute(`normal`,new T(f,3)),ge(p,r.seed),p.computeBoundingBox(),p.computeBoundingSphere(),p.userData.stoneSolid=!0,p}function ve(e,t,n,r){let i=e/2,a=n/2;return _e([[-i,-a],[-i,a],[i,a],[i,-a]],t,r)}function ye(e){return Y(`stone`,void 0,e)}function be(){return{time:{value:q.initialTime},impacts:{value:Array.from({length:q.ripples.capacity},()=>new e(0,0,0,0))}}}function xe(t=be(),n=`surface`){let r=Y(`water`);r.name=`courtyard-water-${n}`,r.flatShading=n===`jet`,r.userData.waterKind=n,r.customProgramCacheKey=()=>`courtyard-water-${n}-v1`;let i=r.onBeforeCompile.bind(r);return r.onBeforeCompile=(r,a)=>{i(r,a);let o=X.fountain;Object.assign(r.uniforms,{uWaterTime:t.time,uWaterImpacts:t.impacts,uWaterEnabled:{value:+!!q.enabled},uWaterBase:{value:new S(q.colors.base)},uWaterDeep:{value:new S(q.colors.deep)},uWaterShade:{value:new S(q.colors.shade)},uWaterWhite:{value:new S(q.colors.highlight)},uWaterJet:{value:new S(q.colors.jet)},uWaterOrigin:{value:new e(o.position[0],o.position[2],Math.cos(o.rotationY),Math.sin(o.rotationY))},uWaterSurface:{value:new e(q.surface.flowSpeed,q.surface.reflectionThreshold,q.surface.waveSpeed,q.surface.waveStrength)},uWaterRipple:{value:new e(q.ripples.lifetime,q.ripples.speed,q.ripples.strength,o.innerRadius*Math.cos(Math.PI/8))}});let s=`
      uniform float uWaterTime;
      uniform float uWaterEnabled;
      uniform vec4 uWaterImpacts[${q.ripples.capacity}];
      uniform vec3 uWaterBase;
      uniform vec3 uWaterDeep;
      uniform vec3 uWaterShade;
      uniform vec3 uWaterWhite;
      uniform vec3 uWaterJet;
      uniform vec4 uWaterOrigin;
      uniform vec4 uWaterSurface;
      uniform vec4 uWaterRipple;
    `,c=`
      vec2 delta = vArtWorldPosition.xz - uWaterOrigin.xy;
      vec2 p = vec2(uWaterOrigin.z * delta.x - uWaterOrigin.w * delta.y,
                    uWaterOrigin.w * delta.x + uWaterOrigin.z * delta.y);
      float t = uWaterTime;
      vec2 drift = vec2(t * uWaterSurface.x, -t * uWaterSurface.x * 0.5);
      float warp = artNoise(p * 4.7 + vec2(-t * 0.022, t * 0.04));
      float field = artNoise(p * 1.8 + vec2(3.1, 6.4) + drift * 0.6);
      float leftBias = 1.0 - smoothstep(-1.6, 0.8, p.x);
      float brokenEdge = (artNoise(p * 22.0 + drift * 2.0) - 0.5) * 0.07;
      float reflection = smoothstep(uWaterSurface.y, uWaterSurface.y + 0.045, field * 0.88 + warp * 0.12 + leftBias * 0.12 + brokenEdge);
      float distanceFromCenter = length(p);
      float wave = smoothstep(0.94, 0.995, sin(distanceFromCenter * 14.0 - t * uWaterSurface.z * 14.0 + warp * 0.5));
      wave *= smoothstep(0.25, 0.5, distanceFromCenter) * (1.0 - smoothstep(1.2, 1.85, distanceFromCenter)) * uWaterSurface.w;
      wave *= smoothstep(0.24, 0.75, artNoise(p * 8.5 + drift));
      float glint = smoothstep(0.80, 0.94, artNoise(p * 9.0 + drift * 1.2))
        * smoothstep(0.72, 0.96, sin((p.x + p.y * 0.7) * 18.0 - t * 1.3 + warp * 7.0)) * 0.8;
      float impactRings = 0.0;
      for (int i = 0; i < ${q.ripples.capacity}; i++) {
        vec4 impact = uWaterImpacts[i];
        float age = impact.z;
        float radius = 0.025 + age * uWaterRipple.y;
        float ring = 1.0 - smoothstep(0.012, 0.022, abs(length(p - impact.xy) - radius));
        float fade = pow(clamp(1.0 - age / uWaterRipple.x, 0.0, 1.0), 2.0);
        impactRings = max(impactRings, ring * fade * impact.w * uWaterRipple.z);
      }
      float wallDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + 0.5) * PI / 4.0;
        wallDistance = min(wallDistance, uWaterRipple.w - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float edgeFoam = (1.0 - smoothstep(0.025, 0.07, wallDistance))
        * smoothstep(0.48, 0.72, artNoise(p * 14.0 + drift)) * 0.4;
      float whiteAmount = clamp(max(max(glint, wave), max(impactRings, edgeFoam)), 0.0, 0.85);
      vec3 litWater = mix(uWaterBase, uWaterDeep, reflection);
      litWater = mix(litWater, uWaterWhite, whiteAmount);
      vec3 shadedWater = mix(uWaterShade, uWaterDeep * 0.8, reflection * 0.8);
      shadedWater = mix(shadedWater, uWaterWhite, whiteAmount * 0.18);
      vec3 dynamicWater = mix(shadedWater, litWater, getShadowMask());
      outgoingLight = mix(mix(uArtWaterShade, uArtWater, getShadowMask()), dynamicWater, uWaterEnabled);
    `,l=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!r.fragmentShader.includes(l))throw Error(`Water shader extension anchor changed.`);r.fragmentShader=r.fragmentShader.replace(`void main() {`,`${s}\nvoid main() {`).replace(l,n===`surface`?c:`
      vec3 waterNormal = inverseTransformDirection(normal, viewMatrix);
      float lightFace = smoothstep(-0.2, 0.8, waterNormal.y);
      float crownSparkle = pow(max(waterNormal.y, 0.0), 14.0) * 0.25;
      vec3 litJet = mix(uWaterJet, uWaterWhite, lightFace * 0.4 + crownSparkle);
      outgoingLight = mix(uWaterShade, litJet, getShadowMask());
    `)},r}function Se(e){let t=new s;t.name=`courtyard-blockout`;let n=new Set;function r(e){return n.add(e),e}let a=new Map,c=ye(),l=xe(e);function u(e,t,n,o,s,l,u=0,d=0,f={}){let p={bevel:W.bevel,cornerCut:W.cornerCut,seed:11,...f},m=JSON.stringify([n,o,s,p]),h=a.get(m);h||(h=r(ve(n,o,s,p)),a.set(m,h));let g=new i(h,c);return g.name=t,g.position.set(u,l+o/2,d),g.castShadow=!0,g.receiveShadow=!0,e.add(g),g}let d=X.fountain,f=new s;f.name=`fountain`,f.position.set(...d.position),f.rotation.y=d.rotationY,t.add(f);let p=new i(r(_e(Array.from({length:8},(e,t)=>[Math.cos(t*Math.PI/4)*d.baseRadius,-Math.sin(t*Math.PI/4)*d.baseRadius]),d.baseHeight,{bevel:.018,cornerCut:.025,seed:11})),c);p.name=`fountain-base`,p.position.y=d.baseHeight/2,p.castShadow=!0,p.receiveShadow=!0,f.add(p);let m=new D,h=new _;for(let e=0;e<8;e++){let t=e*Math.PI/4,n=-t,r=Math.cos(t)*d.outerRadius,i=Math.sin(t)*d.outerRadius,a=Math.cos(n)*d.innerRadius,o=Math.sin(n)*d.innerRadius;e===0?(m.moveTo(r,i),h.moveTo(a,o)):(m.lineTo(r,i),h.lineTo(a,o))}m.closePath(),h.closePath(),m.holes.push(h);let g=new s;g.name=`fountain-rim`,g.position.y=d.baseHeight,f.add(g);let v=W.fountain,y=d.rimHeight-v.copingHeight,b=new i(r(ge(new o(m,{depth:y,bevelEnabled:!1,steps:1,curveSegments:1}),11)),c);b.name=`fountain-rim-wall`,b.rotation.x=-Math.PI/2,b.castShadow=!0,b.receiveShadow=!0,g.add(b);function x(e){let t=Math.cos(Math.PI/4)*e,n=-Math.sin(Math.PI/4)*e,r=v.jointWidth/(2*Math.hypot(t-e,n));return[[e+(t-e)*r,n*r],[t+(e-t)*r,n*(1-r)]]}let[S,C]=x(d.outerRadius),[w,T]=x(d.innerRadius),E=new Map;for(let e=0;e<8;e++){let t=v.chippedSegments.some(t=>t===e),n=t?`chip-${e%2}`:`plain-${e%2}`,a=E.get(n);a||(a=r(_e([S,C,T,w],v.copingHeight,{bevel:v.bevel,cornerCut:.025,seed:29+e%2,chipSize:t?v.chipSize:0,chipCorner:e%2})),E.set(n,a));let o=new i(a,c);o.name=`fountain-coping-${e}`,o.position.y=y+v.copingHeight/2,o.rotation.y=e*Math.PI/4,o.castShadow=!0,o.receiveShadow=!0,g.add(o)}let O=new i(r(new ee(d.innerRadius-.008,8)),l);O.name=`fountain-water`,O.rotation.x=-Math.PI/2,O.position.y=d.waterHeight,O.receiveShadow=!0,f.add(O),u(f,`fountain-pedestal-foot`,d.pedestalFootSize,d.pedestalFootHeight,d.pedestalFootSize,d.baseHeight);let k=d.baseHeight+d.pedestalFootHeight;u(f,`fountain-pedestal`,d.pedestalSize,d.pedestalHeight,d.pedestalSize,k),u(f,`fountain-pedestal-cap`,d.pedestalCapSize,d.pedestalCapHeight,d.pedestalCapSize,k+d.pedestalHeight,0,0,{bevel:.016,chipSize:.06,chipCorner:2,seed:29});let A=X.columnShape;for(let[e,n]of X.columns.entries()){let r=new s;r.name=n.name;let[i,a,o]=n.position;r.position.set(i,a,o),r.rotation.y=n.rotationY;let c=W.column,l=c.profiles[e];u(r,`${n.name}-base`,A.baseWidth,A.baseHeight,A.baseDepth,0,0,0,{bevel:c.baseBevel,chipSize:.04,chipCorner:e%2,seed:29});let d=new s;d.name=`${n.name}-shaft`,r.add(d);let f=W.joints.width,p=c.layerRatios,m=A.shaftHeight-f*(p.length-1),h=p.reduce((e,t)=>e+t,0),g=A.baseHeight;for(let e=0;e<p.length;e++){let t=m*p[e]/h,r=l.layers[e];u(d,`${n.name}-block-${e}`,A.shaftWidth,t,A.shaftDepth,g,l.offsets[e],0,{seed:c.layerSeeds[r],chipSize:c.layerChips[r],chipCorner:r}),g+=t,e<p.length-1&&(u(d,`${n.name}-joint-${e}`,A.shaftWidth-W.joints.recess*2,f,A.shaftDepth-W.joints.recess*2,g,0,0,{bevel:0,cornerCut:0,seed:47}),g+=f)}u(r,`${n.name}-cap`,A.capWidth,A.capHeight,A.capDepth,A.baseHeight+A.shaftHeight,0,0,{bevel:c.capBevel,chipSize:l.capChip,chipCorner:l.capCorner,seed:47+e}),t.add(r)}let j=X.wall,M=new s;M.name=`wallLeft`,M.position.set(...j.position),M.rotation.y=j.rotationY,u(M,`wallLeft-base`,j.length+j.endSize,j.baseHeight,j.baseDepth,0);let N=new s;N.name=`wallLeft-body`,M.add(N);let P=W.wall.bodyBlocks,F=W.joints.width,I=(j.length-(P-1)*F)/P;for(let e=0;e<P;e++){let t=-j.length/2+I/2+e*(I+F);u(N,`wallLeft-body-${e}`,I,j.height,j.depth,j.baseHeight,t,0,{seed:11+e*18,chipSize:e===P-1?.075:0,chipCorner:2}),e<P-1&&u(N,`wallLeft-body-joint-${e}`,F,j.height,j.depth-W.joints.recess*2,j.baseHeight,t+I/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}let L=new s;L.name=`wallLeft-cap`,M.add(L);let R=W.wall.capBlocks,z=(j.length-(R-1)*F)/R;for(let e=0;e<R;e++){let t=-j.length/2+z/2+e*(z+F);u(L,`wallLeft-cap-${e}`,z,j.capHeight,j.capDepth,j.baseHeight+j.height,t,0,{bevel:.018,seed:29+e*18,chipSize:e===R-1?.065:0,chipCorner:2}),e<R-1&&u(L,`wallLeft-cap-joint-${e}`,F,j.capHeight*.65,j.capDepth-W.joints.recess*2,j.baseHeight+j.height,t+z/2+F/2,0,{bevel:0,cornerCut:0,seed:47})}u(M,`wallLeft-end`,j.endSize,j.endHeight,j.endSize,j.baseHeight,j.length/2,0,{chipSize:.095,chipCorner:2,seed:29}),t.add(M);let B=X.path,V=new s;V.name=`pathRight`,V.position.set(...B.position),V.rotation.y=B.rotationY;for(let e=0;e<B.rows;e++)for(let t=0;t<B.columns;t++)u(V,`pathRight-slab-${e}-${t}`,B.slabWidth,B.slabHeight,B.slabDepth,0,(t-(B.columns-1)/2)*B.stepX,(e-(B.rows-1)/2)*B.stepZ,{bevel:W.path.bevel,cornerCut:W.path.cornerCut,seed:11+(e*B.columns+t)%3*18,chipSize:W.path.chippedSlabs.some(n=>n===e*B.columns+t)?W.path.chipSize:0,chipCorner:(e*B.columns+t)%4});t.add(V);let te=!1;return{root:t,dispose(){if(!te){te=!0,t.removeFromParent(),t.clear();for(let e of n)e.dispose();c.dispose(),l.dispose()}}}}function Ce(e,t,n){let r=new k;return r.setAttribute(`position`,new T(e,3)),r.setAttribute(`plantPart`,new T(t,1)),r.setAttribute(`plantHeight`,new T(n,1)),r.computeVertexNormals(),r.computeBoundingBox(),r.computeBoundingSphere(),r}function we(){let e=[],t=[],n=[];function r(r,i,a,o=0){for(let s of[r,i,a])e.push(...s),t.push(o),n.push(s[1])}return{triangle:r,finish:()=>Ce(e,t,n)}}function Te(){let e=we();for(let t=0;t<3;t++){let n=t*Math.PI*2/3,r=Math.cos(n),i=Math.sin(n),a=t===0?1:.72+t*.08,o=(e,t,n)=>[r*e-i*n,t,i*e+r*n],s=o(-.12,0,0),c=o(.12,0,0),l=o(.08,a*.6,.1),u=o(.23,a,.18);e.triangle(s,c,l),e.triangle(s,l,u)}return e.finish()}function Ee(){let e=we();return e.triangle([-.025,0,0],[.025,0,0],[.025,1,0]),e.triangle([-.025,0,0],[.025,1,0],[-.025,1,0]),e.triangle([0,0,-.025],[0,0,.025],[0,1,.025]),e.triangle([0,0,-.025],[0,1,.025],[0,1,-.025]),e.triangle([0,.4,0],[.18,.65,.04],[.04,.63,-.04]),e.triangle([0,.56,0],[-.17,.77,-.02],[-.04,.76,.05]),e.finish()}function De(e){let t=we();for(let n=0;n<e;n++){let r=n*Math.PI*2/e,i=(e,t,n)=>[Math.cos(r+t)*e,n,Math.sin(r+t)*e],a=i(.07,0,0),o=i(.33,-.48,.035),s=i(.5,0,.08),c=i(.33,.48,.035);t.triangle(a,s,o),t.triangle(a,c,s)}let n=[-.085,.05,0],r=[.085,.05,0];return t.triangle(n,[0,.05,.085],r,1),t.triangle(n,r,[0,.05,-.085],1),t.finish()}function Oe(e,t){let n=Y(e,t);return n.side=2,n}function ke(e,t,n,r=.035){let i=X.fountain,a=Math.cos(i.rotationY),o=Math.sin(i.rotationY),s=e-i.position[0],c=t-i.position[2],l=a*s-o*c,u=o*s+a*c,d=!0;for(let e=0;e<8;e++){let t=(e+.5)*Math.PI/4;l*Math.cos(t)-u*Math.sin(t)>i.baseRadius*Math.cos(Math.PI/8)+n+r&&(d=!1)}if(d)return!1;function f(e,t,i,a,o,s,c){let l=Math.cos(c),u=Math.sin(c),d=e-i,f=t-a;return Math.abs(l*d-u*f)<o/2+n+r&&Math.abs(u*d+l*f)<s/2+n+r}let p=X.columnShape;for(let n of X.columns)if(f(e,t,n.position[0],n.position[2],p.baseWidth,p.baseDepth,n.rotationY))return!1;let m=X.wall;if(f(e,t,m.position[0],m.position[2],m.length+m.endSize,Math.max(m.baseDepth,m.endSize),m.rotationY))return!1;let h=X.path;for(let n=0;n<h.rows;n++)for(let r=0;r<h.columns;r++){let i=(r-(h.columns-1)/2)*h.stepX,a=(n-(h.rows-1)/2)*h.stepZ;if(f(e,t,h.position[0]+Math.cos(h.rotationY)*i+Math.sin(h.rotationY)*a,h.position[2]-Math.sin(h.rotationY)*i+Math.cos(h.rotationY)*a,h.slabWidth,h.slabDepth,h.rotationY))return!1}return!0}function Ae(e,n){let r=new s;r.name=`courtyard-vegetation`;let i=G.seed;function o(){i+=1831565813;let e=Math.imul(i^i>>>15,1|i);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let c=(e,t)=>e+(t-e)*o();function u(n,r){let i=new t(n,0,r).project(e);return Math.abs(i.x)<.98&&Math.abs(i.y)<.98}function d(e,t){let n=G.ground;return Math.hypot((e-n.quietCenter[0])/n.quietRadius[0],(t-n.quietCenter[1])/n.quietRadius[1])<1}let f=[],p=[];if(G.enabled){for(let e=0;f.length<G.grass.count&&e<G.grass.count*120;e++){let e,t;if(o()<.48){let n=G.flowers.clusters[Math.floor(o()*G.flowers.clusters.length)],r=o()*Math.PI*2,i=Math.sqrt(o())*(n.radius+.5);e=n.center[0]+Math.cos(r)*i,t=n.center[1]+Math.sin(r)*i}else e=c(-7.5,7.4),t=c(-8.7,8.4);!u(e,t)||!ke(e,t,G.grass.clearance)||d(e,t)&&o()<.9||f.push({x:e,z:t,height:c(G.grass.minHeight,G.grass.maxHeight),diameter:0,rotation:o()*Math.PI*2,color:o(),radius:G.grass.clearance,gap:!1})}for(let e=0;p.length<G.flowers.count&&e<G.flowers.count*120;e++){let e=G.flowers.clusters[Math.floor(o()*G.flowers.clusters.length)],t=o()*Math.PI*2,n=o()**.65*e.radius,r=e.center[0]+Math.cos(t)*n,i=e.center[1]+Math.sin(t)*n,a=c(G.flowers.minDiameter,G.flowers.maxDiameter),s=a*.55+.01;u(r,i)&&!d(r,i)&&ke(r,i,s)&&(p.some(e=>Math.hypot(e.x-r,e.z-i)<(e.radius+s)*.85)||p.push({x:r,z:i,height:c(G.flowers.minHeight,G.flowers.maxHeight),diameter:a,rotation:o()*Math.PI*2,color:o(),radius:s,gap:!1}))}if(f.length!==G.grass.count||p.length!==G.flowers.count)throw Error(`Vegetation regions cannot fit the requested counts.`);let e=X.path,t=[];for(let n=0;n<e.rows;n++)for(let r=0;r<e.columns-1;r++)t.push([(r-(e.columns-2)/2)*e.stepX,(n-(e.rows-1)/2)*e.stepZ]);for(let n=0;n<e.columns;n++)t.push([(n-(e.columns-1)/2)*e.stepX,0]);t.push([-e.stepX,0],[e.stepX,0]);for(let[n,r]of t.slice(0,G.grass.gapCount)){let t=e.position[0]+Math.cos(e.rotationY)*n+Math.sin(e.rotationY)*r+c(-.006,.006),i=e.position[2]-Math.sin(e.rotationY)*n+Math.cos(e.rotationY)*r+c(-.006,.006);if(!ke(t,i,.023,.008))throw Error(`Paving gap vegetation intersects stone.`);f.push({x:t,z:i,height:c(G.grass.gapMinHeight,G.grass.gapMaxHeight),diameter:0,rotation:o()*Math.PI*2,color:o(),radius:.023,gap:!0})}}let m=[],h=[],g=[];if(G.enabled){let e=Oe(`foliage`,n),i=Oe(`flower`,n);h.push(e,i);let o=Te(),s=Ee(),c=De(4),u=De(5);m.push(o,s,c,u);function d(e,i,o,s,c){let u=new l(i,o,s.length);u.name=e,u.castShadow=!1,u.receiveShadow=!0;let d=new j,f=new F,p=new t(0,1,0),m=new S(c===`flower`?R.flower:c===`stem`?R.plantStem:R.grassBlade),h=new S(c===`flower`?R.flowerLight:R.grassBladeLight);if(s.forEach((e,n)=>{f.setFromAxisAngle(p,e.rotation);let r=c===`flower`?e.diameter:e.height,i=c===`grass`&&e.gap?G.grass.gapWidthScale:1;d.compose(new t(e.x,G.rootHeight+(c===`flower`?e.height:0),e.z),f,new t(r*i,r,r*i)),u.setMatrixAt(n,d),u.setColorAt(n,m.clone().lerp(h,c===`stem`?e.color*.25:c===`flower`?e.color*.6:e.color*.85))}),u.instanceMatrix.needsUpdate=!0,u.instanceColor&&(u.instanceColor.needsUpdate=!0),n?.options.enabled){let e=new Float32Array(s.length*3),t=new Float32Array(s.length*4);s.forEach((n,r)=>{let i=c===`grass`?n.gap?K.wind.gapAngle:K.wind.grassAngle:K.wind.flowerAngle;e.set([n.x,G.rootHeight,n.z],r*3),t.set([n.height,i,se(n.x,n.z),+(c===`flower`)],r*4)}),i.setAttribute(`windRoot`,new a(e,3)),i.setAttribute(`windShape`,new a(t,4))}u.computeBoundingBox(),u.computeBoundingSphere(),n?.options.enabled&&(u.boundingBox.expandByScalar(.02),u.boundingSphere.radius+=.02),u.userData.plants=s,u.userData.plantType=c,g.push(u),r.add(u)}d(`grass-clusters`,o,e,f,`grass`),d(`flower-stems`,s,e,p,`stem`),d(`flowers-four-petal`,c,i,p.filter((e,t)=>t%2==0),`flower`),d(`flowers-five-petal`,u,i,p.filter((e,t)=>t%2==1),`flower`)}r.userData.seed=G.seed,r.userData.counts={grass:f.length,flowers:p.length,batches:g.length};let _=!1;return{root:r,dispose(){if(!_){_=!0;for(let e of g)e.dispose();for(let e of m)e.dispose();for(let e of h)e.dispose();r.removeFromParent(),r.clear()}}}}var Q={radius:.26,centerY:1.37,floatAmplitude:.03,floatPeriod:6,sphereSegments:[12,8],shape:{first:.018,second:.009,x:.012,y:.015,z:.012,yRatio:.96,envelope:1.06},stemRadius:.04,stemOverlap:.025,releaseLatitude:-.16,releaseMargin:.004,colors:{base:`#80B9D5`,light:`#ADDCE8`,side:`#4D89B2`,shade:`#427192`,white:`#F3FBFF`}},je=Math.PI*2/Q.floatPeriod,Me=()=>({y:0,sx:1,sy:1,sz:1});function Ne(e,t=Me()){let n=e*je;return t.y=Q.centerY+Q.floatAmplitude*Math.sin(n),t.sx=1+Q.shape.x*Math.sin(n*.73),t.sy=Q.shape.yRatio*(1+Q.shape.y*Math.sin(n+.8)),t.sz=1+Q.shape.z*Math.cos(n*.81),t}function Pe(e,t,n,r){return 1+Q.shape.first*Math.sin(e*3.7+t*2.1+r*je*.84)+Q.shape.second*Math.cos(n*4.4-t*1.3-r*je*1.18)}var Fe=()=>({birthTime:NaN,x:0,y:0,z:0,vx:0,vy:0,vz:0,duration:0,impactX:0,impactZ:0}),Ie=Me();function Le(e,t,n=Fe()){let r=Ne(t,Ie),i=Math.hypot(e.vx,e.vz),a=Q.releaseLatitude,o=Math.sqrt(1-a*a),s=e.vx/i*o,c=a,l=e.vz/i*o,u=Q.radius*Pe(s,c,l,t),d=Math.hypot(s/r.sx,c/r.sy,l/r.sz),f=e.radius+Q.releaseMargin;n.birthTime=t,n.x=s*u*r.sx+s/r.sx/d*f,n.y=r.y+c*u*r.sy+c/r.sy/d*f,n.z=l*u*r.sz+l/r.sz/d*f,n.vx=e.vx,n.vz=e.vz,n.vy=e.vy+Q.floatAmplitude*je*Math.cos(t*je);let p=n.y-X.fountain.waterHeight-e.radius;return n.duration=(n.vy+Math.sqrt(n.vy*n.vy+2*q.drops.gravity*p))/q.drops.gravity,n.impactX=n.x+n.vx*n.duration,n.impactZ=n.z+n.vz*n.duration,n}function Re(e,t,n){return n.set(e.x+e.vx*t,e.y+e.vy*t-.5*q.drops.gravity*t*t,e.z+e.vz*t)}function ze(e){let t=Y(`water`);t.name=`courtyard-living-orb`,t.flatShading=!0,t.customProgramCacheKey=()=>`courtyard-living-orb-v1`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r),Object.assign(t.uniforms,{uOrbTime:e.time,uOrbBase:{value:new S(Q.colors.base)},uOrbLight:{value:new S(Q.colors.light)},uOrbSide:{value:new S(Q.colors.side)},uOrbShade:{value:new S(Q.colors.shade)},uOrbWhite:{value:new S(Q.colors.white)}});let i=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!t.fragmentShader.includes(i))throw Error(`Orb shader extension anchor changed.`);t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      uniform float uOrbTime;
      uniform vec3 uOrbBase; uniform vec3 uOrbLight; uniform vec3 uOrbSide; uniform vec3 uOrbShade; uniform vec3 uOrbWhite;
    
void main() {`).replace(i,`
      vec3 orbNormal = inverseTransformDirection(normal, viewMatrix);
      float sunFace = .5;
      #if NUM_DIR_LIGHTS > 0
        sunFace = max(dot(normal, directionalLights[0].direction), 0.0);
      #endif
      float volume = smoothstep(-.6, .7, orbNormal.y) * .6 + sunFace * .4;
      float band = floor(clamp(volume, 0.0, .999) * 4.0) / 3.0;
      vec3 orbColor = mix(uOrbSide, uOrbBase, band);
      orbColor = mix(orbColor, uOrbLight, smoothstep(.65, .95, volume) * .48);
      float edge = pow(1.0 - clamp(dot(normal, normalize(vViewPosition)), 0.0, 1.0), 2.6);
      float upper = smoothstep(-.12, .55, orbNormal.y);
      float crown = smoothstep(.78, .96, orbNormal.y) * smoothstep(-.25, .3, orbNormal.x + .4);
      float rim = smoothstep(.3, .8, edge) * upper * smoothstep(-.4, .2, orbNormal.z);
      float sheen = .035 * sin(uOrbTime * .55 + orbNormal.x * 4.0 + orbNormal.z * 3.0);
      orbColor = mix(orbColor, uOrbLight, max(sheen, 0.0));
      orbColor = mix(orbColor, uOrbWhite, clamp(max(crown * .82, rim * .75), 0.0, .86));
      outgoingLight = mix(uOrbShade, orbColor, getShadowMask());
    `)},t}function Be(e,n){let r=new s;r.name=`fountain-effects`,r.userData.orbStyle=`lively`;let a=X.fountain;r.position.set(...a.position),r.rotation.y=a.rotationY;let o=xe(e,`jet`),c=ze(e),d=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,f=new m(Q.stemRadius,Q.stemRadius,1,8),p=new C(1,...Q.sphereSegments),h=p.getAttribute(`position`);h.setUsage(u);let g=new Float32Array(h.array);p.boundingSphere=new b(new t,Q.shape.envelope),p.boundingBox=new M(new t().setScalar(-Q.shape.envelope),new t().setScalar(Q.shape.envelope));let _=new N(1,0),v=new i(f,o);v.name=`fountain-water-column`,v.receiveShadow=!0;let y=new i(p,c);y.name=`fountain-water-crown`,y.receiveShadow=!0,y.scale.setScalar(Q.radius);let x=new l(_,o,n.length);x.name=`fountain-water-drops`,x.receiveShadow=!0,x.instanceMatrix.setUsage(u),x.boundingBox=new M(new t(-1.75,.3,-1.75),new t(1.75,1.9,1.75)),x.boundingSphere=x.boundingBox.getBoundingSphere(new b),r.add(v,y,x),r.visible=q.enabled;let S=Me(),w=new t,T=new t,E=new F,D=new j,O=new j,k=n.map((e,t)=>({drop:e,index:t,current:Fe(),previous:Fe()})),A=k.map(e=>({record:e,age:0,flight:e.current}));r.userData.flights=k,r.userData.orbPose=S,r.userData.impactEvents=A,r.userData.orbMetadata={radius:Q.radius,centerY:Q.centerY,amplitude:Q.floatAmplitude,period:Q.floatPeriod,envelope:Q.shape.envelope,replacedGeometries:2,addedGeometries:0,addedTextures:0,addedPasses:0,dropCapacity:n.length,rippleCapacity:e.impacts.value.length};let P,ee=!1;function I(t){if(ee||t===P)return;P=t,e.time.value=t,Ne(t,S);let i=1/0;for(let e=0;e<h.count;e++){let n=e*3,r=g[n],a=g[n+1],o=g[n+2],s=Pe(r,a,o,t),c=a*s*S.sy;h.setXYZ(e,r*s*S.sx,c,o*s*S.sz),i=Math.min(i,c)}h.needsUpdate=!0,y.position.y=S.y;let a=S.y+i*Q.radius,o=a+Q.stemOverlap;v.position.y=(d+o)/2,v.scale.y=o-d;let s=0;for(let e of k){let{drop:n,current:r,previous:i}=e,a=n.phase+Math.floor((t-n.phase)/q.drops.period)*q.drops.period;a!==r.birthTime&&(Le(n,a,r),Le(n,a-q.drops.period,i));let o=t-a;if(o>=r.duration)continue;let c=n.radius*Math.min(1,o/.07,(r.duration-o)/.055);c<5e-4||(Re(r,o,w),T.setScalar(c),D.compose(w,E,T),x.setMatrixAt(s++,D))}x.count=s;for(let e=s;e<n.length;e++)x.setMatrixAt(e,O);x.instanceMatrix.needsUpdate=!0;for(let e of A){let n=e.record;e.flight=t>=n.current.birthTime+n.current.duration?n.current:n.previous,e.age=t-e.flight.birthTime-e.flight.duration}A.sort((e,t)=>e.age-t.age||e.record.index-t.record.index);let c=0;for(let t=0;t<e.impacts.value.length;t++){let n=A[t];n.age>=0&&n.age<q.ripples.lifetime?(e.impacts.value[t].set(n.flight.impactX,n.flight.impactZ,n.age,n.record.drop.strength),c++):e.impacts.value[t].set(0,0,0,0)}r.userData.time=t,r.userData.activeDrops=s,r.userData.activeRipples=c,r.userData.orbBottom=a,r.userData.stemTop=o}return I(q.initialTime),{root:r,update:I,dispose(){ee||(ee=!0,x.dispose(),f.dispose(),p.dispose(),_.dispose(),o.dispose(),c.dispose(),r.removeFromParent(),r.clear())}}}function Ve(){let e=q.seed;function t(){e+=1831565813;let t=Math.imul(e^e>>>15,1|e);return t^=t+Math.imul(t^t>>>7,61|t),((t^t>>>14)>>>0)/4294967296}let n=q.drops;return Array.from({length:n.capacity},(e,r)=>{let i=r*2.399963229728653+t()*.15,a=n.minHorizontalSpeed+t()*(n.maxHorizontalSpeed-n.minHorizontalSpeed),o=n.minVerticalSpeed+t()*(n.maxVerticalSpeed-n.minVerticalSpeed),s=n.minRadius+t()*(n.maxRadius-n.minRadius),c=Math.cos(i)*a,l=Math.sin(i)*a,u=q.jet.emitterHeight-X.fountain.waterHeight-s,d=(o+Math.sqrt(o*o+2*n.gravity*u))/n.gravity;return{phase:r*n.period/n.capacity,vx:c,vz:l,vy:o,radius:s,impactTime:d,impactX:c*d,impactZ:l*d,strength:.7+t()*.3}})}function He(e,t,n){return n.set(e.vx*t,q.jet.emitterHeight+e.vy*t-.5*q.drops.gravity*t*t,e.vz*t)}function Ue(e,n=`legacy`){if(n===`lively`)try{return Be(e,Ve())}catch(e){console.warn(`Orb detail unavailable; original water effects retained.`,e)}let r=new s;r.name=`fountain-effects`;let a=X.fountain;r.position.set(...a.position),r.rotation.y=a.rotationY;let o=Ve();r.userData.dropParameters=o;let c=xe(e,`jet`),u=a.baseHeight+a.pedestalFootHeight+a.pedestalHeight+a.pedestalCapHeight,d=q.jet.emitterHeight-u,f=new m(q.jet.stemRadius,q.jet.stemRadius,d,8),p=new C(1,8,5),h=new N(1,0),g=new i(f,c);g.name=`fountain-water-column`,g.position.y=u+d/2,g.receiveShadow=!0;let _=new i(p,c);_.name=`fountain-water-crown`,_.position.y=q.jet.emitterHeight,_.receiveShadow=!0;let v=new l(h,c,o.length);v.name=`fountain-water-drops`,v.receiveShadow=!0,v.boundingBox=new M(new t(-1.4,.3,-1.4),new t(1.4,1.45,1.4)),v.boundingSphere=v.boundingBox.getBoundingSphere(new b),r.add(g,_,v),r.visible=q.enabled;let y=new t,x=new t,S=new j,w=new F,T=new j,E=o.map(e=>({drop:e,age:0})),D=(e,t)=>e.age-t.age,O=(e,t)=>(e%t+t)%t;function k(t){e.time.value=t;let n=0;for(let e of o){let r=O(t-e.phase,q.drops.period);if(r>=e.impactTime)continue;He(e,r,y);let i=Math.min(1,r/.07),a=Math.min(1,(e.impactTime-r)/.055),o=e.radius*Math.min(i,a);o<5e-4||(x.setScalar(o),S.compose(y,w,x),v.setMatrixAt(n++,S))}v.count=n;for(let e=n;e<o.length;e++)v.setMatrixAt(e,T);v.instanceMatrix.needsUpdate=!0;for(let e of E)e.age=O(t-e.drop.phase-e.drop.impactTime,q.drops.period);E.sort(D);let i=0;for(let t=0;t<e.impacts.value.length;t++){let n=E[t];n.age<q.ripples.lifetime?(e.impacts.value[t].set(n.drop.impactX,n.drop.impactZ,n.age,n.drop.strength),i++):e.impacts.value[t].set(0,0,0,0)}let a=q.jet.pulse,s=q.jet.radius;_.scale.set(s*(1+a*Math.sin(t*2.1)),s*.9*(1+a*Math.sin(t*2.8)),s*(1+a*Math.cos(t*2.1))),g.scale.set(1+a*Math.sin(t*2.1),1,1+a*Math.sin(t*2.1)),r.userData.time=t,r.userData.activeDrops=n,r.userData.activeRipples=i}k(q.initialTime);let A=!1;return{root:r,update:k,dispose(){A||(A=!0,v.dispose(),f.dispose(),p.dispose(),h.dispose(),c.dispose(),r.removeFromParent(),r.clear())}}}function We(){let e=K.petals,n=K.seed+1;function r(){n+=1831565813;let e=Math.imul(n^n>>>15,1|n);return e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296}let i=Array.from({length:e.capacity},(t,n)=>{let i=0,a=0,o=!1;for(let t=0;t<1e3;t++){let t=G.flowers.clusters[Math.floor(r()*G.flowers.clusters.length)],n=r()*Math.PI*2,s=r()*t.radius;if(i=t.center[0]+Math.cos(n)*s,a=t.center[1]+Math.sin(n)*s,ke(i,a,e.drift*Math.SQRT2+.05)){o=!0;break}}if(!o)throw Error(`Cannot fit a clear floating-petal corridor.`);return{x:i,z:a,phase:n*e.period/e.capacity,rotation:r()*Math.PI*2,size:.055+r()*.02}}),a=new k;a.setAttribute(`position`,new T([0,0,-.5,-.32,0,0,0,.035,.45,0,0,-.5,0,.035,.45,.32,0,0],3)),a.computeVertexNormals();let o=new p({color:R.flowerLight,side:2,toneMapped:!1});o.name=`courtyard-floating-petal`;let s=new l(a,o,e.capacity);s.name=`courtyard-floating-petals`,s.castShadow=!1;let c=new M;for(let n of i)c.expandByPoint(new t(n.x-e.drift,e.minHeight,n.z-e.drift)),c.expandByPoint(new t(n.x+e.drift,e.maxHeight,n.z+e.drift));c.expandByScalar(.05),s.boundingBox=c,s.boundingSphere=c.getBoundingSphere(new b),s.userData.parameters=i;let u=new j,d=new t,f=new t,m=new F,h=new j,g=new t(.25,1,.15).normalize(),_=!1;return{mesh:s,update(t){let n=0;for(let r of i){let i=((t-r.phase)%e.period+e.period)%e.period;if(i>=e.lifetime)continue;let a=i/e.lifetime,o=Math.min(1,i/.6,(e.lifetime-i)/.7);d.set(r.x+Math.sin(i*.6+r.rotation)*e.drift,e.maxHeight+(e.minHeight-e.maxHeight)*a,r.z+Math.cos(i*.5+r.rotation)*e.drift),m.setFromAxisAngle(g,r.rotation+i*.25),f.setScalar(r.size*o),u.compose(d,m,f),s.setMatrixAt(n++,u)}s.count=n;for(let t=n;t<e.capacity;t++)s.setMatrixAt(t,h);s.instanceMatrix.needsUpdate=!0},dispose(){_||(_=!0,s.dispose(),a.dispose(),o.dispose(),s.removeFromParent())}}}var $={flowSpeed:.035,waveSpeed:.36,waveStrength:.15,rippleStrength:.42,foamWidth:[.015,.04],colors:{shallow:`#B4DAD9`,base:`#BED4DF`,middle:`#95BECF`,deep:`#245B80`,shade:`#7FA3BF`,white:`#F2FAFC`,stoneTop:`#F0E5C1`,stoneSide:`#C7CCB6`,stoneShade:`#7095A1`,wetStone:`#557D81`,weathering:`#A3B592`}};function Ge(){let t=ye({top:$.colors.stoneTop,side:$.colors.stoneSide,shade:$.colors.stoneShade});t.name=`courtyard-pool-stone`,t.customProgramCacheKey=()=>`courtyard-pool-stone-v1`;let n=t.onBeforeCompile.bind(t);return t.onBeforeCompile=(t,r)=>{n(t,r);let i=X.fountain;Object.assign(t.uniforms,{uPoolStoneOrigin:{value:new e(i.position[0],i.position[2],Math.cos(i.rotationY),Math.sin(i.rotationY))},uPoolStoneLevels:{value:new e(i.position[1],i.waterHeight,i.baseHeight,i.innerRadius)},uPoolStoneWet:{value:new S($.colors.wetStone)},uPoolStoneOld:{value:new S($.colors.weathering)}});let a=`outgoingLight *= 1.0 + vArtStoneTint * uArtStoneVariation;`;if(!t.fragmentShader.includes(a))throw Error(`Pool stone extension anchor changed.`);t.fragmentShader=t.fragmentShader.replace(`void main() {`,`
      uniform vec4 uPoolStoneOrigin; uniform vec4 uPoolStoneLevels;
      uniform vec3 uPoolStoneWet; uniform vec3 uPoolStoneOld;
    
void main() {`).replace(a,`${a}\n
      vec2 poolDelta = vArtWorldPosition.xz - uPoolStoneOrigin.xy;
      vec2 poolP = vec2(uPoolStoneOrigin.z * poolDelta.x - uPoolStoneOrigin.w * poolDelta.y,
                       uPoolStoneOrigin.w * poolDelta.x + uPoolStoneOrigin.z * poolDelta.y);
      vec2 poolN = vec2(uPoolStoneOrigin.z * worldNormal.x - uPoolStoneOrigin.w * worldNormal.z,
                       uPoolStoneOrigin.w * worldNormal.x + uPoolStoneOrigin.z * worldNormal.z);
      float poolY = vArtWorldPosition.y - uPoolStoneLevels.x;
      float side = 1.0 - smoothstep(.35, .85, worldNormal.y);
      float innerFace = 1.0 - smoothstep(-.08, .05, dot(poolN, poolP));
      float pedestal = 1.0 - smoothstep(.44, .58, max(abs(poolP.x), abs(poolP.y)));
      float wetNoise = artNoise(poolP * 13.0 + vec2(5.4, 8.1));
      float wetLine = 1.0 - smoothstep(uPoolStoneLevels.y + .018, uPoolStoneLevels.y + .065 + wetNoise * .025, poolY);
      float wet = wetLine * side * max(innerFace, pedestal);
      outgoingLight = mix(outgoingLight, mix(outgoingLight * .73, uPoolStoneWet, .22), wet * .72);
      float contact = (1.0 - smoothstep(.02, .075, poolY)) * side;
      outgoingLight = mix(outgoingLight, uPoolStoneWet * .78, contact * .30);
      float capStep = (1.0 - smoothstep(.004, .018, abs(poolY - .44))) * side;
      outgoingLight *= 1.0 - capStep * .10;
      float chips = max(1.0 - smoothstep(.08, .28, length(poolP - vec2(.935, -2.259))),
                        1.0 - smoothstep(.08, .28, length(poolP + vec2(.935, -2.259))));
      float weather = chips * smoothstep(.48, .72, wetNoise) * smoothstep(.48, .56, poolY);
      outgoingLight = mix(outgoingLight, uPoolStoneOld, weather * .35);
    `)},t}function Ke(t){let n=Y(`water`);n.name=`courtyard-water-refined-surface`,n.userData.waterKind=`refined-surface`,n.customProgramCacheKey=()=>`courtyard-water-refined-surface-v1`;let r=n.onBeforeCompile.bind(n);return n.onBeforeCompile=(n,i)=>{r(n,i);let a=X.fountain;Object.assign(n.uniforms,{uPoolTime:t.time,uPoolImpacts:t.impacts,uPoolOrigin:{value:new e(a.position[0],a.position[2],Math.cos(a.rotationY),Math.sin(a.rotationY))},uPoolMotion:{value:new e($.flowSpeed,$.waveSpeed,$.waveStrength,$.rippleStrength)},uPoolBoundary:{value:new e(a.innerRadius*Math.cos(Math.PI/8),...$.foamWidth,q.ripples.lifetime)},uPoolShallow:{value:new S($.colors.shallow)},uPoolBase:{value:new S($.colors.base)},uPoolMiddle:{value:new S($.colors.middle)},uPoolDeep:{value:new S($.colors.deep)},uPoolShade:{value:new S($.colors.shade)},uPoolWhite:{value:new S($.colors.white)}});let o=`
      uniform float uPoolTime;
      uniform vec4 uPoolImpacts[${q.ripples.capacity}];
      uniform vec4 uPoolOrigin; uniform vec4 uPoolMotion; uniform vec4 uPoolBoundary;
      uniform vec3 uPoolShallow; uniform vec3 uPoolBase; uniform vec3 uPoolMiddle;
      uniform vec3 uPoolDeep; uniform vec3 uPoolShade; uniform vec3 uPoolWhite;
    `,s=`
      vec2 delta = vArtWorldPosition.xz - uPoolOrigin.xy;
      vec2 p = vec2(uPoolOrigin.z * delta.x - uPoolOrigin.w * delta.y,
                    uPoolOrigin.w * delta.x + uPoolOrigin.z * delta.y);
      float t = uPoolTime;
      vec2 drift = vec2(t, -t * .25) * uPoolMotion.x;
      float broad = artNoise(p * vec2(2.2, 1.6) + drift * .5 + vec2(3.7, 6.1));
      float grain = artNoise(p * 18.0 + drift);
      vec2 q = p + vec2((broad - .5) * .20, (artNoise(p * 2.8 + vec2(8.4, 1.7) - drift) - .5) * .18) + drift * .65;
      vec2 leftShape = mat2(.96, -.28, .28, .96) * (q - vec2(-1.3, -.25));
      float leftReflection = length(leftShape / vec2(.36, 1.62));
      vec2 farShape = q - vec2(.30, -1.68);
      farShape.y += sin(farShape.x * 2.0) * .10;
      float farReflection = length(farShape / vec2(1.42, .31));
      vec2 nearShape = mat2(.91, .41, -.41, .91) * (q - vec2(1.12, .95));
      float nearReflection = length(nearShape / vec2(.24, .64));
      float silhouette = min(min(leftReflection, farReflection), nearReflection);
      silhouette += (broad - .5) * .70 + (grain - .5) * .12;
      float aa = clamp(max(fwidth(p.x), fwidth(p.y)), .003, .12);
      float detail = 1.0 - smoothstep(.035, .095, aa);
      float reflection = 1.0 - smoothstep(.93 - aa, 1.04 + aa, silhouette);
      float centerDistance = length(p);
      reflection *= smoothstep(.55, .85, centerDistance);

      float shoreDistance = 10.0;
      for (int i = 0; i < 8; i++) {
        float angle = (float(i) + .5) * PI / 4.0;
        shoreDistance = min(shoreDistance, uPoolBoundary.x - dot(p, vec2(cos(angle), -sin(angle))));
      }
      float shelf = smoothstep(.025, .18, shoreDistance);
      float depth = smoothstep(.28, 1.25, shoreDistance) * .26;
      vec3 clearWater = mix(uPoolShallow, uPoolBase, shelf);
      clearWater = mix(clearWater, uPoolMiddle, depth);
      vec3 litWater = mix(clearWater, uPoolDeep, reflection * .96);

      float wave = smoothstep(.955, .995, sin(centerDistance * 12.0 - t * uPoolMotion.y * 12.0 + broad));
      wave *= smoothstep(.65, .9, centerDistance) * (1.0 - smoothstep(1.5, 1.95, centerDistance));
      wave *= smoothstep(.52, .76, artNoise(p * 7.5 + drift)) * uPoolMotion.z;
      float glint = smoothstep(.78, .94, artNoise(p * 7.0 - drift))
        * smoothstep(.90, .99, sin(p.x * 11.0 + p.y * 6.0 - t * .72 + broad * 3.0)) * .64;
      float foam = (1.0 - smoothstep(uPoolBoundary.y, uPoolBoundary.z + aa * .35, shoreDistance))
        * smoothstep(.71, .88, artNoise(p * 12.0 + drift)) * .48;
      float impacts = 0.0;
      for (int i = 0; i < ${q.ripples.capacity}; i++) {
        vec4 event = uPoolImpacts[i];
        float radius = .025 + event.z * ${q.ripples.speed.toFixed(2)};
        float distanceToRing = abs(length(p - event.xy) - radius);
        float ring = 1.0 - smoothstep(.008, .018 + aa * .3, distanceToRing);
        float ageFade = pow(clamp(1.0 - event.z / uPoolBoundary.w, 0.0, 1.0), 2.0);
        float broken = smoothstep(.22, .47, artNoise(p * 9.0 + vec2(float(i) * 3.1, 5.0)));
        impacts = max(impacts, ring * ageFade * event.w * broken * uPoolMotion.w);
      }
      float white = max(max(wave, glint) * mix(.25, 1.0, detail), max(foam, impacts));
      litWater = mix(litWater, uPoolWhite, white);
      vec3 shadedWater = mix(uPoolShade, uPoolDeep * .84, reflection * .78);
      shadedWater = mix(shadedWater, uPoolWhite, white * .13);
      outgoingLight = mix(shadedWater, litWater, getShadowMask());
    `,c=`outgoingLight = mix(uArtWaterShade, uArtWater, getShadowMask());`;if(!n.fragmentShader.includes(c))throw Error(`Pool surface extension anchor changed.`);n.fragmentShader=n.fragmentShader.replace(`void main() {`,`${o}\nvoid main() {`).replace(c,s)},n}function qe(e,t){let n=e.getObjectByName(`fountain`),r=n?.getObjectByName(`fountain-water`),a=[];if(n?.traverse(e=>{e instanceof i&&/^fountain-(base|rim-wall|coping-\d|pedestal(-foot|-cap)?)$/.test(e.name)&&a.push(e)}),!(r instanceof i)||a.length!==13)throw Error(`Pool finish requires the complete original fountain.`);let o=Ke(t),s=Ge(),c=new Map;for(let e of[...a,r])c.set(e,e.material),e.material=e===r?o:s;let l=!1;return{metadata:{bindings:[...c.keys()].map(e=>({object:e.name,material:e.material.name})),newGeometries:0,newTextures:0,extraPasses:0},dispose(){if(!l){l=!0;for(let[e,t]of c)e.material=t;c.clear(),o.dispose(),s.dispose()}}}}function Je(e={},t=`legacy`,n=`legacy`){let a=oe(e),o=new P;o.background=new S(R.grassBase);let s=new w;s.position.set(...H.camera.position),s.lookAt(...H.camera.target),s.near=H.camera.near,s.far=H.camera.far;let c=new y(H.ground.size,H.ground.size),l=pe(a),u=new i(c,l);u.name=`courtyard-ground`,u.rotation.x=-Math.PI/2,u.receiveShadow=!0,o.add(u);let d=be(),f=Se(d);o.add(f.root);let p;if(t===`refined`)try{p=qe(o,d)}catch(e){console.warn(`Pool finish unavailable; original fountain retained.`,e)}let m=Ue(d,n);o.add(m.root);let h=new r(R.highlight,R.stoneShade,U.fill.intensity);h.name=`courtyard-fill`;let g=new I(R.highlight,U.sun.intensity);g.name=`courtyard-sun`,g.position.set(...U.sun.position),g.castShadow=U.shadows.enabled;let _=U.shadows;g.shadow.mapSize.setScalar(_.mapSize),g.shadow.camera.left=-_.extent,g.shadow.camera.right=_.extent,g.shadow.camera.top=_.extent,g.shadow.camera.bottom=-_.extent,g.shadow.camera.near=_.near,g.shadow.camera.far=_.far,g.shadow.bias=_.bias,g.shadow.normalBias=_.normalBias,g.shadow.radius=_.radius,o.add(h,g,g.target);let v=H.camera.viewHeight,b=1;function x(e){b=e;let t=v/2;s.left=-t*e,s.right=t*e,s.top=t,s.bottom=-t,s.updateProjectionMatrix()}x(1),s.updateMatrixWorld(!0);let C=Ae(s,a);o.add(C.root);let T=a.options.enabled&&a.options.petals?We():void 0;T&&(T.update(a.time.value),o.add(T.mesh));let E=!1;return{scene:o,camera:s,setAspect:x,setViewHeight(e){if(!Number.isFinite(e)||e<=0)throw RangeError(`Camera view height must be positive.`);e!==v&&(v=e,x(b))},update(e){m.update(e),a.time.value=e,T?.update(e)},waterState:d,fountainStyle:p?`refined`:t===`refined`?`fallback`:`legacy`,fountainMetadata:p?.metadata,orbStyle:m.root.userData.orbStyle??(n===`lively`?`fallback`:`legacy`),orbMetadata:m.root.userData.orbMetadata,environmentState:a,dispose(){E||(E=!0,c.dispose(),l.dispose(),p?.dispose(),f.dispose(),C.dispose(),m.dispose(),T?.dispose(),g.shadow.dispose(),o.clear())}}}var Ye=[320,384,448],Xe={resolution:384,finish:`clean`,finishes:{clean:{levels:0,dither:0},soft:{levels:64,dither:.18}}};function Ze(e){let t=Number(e.get(`pixelSize`));return{resolution:Ye.some(e=>e===t)?t:Xe.resolution,finish:e.get(`finish`)===`soft`?`soft`:Xe.finish,storage:`auto`}}function Qe(e,t){let r=t.storage!==`byte`&&e.extensions.has(`EXT_color_buffer_float`),a=new E(1,1,{type:r?n:h,minFilter:x,magFilter:x,generateMipmaps:!1,depthBuffer:!0,stencilBuffer:!1});a.texture.colorSpace=r?f:g,a.texture.name=`courtyard-pixel-scene`;let o=new k;o.setAttribute(`position`,new T([-1,-1,0,3,-1,0,-1,3,0],3)),o.setAttribute(`uv`,new T([0,0,2,0,0,2],2));let s=Xe.finishes[t.finish],c=new v({name:`courtyard-pixel-output`,depthTest:!1,depthWrite:!1,toneMapped:!1,uniforms:{uScene:{value:a.texture},uSampleSize:{value:new d(1,1)},uLevels:{value:s.levels},uDither:{value:s.dither}},vertexShader:`
      varying vec2 vPixelUv;
      void main() {
        vPixelUv = uv;
        gl_Position = vec4(position.xy, 0.0, 1.0);
      }
    `,fragmentShader:`
      uniform sampler2D uScene;
      uniform vec2 uSampleSize;
      uniform float uLevels;
      uniform float uDither;
      varying vec2 vPixelUv;
      float bayer2(vec2 p) {
        vec2 b = mod(p, 2.0);
        return mod(2.0 * b.x + 3.0 * b.y, 4.0);
      }
      void main() {
        vec2 cell = clamp(floor(vPixelUv * uSampleSize), vec2(0.0), uSampleSize - 1.0);
        vec2 centerUv = (cell + 0.5) / uSampleSize;
        vec3 linearColor = texture2D(uScene, centerUv).rgb;
        vec3 displayColor = linearToOutputTexel(vec4(linearColor, 1.0)).rgb;
        if (uLevels > 1.0) {
          float threshold = (4.0 * bayer2(cell) + bayer2(floor(cell / 2.0)) + 0.5) / 16.0 - 0.5;
          float steps = uLevels - 1.0;
          displayColor = floor(clamp(displayColor + threshold * uDither / steps, 0.0, 1.0) * steps + 0.5) / steps;
        }
        gl_FragColor = vec4(displayColor, 1.0);
      }
    `}),l=new P,u=new w(-1,1,1,-1,0,1),p=new i(o,c);p.frustumCulled=!1,l.add(p);let m=!1,_=0;function y(){a.dispose(),o.dispose(),c.dispose()}return{releaseGpuResources:y,resize(e,n){let r=Math.min(1,t.resolution/Math.max(e,n)),i=Math.max(1,Math.round(e*r)),o=Math.max(1,Math.round(n*r));(i!==a.width||o!==a.height)&&(a.setSize(i,o),c.uniforms.uSampleSize.value.set(i,o),_++)},render(t,n){e.setRenderTarget(a),e.render(t,n),e.setRenderTarget(null),e.render(l,u)},getInfo(){return{sampleWidth:a.width,sampleHeight:a.height,designResolution:t.resolution,finish:t.finish,storage:r?`linear-half-float`:`srgb8`,minFilter:`nearest`,magFilter:`nearest`,mipmaps:!1,levels:s.levels,dither:s.dither,allocations:_}},dispose(){m||(m=!0,y(),l.clear())}}}function $e(e){let t=new Set,n=new Set,r=new Set;e.traverse(e=>{if(e instanceof i||e instanceof O){t.add(e.geometry);for(let t of Array.isArray(e.material)?e.material:[e.material])n.add(t)}e instanceof l&&e.dispose(),e instanceof I&&(e.shadow.map?.dispose(),e.shadow.mapPass?.dispose())});for(let e of t)e.dispose();for(let e of n){for(let t of Object.values(e))t instanceof A&&r.add(t);if(e instanceof v)for(let t of Object.values(e.uniforms)){let e=Array.isArray(t.value)?t.value:[t.value];for(let t of e)t instanceof A&&r.add(t)}e.dispose()}for(let e of r)e.dispose()}function et(e,t,n,r=Ze(new URLSearchParams),i){let a=new L({antialias:!1,alpha:!1});a.outputColorSpace=g,a.toneMapping=0,a.shadowMap.enabled=!0,a.shadowMap.type=1,a.shadowMap.autoUpdate=!1,a.shadowMap.needsUpdate=!0,a.info.autoReset=!1;let o=Qe(a,r),s=new d,c=a.domElement;c.setAttribute(`role`,`img`),c.setAttribute(`aria-label`,`固定俯视庭院：石柱和粉紫小花围绕八边形喷泉，蓝白水面流动，草花随风轻摆，树影边缘缓慢变化，可暂停整个场景动效。`),e.append(c);let l=t,u=!1,f=!1,p=!1,m=!1,h=!0,_,v,y,b=0,x=0,S=0,C=0;function w(){y!==void 0&&cancelAnimationFrame(y),y=void 0,b=0}function T(){u||f||m||h||!_||y!==void 0||b===0||(y=requestAnimationFrame(e=>{y=void 0,b--,u||f||m||h||(_?.(e),T())}))}function E(){u||f||m||h||!_||(b=Math.max(b,2),T())}function D(){let e=!u&&!f&&!m;(!e||h)&&w(),a.setAnimationLoop(e&&h&&_?_:null),e&&!h&&E()}function O(){let t=e.getBoundingClientRect();if(t.width<=0||t.height<=0||u)return;let r=Math.min(window.devicePixelRatio||1,ie.maxDevicePixelRatio),i=Math.max(1,Math.floor(t.width)),d=Math.max(1,Math.floor(t.height));(i!==x||d!==S||r!==C)&&(x=i,S=d,C=r,a.setPixelRatio(r),a.setSize(i,d,!1),a.getDrawingBufferSize(s),o.resize(s.x,s.y)),c.dataset.renderMode=l;let f=o.getInfo();c.dataset.sampleWidth=String(l===`pixel`?f.sampleWidth:s.x),c.dataset.sampleHeight=String(l===`pixel`?f.sampleHeight:s.y),c.dataset.pixelProfile=String(f.designResolution),c.dataset.finish=f.finish,n(t.width/t.height),E()}function k(t){t.preventDefault(),f=!0,p=!0,e.dataset.renderState=`context-lost`,D(),o.releaseGpuResources(),v&&$e(v),i?.(`context-lost`)}function A(){f=!1,x=0,a.shadowMap.needsUpdate=!0,i?.(`restored`),O(),D()}c.addEventListener(`webglcontextlost`,k),c.addEventListener(`webglcontextrestored`,A);let j=new ResizeObserver(O);j.observe(e),window.addEventListener(`resize`,O);let M;function N(){M?.removeEventListener(`change`,P),M=window.matchMedia(`(resolution: ${window.devicePixelRatio}dppx)`),M.addEventListener(`change`,P)}function P(){N(),O()}return N(),O(),{canvas:c,setMode(e){l=e,O()},setAnimating(e){h=e,D()},setSuspended(e){m!==e&&(m=e,D())},renderOnce(){_?.(performance.now()),E()},getStats(){return{geometries:a.info.memory.geometries,textures:a.info.memory.textures,programs:a.info.programs?.length??0,calls:a.info.render.calls,triangles:a.info.render.triangles,mode:l,outputWidth:a.domElement.width,outputHeight:a.domElement.height,pixel:l===`pixel`?o.getInfo():null}},start(t,n,r){v=t,_=s=>{u||f||m||(r?.(s),a.info.reset(),l===`pixel`?o.render(t,n):(a.setRenderTarget(null),a.render(t,n)),e.dataset.renderState=`ready`,p&&(p=!1,i?.(`ready`),E()))},D()},dispose(){u||(u=!0,w(),j.disconnect(),window.removeEventListener(`resize`,O),M.removeEventListener(`change`,P),c.removeEventListener(`webglcontextlost`,k),c.removeEventListener(`webglcontextrestored`,A),a.setAnimationLoop(null),_=void 0,v=void 0,o.dispose(),a.dispose(),!a.getContext().isContextLost()&&a.extensions.has(`WEBGL_lose_context`)&&a.forceContextLoss(),c.remove())}}}function tt(e,t=q.maxFrameDelta){let n=e,r=null;return{get time(){return n},resetTimestamp(){r=null},tick(e,i){let a=r===null?0:Math.min(t,Math.max(0,(e-r)/1e3));return r=e,i&&(n+=a),n}}}function nt(e,t,n=!1,r={}){let i=window.matchMedia(`(prefers-reduced-motion: reduce)`),a=tt(t),o=n||r.retainReducedPause&&i.matches?!0:null,s=!1;function c(){return{playing:!document.hidden&&!(o??i.matches),hidden:document.hidden,reducedMotion:i.matches}}function l(){s||(a.resetTimestamp(),e(c()))}function u(){i.matches&&o!==!0&&(o=r.retainReducedPause?!0:null),l()}return document.addEventListener(`visibilitychange`,l),i.addEventListener(`change`,u),{get state(){return c()},get time(){return a.time},advance(e){return a.tick(e,c().playing)},resetTimestamp:a.resetTimestamp,toggle(){o=!(o??i.matches),l()},dispose(){s||(s=!0,document.removeEventListener(`visibilitychange`,l),i.removeEventListener(`change`,u))}}}export{ye as a,ie as c,ne as d,te as f,z as h,Je as i,H as l,B as m,et as n,q as o,V as p,Ze as r,ae as s,nt as t,re as u};