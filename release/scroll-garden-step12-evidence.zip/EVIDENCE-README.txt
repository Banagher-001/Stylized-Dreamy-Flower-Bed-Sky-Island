Step12 evidence, including fresh reports and explicitly inherited Step11 JSON records.
Final ZIP integrity/unzip status is external: release/scroll-garden-step12-manifest.json
and docs/evidence/scroll-garden-step-12/package-verification.json.
Historical screenshots are not duplicated; Step11 baseline source/build is included.
